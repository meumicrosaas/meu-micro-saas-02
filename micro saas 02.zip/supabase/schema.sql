-- ==============================================================================
-- SCHEMA SUPABASE COMPLETO & MULTI-TENANT (ARMONIX STORE DELIVERY & SAAS)
-- Projeto: eyaufwzdrjtfzcvtuxyw
-- Copie e cole este script no SQL Editor do seu novo projeto Supabase e clique em RUN
-- ==============================================================================

-- SE PRECISAR LIMPAR O BANCO ANTES DE CRIAR AS NOVAS TABELAS, DESCOMENTE A LINHA ABAIXO:
-- DROP TABLE IF EXISTS public.itens_pedido, public.pedidos, public.clientes, public.produtos, public.categorias, public.saas_pagamentos_logs, public.saas_assinaturas, public.avisos_globais, public.configuracoes_saas, public.lojas CASCADE;

-- 1. Habilitar extensões necessárias para UUID e Criptografia
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ==============================================================================
-- CRIAÇÃO DAS TABELAS
-- ==============================================================================

-- TABELA 1: LOJAS (TENANTS ISOLADOS)
CREATE TABLE IF NOT EXISTS public.lojas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT,
  owner_id TEXT,
  nome TEXT NOT NULL,
  nome_loja TEXT,
  slug TEXT NOT NULL UNIQUE,
  whatsapp TEXT NOT NULL,
  telefone_whatsapp TEXT,
  email TEXT,
  senha TEXT,
  cidade TEXT DEFAULT 'Campo Grande, MS',
  status_conta TEXT DEFAULT 'ativa' NOT NULL,
  aberto BOOLEAN DEFAULT TRUE NOT NULL,
  taxa_base_entrega NUMERIC(10, 2) DEFAULT 5.00 NOT NULL,
  valor_por_km NUMERIC(10, 2) DEFAULT 1.50 NOT NULL,
  taxas_bairros JSONB DEFAULT '[]'::jsonb,
  origem_lat DOUBLE PRECISION DEFAULT -20.4697 NOT NULL,
  origem_lng DOUBLE PRECISION DEFAULT -54.6201 NOT NULL,
  origem_endereco_texto TEXT DEFAULT 'Av. Afonso Pena, 1500 - Centro',
  chave_pix TEXT,
  mercadopago_access_token TEXT,
  mercadopago_public_key TEXT,
  abacatepay_api_key TEXT,
  abacatepay_webhook_secret TEXT,
  logo_url TEXT,
  cor_tema TEXT DEFAULT '#DC2626',
  cor_primaria TEXT DEFAULT '#DC2626',
  impressora_largura VARCHAR(10) DEFAULT '80mm' NOT NULL,
  impressora_fonte VARCHAR(10) DEFAULT 'normal' NOT NULL,
  impressora_vias INTEGER DEFAULT 1 NOT NULL,
  impressora_auto_imprimir BOOLEAN DEFAULT FALSE NOT NULL,
  impressora_espaco_corte INTEGER DEFAULT 4 NOT NULL,
  impressora_rodape_texto TEXT DEFAULT 'Agradecemos a preferência! Volte sempre.',
  banner_oferta JSONB DEFAULT '{"ativo": false}'::jsonb,
  modelo_calculo_entrega TEXT DEFAULT 'raio_km' NOT NULL,
  raios_entrega JSONB DEFAULT '[{"id":"r-1","de_km":0,"ate_km":3,"valor":5.00,"tempo_estimado_min":"30-40 min"},{"id":"r-2","de_km":3,"ate_km":6,"valor":8.50,"tempo_estimado_min":"35-45 min"},{"id":"r-3","de_km":6,"ate_km":10,"valor":12.00,"tempo_estimado_min":"45-60 min"}]'::jsonb,
  raio_maximo_km NUMERIC(10, 2) DEFAULT 15.00 NOT NULL,
  valor_km_excedente NUMERIC(10, 2) DEFAULT 2.00 NOT NULL,
  valor_pedido_frete_gratis NUMERIC(10, 2),
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- Migrações seguras caso a tabela já exista:
ALTER TABLE public.lojas ADD COLUMN IF NOT EXISTS modelo_calculo_entrega TEXT DEFAULT 'raio_km';
ALTER TABLE public.lojas ADD COLUMN IF NOT EXISTS raios_entrega JSONB DEFAULT '[{"id":"r-1","de_km":0,"ate_km":3,"valor":5.00,"tempo_estimado_min":"30-40 min"},{"id":"r-2","de_km":3,"ate_km":6,"valor":8.50,"tempo_estimado_min":"35-45 min"},{"id":"r-3","de_km":6,"ate_km":10,"valor":12.00,"tempo_estimado_min":"45-60 min"}]'::jsonb;
ALTER TABLE public.lojas ADD COLUMN IF NOT EXISTS raio_maximo_km NUMERIC(10, 2) DEFAULT 15.00;
ALTER TABLE public.lojas ADD COLUMN IF NOT EXISTS valor_km_excedente NUMERIC(10, 2) DEFAULT 2.00;
ALTER TABLE public.lojas ADD COLUMN IF NOT EXISTS valor_pedido_frete_gratis NUMERIC(10, 2);
ALTER TABLE public.lojas ADD COLUMN IF NOT EXISTS impressora_espaco_corte INTEGER DEFAULT 4;
ALTER TABLE public.lojas ADD COLUMN IF NOT EXISTS impressora_rodape_texto TEXT DEFAULT 'Agradecemos a preferência! Volte sempre.';

-- TABELA 2: CATEGORIAS DO CARDÁPIO
CREATE TABLE IF NOT EXISTS public.categorias (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  loja_id UUID NOT NULL REFERENCES public.lojas(id) ON DELETE CASCADE,
  store_id UUID,
  nome TEXT NOT NULL,
  ordem INTEGER DEFAULT 0 NOT NULL,
  ativa BOOLEAN DEFAULT TRUE NOT NULL,
  ativo BOOLEAN DEFAULT TRUE,
  icone TEXT DEFAULT 'Utensils',
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- TABELA 3: PRODUTOS DO CARDÁPIO
CREATE TABLE IF NOT EXISTS public.produtos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  loja_id UUID NOT NULL REFERENCES public.lojas(id) ON DELETE CASCADE,
  store_id UUID,
  categoria_id UUID NOT NULL REFERENCES public.categorias(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  descricao TEXT,
  preco NUMERIC(10, 2) NOT NULL,
  preco_promocional NUMERIC(10, 2),
  preco_original TEXT,
  imagem TEXT,
  imagem_url TEXT,
  destaque_oferta BOOLEAN DEFAULT FALSE NOT NULL,
  destaque_mais_pedido BOOLEAN DEFAULT FALSE NOT NULL,
  ativo BOOLEAN DEFAULT TRUE NOT NULL,
  disponivel BOOLEAN DEFAULT TRUE NOT NULL,
  opcionais JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- TABELA 4: CLIENTES (HISTÓRICO E AUTO-PREENCHIMENTO)
CREATE TABLE IF NOT EXISTS public.clientes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  loja_id UUID NOT NULL REFERENCES public.lojas(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  telefone TEXT NOT NULL,
  endereco TEXT,
  numero TEXT,
  complemento TEXT,
  bairro TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- TABELA 5: PEDIDOS EM TEMPO REAL
CREATE TABLE IF NOT EXISTS public.pedidos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  loja_id UUID NOT NULL REFERENCES public.lojas(id) ON DELETE CASCADE,
  codigo_pedido TEXT DEFAULT ('#' || floor(random() * 9000 + 1000)::text),
  cliente_nome TEXT NOT NULL,
  cliente_telefone TEXT NOT NULL,
  tipo_entrega TEXT DEFAULT 'delivery' NOT NULL,
  endereco_destino TEXT,
  endereco_completo TEXT,
  distancia_km NUMERIC(10, 2) DEFAULT 0.00,
  taxa_entrega NUMERIC(10, 2) DEFAULT 0.00 NOT NULL,
  subtotal NUMERIC(10, 2) DEFAULT 0.00,
  total NUMERIC(10, 2) NOT NULL,
  status TEXT DEFAULT 'pendente' NOT NULL,
  status_pagamento TEXT DEFAULT 'pendente' NOT NULL,
  metodo_pagamento TEXT DEFAULT 'pix_online' NOT NULL,
  forma_pagamento TEXT,
  troco_para NUMERIC(10, 2),
  impresso BOOLEAN DEFAULT FALSE NOT NULL,
  pix_copia_cola TEXT,
  pix_qrcode_url TEXT,
  gateway_transacao_id TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- TABELA 6: ITENS DO PEDIDO
CREATE TABLE IF NOT EXISTS public.itens_pedido (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pedido_id UUID NOT NULL REFERENCES public.pedidos(id) ON DELETE CASCADE,
  produto_id UUID NOT NULL REFERENCES public.produtos(id) ON DELETE RESTRICT,
  produto_nome TEXT,
  quantidade INTEGER DEFAULT 1 NOT NULL,
  preco_unitario NUMERIC(10, 2) NOT NULL,
  total_item NUMERIC(10, 2),
  observacao TEXT,
  opcionais JSONB DEFAULT '[]'::jsonb
);

-- TABELA 7: ASSINATURAS DO SAAS (SUPER ADMIN)
CREATE TABLE IF NOT EXISTS public.saas_assinaturas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  loja_id UUID NOT NULL REFERENCES public.lojas(id) ON DELETE CASCADE,
  status TEXT DEFAULT 'ativa' NOT NULL,
  plano TEXT DEFAULT 'mensal' NOT NULL,
  valor NUMERIC(10, 2) DEFAULT 169.99 NOT NULL,
  data_vencimento TIMESTAMPTZ NOT NULL,
  ultimo_pagamento TIMESTAMPTZ,
  dias_teste INTEGER DEFAULT 7,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- TABELA 8: LOGS DE PAGAMENTO DO SAAS
CREATE TABLE IF NOT EXISTS public.saas_pagamentos_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  loja_id UUID NOT NULL REFERENCES public.lojas(id) ON DELETE CASCADE,
  loja_nome TEXT NOT NULL,
  valor NUMERIC(10, 2) NOT NULL,
  metodo TEXT DEFAULT 'pix' NOT NULL,
  gateway TEXT DEFAULT 'mercadopago' NOT NULL,
  status TEXT DEFAULT 'confirmado' NOT NULL,
  data_pagamento TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  comprovante_id TEXT
);

-- TABELA 9: CONFIGURAÇÕES GLOBAIS DO SAAS (SUPER ADMIN)
CREATE TABLE IF NOT EXISTS public.configuracoes_saas (
  chave TEXT PRIMARY KEY,
  valor JSONB NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- TABELA 10: AVISOS GLOBAIS DO SAAS (SUPER ADMIN)
CREATE TABLE IF NOT EXISTS public.avisos_globais (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  titulo TEXT NOT NULL,
  mensagem TEXT NOT NULL,
  tipo TEXT DEFAULT 'informativo' NOT NULL,
  ativo BOOLEAN DEFAULT TRUE NOT NULL,
  data_criacao TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- TABELA 11: CONTAS DOS LOJISTAS (ACESSO MULTI-DISPOSITIVO)
CREATE TABLE IF NOT EXISTS public.saas_contas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  loja_id UUID REFERENCES public.lojas(id) ON DELETE CASCADE,
  nome_responsavel TEXT,
  nome_loja TEXT NOT NULL,
  slug TEXT NOT NULL,
  email TEXT NOT NULL,
  whatsapp TEXT NOT NULL,
  senha TEXT NOT NULL,
  status TEXT DEFAULT 'ativa' NOT NULL,
  plano TEXT DEFAULT 'mensal' NOT NULL,
  dispositivos_conectados INTEGER DEFAULT 1,
  ultimo_acesso TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- ==============================================================================
-- ÍNDICES PARA ALTA VELOCIDADE & MULTI-TENANCY
-- ==============================================================================
CREATE INDEX IF NOT EXISTS idx_lojas_slug ON public.lojas(slug);
CREATE INDEX IF NOT EXISTS idx_saas_contas_email ON public.saas_contas(email);
CREATE INDEX IF NOT EXISTS idx_saas_contas_whatsapp ON public.saas_contas(whatsapp);
CREATE INDEX IF NOT EXISTS idx_saas_contas_slug ON public.saas_contas(slug);
CREATE INDEX IF NOT EXISTS idx_categorias_loja ON public.categorias(loja_id, ordem);
CREATE INDEX IF NOT EXISTS idx_produtos_loja ON public.produtos(loja_id, categoria_id);
CREATE INDEX IF NOT EXISTS idx_clientes_loja ON public.clientes(loja_id, telefone);
CREATE INDEX IF NOT EXISTS idx_pedidos_loja ON public.pedidos(loja_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_itens_pedido_pedido ON public.itens_pedido(pedido_id);
CREATE INDEX IF NOT EXISTS idx_saas_assinaturas_loja ON public.saas_assinaturas(loja_id);

-- ==============================================================================
-- SEGURANÇA (ROW LEVEL SECURITY - RLS) COM POLÍTICAS PÚBLICAS
-- ==============================================================================
ALTER TABLE public.lojas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.saas_contas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categorias ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.produtos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pedidos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.itens_pedido ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.saas_assinaturas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.saas_pagamentos_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.configuracoes_saas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.avisos_globais ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public access lojas" ON public.lojas;
CREATE POLICY "Public access lojas" ON public.lojas FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access saas_contas" ON public.saas_contas;
CREATE POLICY "Public access saas_contas" ON public.saas_contas FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access categorias" ON public.categorias;
CREATE POLICY "Public access categorias" ON public.categorias FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access produtos" ON public.produtos;
CREATE POLICY "Public access produtos" ON public.produtos FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access clientes" ON public.clientes;
CREATE POLICY "Public access clientes" ON public.clientes FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access pedidos" ON public.pedidos;
CREATE POLICY "Public access pedidos" ON public.pedidos FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access itens_pedido" ON public.itens_pedido;
CREATE POLICY "Public access itens_pedido" ON public.itens_pedido FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access saas_assinaturas" ON public.saas_assinaturas;
CREATE POLICY "Public access saas_assinaturas" ON public.saas_assinaturas FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access saas_pagamentos_logs" ON public.saas_pagamentos_logs;
CREATE POLICY "Public access saas_pagamentos_logs" ON public.saas_pagamentos_logs FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access configuracoes_saas" ON public.configuracoes_saas;
CREATE POLICY "Public access configuracoes_saas" ON public.configuracoes_saas FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access avisos_globais" ON public.avisos_globais;
CREATE POLICY "Public access avisos_globais" ON public.avisos_globais FOR ALL USING (true) WITH CHECK (true);

-- ==============================================================================
-- DADOS INICIAIS DE EXEMPLO (DEMO LOJA, CATEGORIAS, PRODUTOS E PLANO)
-- ==============================================================================
INSERT INTO public.lojas (
  id, nome, nome_loja, slug, whatsapp, telefone_whatsapp, email, senha, cidade, status_conta, aberto, taxa_base_entrega, valor_por_km, cor_tema, cor_primaria, logo_url
) VALUES (
  'a0000000-0000-0000-0000-000000000001',
  'Armonix Burger & Grill',
  'Armonix Burger & Grill',
  'armonix-burger',
  '11999998888',
  '11999998888',
  'contato@armonixburger.com',
  '123456',
  'Campo Grande, MS',
  'ativa',
  TRUE,
  5.00,
  1.50,
  '#DC2626',
  '#DC2626',
  'https://images.unsplash.com/photo-1550547660-d9450f859349?w=200&auto=format&fit=crop&q=80'
) ON CONFLICT (slug) DO NOTHING;

INSERT INTO public.saas_assinaturas (
  loja_id, status, plano, valor, data_vencimento, dias_teste
) VALUES (
  'a0000000-0000-0000-0000-000000000001',
  'ativa',
  'mensal',
  169.99,
  NOW() + INTERVAL '30 days',
  7
) ON CONFLICT DO NOTHING;

INSERT INTO public.categorias (
  id, loja_id, nome, ordem, ativa, icone
) VALUES
  ('b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000001', 'Burgers Especiais', 1, TRUE, 'Utensils'),
  ('b0000000-0000-0000-0000-000000000002', 'a0000000-0000-0000-0000-000000000001', 'Porções & Entradas', 2, TRUE, 'Flame'),
  ('b0000000-0000-0000-0000-000000000003', 'a0000000-0000-0000-0000-000000000001', 'Bebidas Geladas', 3, TRUE, 'Beer')
ON CONFLICT DO NOTHING;

INSERT INTO public.produtos (
  loja_id, categoria_id, nome, descricao, preco, preco_promocional, destaque_oferta, destaque_mais_pedido, ativo, disponivel, imagem_url
) VALUES
  ('a0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', 'Smash Burger Gran Angus', 'Pão brioche selado, 2 carnes Angus smash 90g, queijo cheddar inglês derretido e maionese artesanal.', 34.90, 29.90, TRUE, TRUE, TRUE, TRUE, 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80'),
  ('a0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000002', 'Batata Rústica Alecrim & Queijo', 'Batatas rústicas crocantes temperadas com sal marinho, alecrim fresco e lascas de parmesão.', 24.90, NULL, FALSE, TRUE, TRUE, TRUE, 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=600&auto=format&fit=crop&q=80'),
  ('a0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000003', 'Coca-Cola Zero Lata 350ml', 'Refrigerante gelado para acompanhar seu lanche.', 6.50, NULL, FALSE, FALSE, TRUE, TRUE, 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=600&auto=format&fit=crop&q=80')
ON CONFLICT DO NOTHING;

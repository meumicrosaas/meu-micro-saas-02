export type StoreStatus = 'ativa' | 'bloqueada' | 'em_teste';
export type SubscriptionStatus = 'ativa' | 'pendente' | 'bloqueada';
export type OrderStatus = 'pendente' | 'em_preparo' | 'saiu_entrega' | 'finalizado' | 'cancelado';
export type PaymentStatus = 'pendente' | 'pago' | 'reembolsado' | 'cancelado';
export type PaymentMethod = 'pix_online' | 'cartao_online' | 'dinheiro' | 'maquininha';
export type DeliveryType = 'retirada' | 'delivery';

export type PrinterWidth = '80mm' | '58mm';
export type PrinterFontSize = 'pequena' | 'normal' | 'grande';

export interface PrinterConfig {
  largura: PrinterWidth;
  fonte: PrinterFontSize;
  vias: number;
  autoImprimir: boolean;
  espacoCorte?: number;
  rodapeTexto?: string;
  imprimirObservacoesDestaque?: boolean;
}

export interface TaxaBairro {
  id: string;
  bairro: string;
  taxa: number;
}

export interface FaixaRaioEntrega {
  id: string;
  de_km: number;
  ate_km: number;
  valor: number;
  tempo_estimado_min?: string;
}

export type ModeloCalculoEntrega = 'raio_km' | 'distancia_km' | 'bairros';

export interface Loja {
  id: string;
  user_id?: string;
  owner_id?: string;
  nome_loja: string;
  nome?: string;
  slug: string;
  telefone_whatsapp: string;
  whatsapp?: string;
  cidade?: string;
  endereco_origem: {
    lat: number;
    lng: number;
    endereco_texto?: string;
  };
  chave_pix?: string;
  mercadopago_access_token?: string;
  abacatepay_api_key?: string;
  taxa_base_entrega: number;
  valor_por_km: number;
  taxas_bairros?: TaxaBairro[];
  modelo_calculo_entrega?: ModeloCalculoEntrega;
  raios_entrega?: FaixaRaioEntrega[];
  raio_maximo_km?: number;
  valor_km_excedente?: number;
  valor_pedido_frete_gratis?: number;
  status_conta: StoreStatus;
  email?: string;
  senha?: string;
  logo_url?: string;
  cor_primaria?: string;
  aberto: boolean;
  created_at: string;
  impressora_largura?: PrinterWidth;
  impressora_fonte?: PrinterFontSize;
  impressora_vias?: number;
  impressora_auto_imprimir?: boolean;
  impressora_espaco_corte?: number;
  impressora_rodape_texto?: string;
  banner_oferta?: BannerOfertaConfig;
  segmento?: string;
}

export interface BannerOfertaConfig {
  ativo: boolean;
  produto_id?: string;
  titulo?: string;
  descricao?: string;
  badge_texto?: string;
  imagem_url?: string;
}

export interface SupabaseConfig {
  url: string;
  anonKey: string;
  serviceRoleKey?: string;
  lastTested?: string;
  status?: 'connected' | 'error' | 'unconfigured';
}

export interface SaasAssinatura {
  id: string;
  loja_id: string;
  status: SubscriptionStatus;
  plano: 'mensal';
  valor: number;
  data_vencimento: string;
  ultimo_pagamento?: string;
  dias_teste?: number;
  created_at: string;
}

export interface Categoria {
  id: string;
  loja_id: string;
  store_id?: string;
  nome: string;
  ordem: number;
  ativa?: boolean;
  ativo?: boolean;
  icone?: string;
  created_at: string;
}

export interface OpcionalProduto {
  id: string;
  produto_id?: string;
  nome_opcao: string;
  preco_adicional: number;
  obrigatorio: boolean;
}

export interface Produto {
  id: string;
  loja_id: string;
  store_id?: string;
  categoria_id: string;
  nome: string;
  descricao: string;
  preco: number;
  preco_promocional?: number;
  preco_original?: number | string;
  imagem?: string;
  imagem_url?: string;
  destaque_oferta?: boolean;
  destaque_mais_pedido?: boolean;
  ativo?: boolean;
  disponivel: boolean;
  opcionais?: OpcionalProduto[];
  created_at: string;
}

export interface Cliente {
  id: string;
  loja_id: string;
  nome: string;
  telefone: string;
  endereco: string;
  numero?: string;
  complemento?: string;
  bairro?: string;
  created_at: string;
}

export interface ItemPedidoOpcional {
  nome_opcao: string;
  preco_adicional: number;
}

export interface ItemPedido {
  id: string;
  pedido_id: string;
  produto_id: string;
  produto_nome: string;
  quantidade: number;
  preco_unitario: number;
  observacao?: string;
  opcionais: ItemPedidoOpcional[];
  total_item: number;
}

export interface Pedido {
  id: string;
  loja_id: string;
  codigo_pedido: string;
  cliente_nome: string;
  cliente_telefone: string;
  tipo_entrega: DeliveryType;
  endereco_destino?: string;
  endereco_completo?: string;
  distancia_km?: number;
  taxa_entrega: number;
  subtotal: number;
  total: number;
  status: OrderStatus;
  status_pagamento: PaymentStatus;
  metodo_pagamento: PaymentMethod;
  forma_pagamento?: string;
  troco_para?: number;
  impresso: boolean;
  pix_copia_cola?: string;
  pix_qrcode_url?: string;
  gateway_transacao_id?: string;
  created_at: string;
  itens: ItemPedido[];
}

export interface SaasPaymentLog {
  id: string;
  loja_id: string;
  loja_nome: string;
  valor: number;
  metodo: 'pix' | 'boleto' | 'cartao';
  gateway: 'mercadopago' | 'abacatepay';
  status: 'confirmado' | 'pendente';
  data_pagamento: string;
  comprovante_id: string;
}

export interface StorageMetrics {
  db_size_bytes: number;
  db_size_mb: number;
  db_limit_mb: number;
  photos_size_mb: number;
  photos_limit_mb: number;
  total_pedidos: number;
  pedidos_antigos_elegiveis: number;
}

export type AvisoTipo = 'informativo' | 'alerta' | 'promocao';

export interface AvisoGlobal {
  id: string;
  titulo: string;
  mensagem: string;
  tipo: AvisoTipo;
  ativo: boolean;
  data_criacao: string;
}

export type TipoChavePix = 'cpf' | 'cnpj' | 'email' | 'telefone' | 'aleatoria';

export interface SaasPlanSettings {
  dias_teste_padrao: number;
  renovacao_antecipada_dias: number;
  renovacao_antecipada_desconto_percentual: number;
  valor_mensal_padrao?: number;
  pix_tipo_chave?: TipoChavePix;
  pix_chave?: string;
  pix_titular?: string;
  pix_banco?: string;
  mercadopago_access_token?: string;
  abacatepay_api_key?: string;
}

export interface SaasBranding {
  logo_url?: string;
  banner_url?: string;
  nome_marca?: string;
  subtitulo?: string;
  titulo_principal?: string;
  badge_destaque?: string;
  cor_primaria?: string;
  imagem_hero?: string;
  texto_chamada?: string;
  texto_botao?: string;
  imagens_vitrine?: Record<string, string>;
}

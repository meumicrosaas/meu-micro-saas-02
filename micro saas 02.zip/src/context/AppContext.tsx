import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Loja, TaxaBairro } from '../types';
import { AppStorage, DEFAULT_CLEAN_TENANT } from '../lib/storage';
import { dataService } from '../lib/dataService';

export interface AppContextType {
  tenants: Loja[];
  activeTenant: Loja | null;
  activeTenantId: string | null;
  setActiveTenantId: (id: string) => void;
  createTenant: (tenantData: Partial<Loja>) => Promise<Loja>;
  updateTenant: (id: string, updates: Partial<Loja>) => Promise<void>;
  deleteTenant: (idOrSlug: string) => Promise<boolean>;
  updateFreight: (
    tenantId: string,
    config: {
      taxa_base_entrega: number;
      valor_por_km: number;
      endereco_origem: any;
      taxas_por_bairro?: TaxaBairro[];
    }
  ) => void;
  refreshData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [tenants, setTenants] = useState<Loja[]>(() => {
    try {
      const direct = localStorage.getItem('delivery_saas_tenants');
      if (direct) {
        const parsed = JSON.parse(direct);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {}
    const fromStorage = AppStorage.getLojas();
    if (fromStorage && fromStorage.length > 0) return fromStorage;
    return [DEFAULT_CLEAN_TENANT];
  });

  const [activeTenantId, setActiveTenantIdState] = useState<string | null>(() => {
    try {
      const stored =
        localStorage.getItem('activeTenantId') ||
        localStorage.getItem('delivery_saas_loja_ativa_id');
      if (stored) return stored;
    } catch {}
    return AppStorage.getActiveLojaId();
  });

  const setActiveTenantId = useCallback((id: string) => {
    setActiveTenantIdState(id);
    AppStorage.setActiveLojaId(id);
    try {
      localStorage.setItem('activeTenantId', id);
    } catch {}
  }, []);

  const refreshData = useCallback(() => {
    const freshLojas = AppStorage.getLojas();
    setTenants(freshLojas);
    try {
      localStorage.setItem('delivery_saas_tenants', JSON.stringify(freshLojas));
    } catch {}
    const freshActiveId =
      localStorage.getItem('activeTenantId') ||
      localStorage.getItem('delivery_saas_loja_ativa_id') ||
      AppStorage.getActiveLojaId();
    if (freshActiveId && freshLojas.some((l) => l.id === freshActiveId)) {
      setActiveTenantIdState(freshActiveId);
    } else if (freshLojas.length > 0) {
      setActiveTenantIdState(freshLojas[0].id);
      AppStorage.setActiveLojaId(freshLojas[0].id);
    } else {
      setActiveTenantIdState(null);
    }
  }, []);

  const createTenant = useCallback(
    async (tenantData: Partial<Loja>): Promise<Loja> => {
      const novaLoja = await dataService.createTenant(tenantData);
      const novasLojas = AppStorage.getLojas();
      setTenants(novasLojas);
      try {
        localStorage.setItem('delivery_saas_tenants', JSON.stringify(novasLojas));
      } catch {}
      setActiveTenantId(novaLoja.id);
      return novaLoja;
    },
    [setActiveTenantId]
  );

  const updateTenant = useCallback(
    async (id: string, updates: Partial<Loja>): Promise<void> => {
      await dataService.updateTenant(id, updates);
      const atualizadas = AppStorage.getLojas();
      setTenants(atualizadas);
      try {
        localStorage.setItem('delivery_saas_tenants', JSON.stringify(atualizadas));
      } catch {}
    },
    []
  );

  const deleteTenant = useCallback(
    async (idOrSlug: string): Promise<boolean> => {
      const ok = await dataService.deleteTenant(idOrSlug);
      const restantes = AppStorage.getLojas();
      setTenants(restantes);
      try {
        localStorage.setItem('delivery_saas_tenants', JSON.stringify(restantes));
      } catch {}

      const currentActive =
        localStorage.getItem('activeTenantId') ||
        localStorage.getItem('delivery_saas_loja_ativa_id');
      if (currentActive === idOrSlug || !restantes.some((l) => l.id === currentActive)) {
        if (restantes.length > 0) {
          setActiveTenantId(restantes[0].id);
        } else {
          setActiveTenantIdState(null);
          localStorage.removeItem('activeTenantId');
          localStorage.removeItem('delivery_saas_loja_ativa_id');
        }
      }
      return ok;
    },
    [setActiveTenantId]
  );

  const updateFreight = useCallback(
    (
      tenantId: string,
      config: {
        taxa_base_entrega: number;
        valor_por_km: number;
        endereco_origem: any;
        taxas_por_bairro?: TaxaBairro[];
      }
    ) => {
      AppStorage.updateLoja(tenantId, config);
      const atualizadas = AppStorage.getLojas();
      setTenants(atualizadas);
      try {
        localStorage.setItem('delivery_saas_tenants', JSON.stringify(atualizadas));
      } catch {}
    },
    []
  );

  useEffect(() => {
    let isMounted = true;
    dataService
      .getTenants()
      .then((loaded) => {
        if (!isMounted) return;
        if (loaded && loaded.length > 0) {
          setTenants(loaded);
          try {
            localStorage.setItem('delivery_saas_tenants', JSON.stringify(loaded));
          } catch {}
        }
      })
      .catch((err) => {
        console.warn('Erro ao carregar lojas do Supabase no AppProvider:', err);
      });
    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    const handleStorageChange = () => {
      refreshData();
    };
    window.addEventListener('app_storage_change', handleStorageChange);
    window.addEventListener('loja_cadastrada', handleStorageChange);
    window.addEventListener('loja_excluida', handleStorageChange);
    window.addEventListener('loja_atualizada', handleStorageChange);
    window.addEventListener('loja_ativa_alterada', handleStorageChange);
    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener('app_storage_change', handleStorageChange);
      window.removeEventListener('loja_cadastrada', handleStorageChange);
      window.removeEventListener('loja_excluida', handleStorageChange);
      window.removeEventListener('loja_atualizada', handleStorageChange);
      window.removeEventListener('loja_ativa_alterada', handleStorageChange);
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [refreshData]);

  const activeTenant =
    (activeTenantId ? tenants.find((t) => t.id === activeTenantId) : null) ||
    tenants[0] ||
    null;

  return (
    <AppContext.Provider
      value={{
        tenants,
        activeTenant,
        activeTenantId,
        setActiveTenantId,
        createTenant,
        updateTenant,
        deleteTenant,
        updateFreight,
        refreshData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp deve ser utilizado dentro de um AppProvider');
  }
  return context;
}

import { useState, useEffect } from 'react';
import {
  ShieldCheck,
  ExternalLink,
  Lock,
  Moon,
  Sun,
  KeyRound,
  ArrowRight,
  Eye,
  EyeOff,
  AlertCircle,
  LogOut,
  User,
} from 'lucide-react';
import SuperAdminPanel from './components/SuperAdmin/SuperAdminPanel';
import MerchantDashboard from './components/MerchantAdmin/MerchantDashboard';
import CardapioClienteView from './components/CustomerStore/CardapioClienteView';
import SignupForm from './components/Signup/SignupForm';
import AssinaturaPendente from './components/Subscription/AssinaturaPendente';
import { AppStorage } from './lib/storage';
import { DataService } from './lib/supabase';
import StoreLogoAvatar from './components/Common/StoreLogoAvatar';
import TermosDeUsoView from './components/Common/TermosDeUsoView';
import { Loja } from './types';
import { AppProvider, useApp } from './context/AppContext';

type ActiveRoute =
  | { view: 'super-admin' }
  | { view: 'admin'; lojaId?: string }
  | { view: 'loja'; slug: string }
  | { view: 'cadastro' }
  | { view: 'assinatura-pendente'; lojaId?: string }
  | { view: 'termos-de-uso' };

function parseRouteFromUrl(): ActiveRoute {
  if (typeof window === 'undefined') return { view: 'admin' };

  let path = window.location.pathname || '/';

  // Fallback para hash routing se acessado como /#/loja/mercado-oficial
  if ((path === '/' || path === '/index.html') && window.location.hash) {
    const hashPart = window.location.hash.replace(/^#\/?/, '/');
    if (
      hashPart.startsWith('/loja/') ||
      hashPart.startsWith('/admin') ||
      hashPart === '/cadastro' ||
      hashPart === '/super-admin' ||
      hashPart === '/termos-de-uso'
    ) {
      path = hashPart;
    }
  }

  const cleanPath = path.split('?')[0].split('#')[0];

  if (cleanPath.startsWith('/loja/')) {
    const rawSlug = cleanPath.slice('/loja/'.length).replace(/\/+$/, '');
    const decodedSlug = decodeURIComponent(rawSlug).trim();
    return { view: 'loja', slug: decodedSlug };
  }

  const normalized = cleanPath.replace(/\/+$/, '') || '/';
  if (normalized === '/admin') return { view: 'admin' };
  if (normalized === '/cadastro') return { view: 'cadastro' };
  if (normalized === '/termos-de-uso') return { view: 'termos-de-uso' };
  if (normalized === '/admin/assinatura-pendente') return { view: 'assinatura-pendente' };
  if (normalized === '/super-admin') return { view: 'super-admin' };

  return { view: 'admin' };
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

function AppContent() {
  const {
    tenants,
    activeTenant,
    activeTenantId,
    setActiveTenantId,
    refreshData,
  } = useApp();

  const [route, setRoute] = useState<ActiveRoute>(() => parseRouteFromUrl());

  const [isDark, setIsDark] = useState(false);
  const [selectedSuperAdminLoja, setSelectedSuperAdminLoja] = useState<Loja | null>(null);
  const [branding, setBranding] = useState(() => AppStorage.getSaasBranding());

  const [isSuperAdminAuth, setIsSuperAdminAuth] = useState<boolean>(() => {
    return sessionStorage.getItem('superadmin_authenticated') === 'true';
  });
  const [superAdminUser, setSuperAdminUser] = useState('');
  const [superAdminPass, setSuperAdminPass] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [authError, setAuthError] = useState('');

  useEffect(() => {
    const handleBrandingChange = () => setBranding(AppStorage.getSaasBranding());
    window.addEventListener('saas_branding_atualizado', handleBrandingChange);
    DataService.getSaasBranding().then((b) => setBranding(b)).catch(() => {});
    return () => window.removeEventListener('saas_branding_atualizado', handleBrandingChange);
  }, []);

  useEffect(() => {
    const handlePopState = () => {
      setRoute(parseRouteFromUrl());
    };
    window.addEventListener('popstate', handlePopState);
    window.addEventListener('hashchange', handlePopState);
    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('hashchange', handlePopState);
    };
  }, []);

  useEffect(() => {
    const handleStorageChange = () => {
      refreshData();
    };
    window.addEventListener('app_storage_change', handleStorageChange);
    window.addEventListener('merchant_auth_change', handleStorageChange);
    return () => {
      window.removeEventListener('app_storage_change', handleStorageChange);
      window.removeEventListener('merchant_auth_change', handleStorageChange);
    };
  }, [refreshData]);

  useEffect(() => {
    DataService.corrigirSlugsDeTodasAsLojas().catch((err) => {
      console.warn('Erro ao auto-corrigir slugs das lojas:', err);
    });

    const parsed = parseRouteFromUrl();
    if (parsed.view === 'admin') {
      const currentActiveId =
        localStorage.getItem('activeTenantId') ||
        localStorage.getItem('delivery_saas_loja_ativa_id') ||
        activeTenantId;
      setRoute({ view: 'admin', lojaId: currentActiveId || undefined });
    }
  }, [activeTenantId]);

  function navigateTo(newRoute: ActiveRoute) {
    if (newRoute.view !== 'super-admin') {
      setIsSuperAdminAuth(false);
      sessionStorage.removeItem('superadmin_authenticated');
    } else {
      if (sessionStorage.getItem('superadmin_authenticated') === 'true') {
        setIsSuperAdminAuth(true);
      }
    }

    if (newRoute.view === 'loja') {
      const cleanSlug = (newRoute.slug || '').replace(/^\/loja\//, '').replace(/^loja\//, '').replace(/\/$/, '').trim();
      const matchLoja =
        tenants.find((l) => {
          const s = (l.slug || '').toLowerCase().trim();
          const nome = (l.nome_loja || l.nome || '').toLowerCase().trim();
          return (
            s === cleanSlug.toLowerCase() ||
            l.id === cleanSlug ||
            nome === cleanSlug.toLowerCase()
          );
        }) ||
        AppStorage.getLojaBySlug(cleanSlug) ||
        AppStorage.getLojaById(cleanSlug);
      if (matchLoja) {
        setActiveTenantId(matchLoja.id);
      }
    }

    setRoute(newRoute);

    let path = '/';
    if (newRoute.view === 'super-admin') path = '/super-admin';
    if (newRoute.view === 'admin') path = '/admin';
    if (newRoute.view === 'cadastro') path = '/cadastro';
    if (newRoute.view === 'termos-de-uso') path = '/termos-de-uso';
    if (newRoute.view === 'assinatura-pendente') path = '/admin/assinatura-pendente';
    if (newRoute.view === 'loja') path = `/loja/${encodeURIComponent(newRoute.slug)}`;

    try {
      window.history.pushState({}, '', path);
    } catch {}
  }

  function abrirCardapioPublicoNovaGuia(slug: string) {
    const cleanSlug = (slug || '').replace(/^\/loja\//, '').replace(/^loja\//, '').replace(/\/$/, '').trim();
    const url = `${window.location.origin}/loja/${encodeURIComponent(cleanSlug)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  }

  function handleSuperAdminLogin(e: React.FormEvent) {
    e.preventDefault();
    const cleanUser = superAdminUser.trim().toLowerCase();
    const cleanPass = superAdminPass.trim();

    if (cleanUser === 'adileradm' && cleanPass === 'Adiler692233#') {
      setIsSuperAdminAuth(true);
      sessionStorage.setItem('superadmin_authenticated', 'true');
      setAuthError('');
      setSuperAdminUser('');
      setSuperAdminPass('');
    } else {
      setAuthError('Credenciais inválidas. Verifique o usuário e a senha de Super Admin.');
    }
  }

  function handleSuperAdminLogout() {
    setIsSuperAdminAuth(false);
    sessionStorage.removeItem('superadmin_authenticated');
    const targetId = activeTenantId || tenants[0]?.id;
    navigateTo({ view: 'admin', lojaId: targetId });
  }

  const currentLoja =
    (route.view === 'super-admin' ? selectedSuperAdminLoja : null) ||
    (route.view === 'admin' && route.lojaId
      ? tenants.find((t) => t.id === route.lojaId)
      : null) ||
    activeTenant ||
    tenants[0] ||
    null;

  const activeMenuSlug = currentLoja?.slug || activeTenant?.slug || tenants[0]?.slug;

  const isMerchantConnected =
    route.view === 'admin' &&
    Boolean(currentLoja) &&
    AppStorage.getAuthenticatedMerchantLojaId() === currentLoja?.id;

  return (
    <div
      className={
        isDark
          ? 'dark bg-slate-950 text-slate-100 min-h-screen font-sans'
          : 'bg-slate-50 text-slate-900 min-h-screen font-sans'
      }
    >
      {route.view !== 'loja' && (
        <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 sticky top-0 z-40 shadow-xs">
          <div className="max-w-7xl mx-auto px-4 py-2.5 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  const targetId = activeTenantId || tenants[0]?.id;
                  navigateTo({ view: 'admin', lojaId: targetId });
                }}
                className="flex items-center gap-2 text-left cursor-pointer group"
              >
                {branding.logo_url ? (
                  <img
                    src={branding.logo_url}
                    alt="ARMONIX STORE"
                    className="w-8 h-8 rounded-xl object-contain bg-white/10 p-0.5 shadow-xs group-hover:scale-105 transition"
                  />
                ) : (
                  <div className="w-8 h-8 rounded-xl bg-red-600 text-white flex items-center justify-center font-black shadow-xs group-hover:scale-105 transition">
                    A
                  </div>
                )}
                <div>
                  <span className="text-sm font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-1.5">
                    {branding.nome_marca || 'ARMONIX STORE'}
                    <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-sm bg-red-100 dark:bg-red-950 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-900">
                      {route.view === 'super-admin' ? 'SUPER ADMIN' : 'PRO'}
                    </span>
                  </span>
                  <p className="text-[10px] text-slate-400 dark:text-slate-500 font-medium leading-none">
                    {route.view === 'super-admin'
                      ? 'Painel SaaS Global'
                      : branding.subtitulo || 'Plataforma de Delivery Multi-tenant'}
                  </p>
                </div>
              </button>

              {isMerchantConnected && currentLoja && (
                <div className="hidden md:flex items-center gap-2.5 pl-3 border-l border-slate-200 dark:border-slate-800">
                  <StoreLogoAvatar
                    nomeLoja={currentLoja.nome_loja}
                    logoUrl={currentLoja.logo_url}
                    size="sm"
                    className="ring-1 ring-slate-200 dark:ring-slate-700"
                  />
                  <div className="text-left">
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block truncate max-w-[170px]">
                      {currentLoja.nome_loja}
                    </span>
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1 leading-none">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                      Loja Conectada
                    </span>
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              {/* O cardápio público pertence exclusivamente ao lojista autenticado em sua respectiva loja */}
              {isMerchantConnected && activeMenuSlug && (
                <button
                  type="button"
                  onClick={() => abrirCardapioPublicoNovaGuia(activeMenuSlug)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer active:scale-95"
                  title={`Abrir Meu Cardápio Público em Nova Guia (/loja/${activeMenuSlug})`}
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Meu Cardápio Público</span>
                  <span className="sm:hidden">Cardápio</span>
                </button>
              )}

              {route.view === 'super-admin' && isSuperAdminAuth && (
                <button
                  type="button"
                  onClick={handleSuperAdminLogout}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-red-600/10 hover:bg-red-600/20 text-red-600 dark:text-red-400 border border-red-500/20 rounded-xl text-xs font-bold transition cursor-pointer"
                  title="Encerrar Sessão Super Admin"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sair do Super Admin</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => setIsDark(!isDark)}
                className="p-2 text-slate-500 hover:text-slate-800 dark:hover:text-white rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                title="Alternar Tema Claro/Escuro"
              >
                {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </header>
      )}

      <div className={route.view === 'loja' ? '' : 'p-4 sm:p-6 max-w-7xl mx-auto'}>
        {route.view === 'super-admin' && (
          <div>
            {!isSuperAdminAuth ? (
              <div className="min-h-[70vh] flex items-center justify-center p-4">
                <div className="max-w-md w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 shadow-xl space-y-6">
                  <div className="w-12 h-12 rounded-2xl bg-red-600/10 text-red-600 flex items-center justify-center mx-auto border border-red-600/20">
                    <KeyRound className="w-6 h-6" />
                  </div>
                  <div className="text-center space-y-1.5">
                    <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
                      Acesso Restrito Super Admin
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Painel exclusivo do proprietário da plataforma SaaS. Digite seu usuário e senha master para continuar.
                    </p>
                  </div>
                  <form onSubmit={handleSuperAdminLogin} className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Usuário Super Admin:
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          value={superAdminUser}
                          onChange={(e) => setSuperAdminUser(e.target.value)}
                          placeholder="Digite seu usuário..."
                          autoFocus
                          autoCapitalize="none"
                          autoCorrect="off"
                          className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pl-9 pr-3 py-3 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-red-500"
                        />
                        <div className="absolute left-3 top-3.5 text-slate-400">
                          <User className="w-4 h-4" />
                        </div>
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Senha de Acesso:
                      </label>
                      <div className="relative">
                        <input
                          type={showPass ? 'text' : 'password'}
                          value={superAdminPass}
                          onChange={(e) => setSuperAdminPass(e.target.value)}
                          placeholder="Digite sua senha..."
                          className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pl-9 pr-10 py-3 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-red-500"
                        />
                        <div className="absolute left-3 top-3.5 text-slate-400">
                          <KeyRound className="w-4 h-4" />
                        </div>
                        <button
                          type="button"
                          onClick={() => setShowPass(!showPass)}
                          className="absolute right-3 top-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                        >
                          {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                      <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1 flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                        Autenticação restrita ao administrador geral do sistema
                      </p>
                    </div>
                    {authError && (
                      <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-xs flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0" />
                        <span>{authError}</span>
                      </div>
                    )}
                    <button
                      type="submit"
                      className="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-extrabold transition shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <span>Entrar no Painel Master</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                    <div className="pt-2 text-center space-y-2">
                      <button
                        type="button"
                        onClick={() => navigateTo({ view: 'admin' })}
                        className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-white transition cursor-pointer"
                      >
                        ← Voltar ao Painel Lojista
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            ) : (
              <SuperAdminPanel
                onNavigateToStore={(slug) => {
                  const lojaAlvo = tenants.find(
                    (t) => (t.slug || '').toLowerCase().trim() === slug.toLowerCase().trim()
                  );
                  if (lojaAlvo) {
                    setActiveTenantId(lojaAlvo.id);
                    setSelectedSuperAdminLoja(lojaAlvo);
                  }
                  navigateTo({ view: 'loja', slug });
                }}
                onNavigateToAdmin={(lojaId) => {
                  setActiveTenantId(lojaId);
                  AppStorage.setActiveLojaId(lojaId);
                  AppStorage.setAuthenticatedMerchantLojaId(lojaId);
                  const lojaAlvo = tenants.find((t) => t.id === lojaId);
                  if (lojaAlvo) {
                    setSelectedSuperAdminLoja(lojaAlvo);
                  }
                  navigateTo({ view: 'admin', lojaId });
                }}
                onLogoutSuperAdmin={handleSuperAdminLogout}
                onNavigateToCadastro={() => navigateTo({ view: 'cadastro' })}
                onSelectTenant={(loja) => {
                  setSelectedSuperAdminLoja(loja);
                  setActiveTenantId(loja.id);
                }}
              />
            )}
          </div>
        )}

        {route.view === 'admin' && (
          <MerchantDashboard
            currentLojaId={route.lojaId || activeTenantId || undefined}
            onNavigateToPublicStore={(slug) => abrirCardapioPublicoNovaGuia(slug)}
            onNavigateToAssinaturaPendente={() =>
              navigateTo({
                view: 'assinatura-pendente',
                lojaId: route.lojaId || activeTenantId || undefined,
              })
            }
            onNavigateToSuperAdmin={() => navigateTo({ view: 'super-admin' })}
            onNavigateToSignup={() => navigateTo({ view: 'cadastro' })}
            onNavigateTermos={() => navigateTo({ view: 'termos-de-uso' })}
          />
        )}

        {route.view === 'loja' && (
          <CardapioClienteView
            slug={route.slug}
            globalLojas={tenants}
            globalActiveLoja={activeTenant}
            onBackToAdmin={() => {
              const activeId = activeTenantId || tenants[0]?.id;
              navigateTo({ view: 'admin', lojaId: activeId });
            }}
            onNavigateToSignup={() => navigateTo({ view: 'cadastro' })}
          />
        )}

        {route.view === 'cadastro' && (
          <SignupForm
            onSuccess={(lojaId) => {
              setActiveTenantId(lojaId);
              refreshData();
              navigateTo({ view: 'admin', lojaId });
            }}
            onNavigateLogin={() => {
              const activeId = activeTenantId || tenants[0]?.id;
              navigateTo({ view: 'admin', lojaId: activeId });
            }}
            onNavigateTermos={() => navigateTo({ view: 'termos-de-uso' })}
          />
        )}

        {route.view === 'assinatura-pendente' && (
          <AssinaturaPendente
            lojaId={route.lojaId}
            onDesbloqueado={() => navigateTo({ view: 'admin', lojaId: route.lojaId })}
            onVoltarParaSuperAdmin={() => navigateTo({ view: 'super-admin' })}
          />
        )}

        {route.view === 'termos-de-uso' && (
          <TermosDeUsoView onBack={() => navigateTo({ view: 'admin' })} />
        )}
      </div>
    </div>
  );
}

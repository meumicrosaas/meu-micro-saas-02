import { useState } from 'react';
import { Store, Sparkles, ArrowRight, CheckCircle2, Clock, Image as ImageIcon } from 'lucide-react';
import { AppStorage } from '../../lib/storage';
import { DataService } from '../../lib/supabase';
import { sanitizeSlug } from '../../lib/slug';
import StoreLogoUploader from '../Common/StoreLogoUploader';
import { Loja } from '../../types';

interface SignupFormProps {
  onSuccess: (lojaId: string, loja?: Loja) => void;
  onNavigateLogin: () => void;
  onNavigateTermos?: () => void;
}

export default function SignupForm({ onSuccess, onNavigateLogin, onNavigateTermos }: SignupFormProps) {
  const [nomeLoja, setNomeLoja] = useState('');
  const [slug, setSlug] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [logoUrl, setLogoUrl] = useState('');
  const [segmento, setSegmento] = useState('hamburgueria');
  const [aceitouTermos, setAceitouTermos] = useState(false);
  const [erro, setErro] = useState('');
  const [carregando, setCarregando] = useState(false);
  const [branding] = useState(() => AppStorage.getSaasBranding());

  const SEGMENTOS_DISPONIVEIS = [
    { id: 'hamburgueria', label: 'Hamburgueria & Lanches', icon: '🍔', resumo: 'Smash burgers, combos, batatas e refri' },
    { id: 'pizzaria', label: 'Pizzaria & Forno a Lenha', icon: '🍕', resumo: 'Pizzas grandes, bordas recheadas e doces' },
    { id: 'sushi', label: 'Sushi & Comida Japonesa', icon: '🍱', resumo: 'Barcas, temakis, hot rolls e combinados' },
    { id: 'restaurante', label: 'Restaurante & Marmitex', icon: '🍛', resumo: 'Pratos executivos, marmitas e feijoada' },
    { id: 'acaiteria', label: 'Açaiteria & Sorvetes', icon: '🍧', resumo: 'Copos turbinados, barcas e adicionais' },
    { id: 'bebidas', label: 'Bebidas, Adega & Distribuidora', icon: '🍺', resumo: 'Cervejas geladas, destilados e combos' },
    { id: 'doceria', label: 'Doceria & Confeitaria', icon: '🎂', resumo: 'Bolos vulcão, fatias e brigadeiros' },
    { id: 'farmacia', label: 'Farmácia & Cosméticos', icon: '💊', resumo: 'Medicamentos, vitaminas e higiene' },
    { id: 'mercado', label: 'Mercado, Hortifruti & Mercearia', icon: '🛒', resumo: 'Frutas frescas, verduras e despensa' },
    { id: 'petshop', label: 'Pet Shop & Rações', icon: '🐶', resumo: 'Rações premium, petiscos e brinquedos' },
    { id: 'moda', label: 'Moda, Roupas & Acessórios', icon: '👕', resumo: 'Vestuário, calçados e novidades' },
    { id: 'manicure', label: 'Salão, Manicure & Cosméticos', icon: '💅', resumo: 'Esmaltação, maquiagens e beleza' },
    { id: 'outro', label: 'Geral & Outro Negócio', icon: '🏪', resumo: 'Catálogo flexível para qualquer segmento' },
  ];

  function handleNomeChange(e: React.ChangeEvent<HTMLInputElement>) {
    const val = e.target.value;
    setNomeLoja(val);
    const slugSugerido = sanitizeSlug(val);
    setSlug(slugSugerido);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErro('');
    const cleanNome = nomeLoja.trim();
    const cleanSlug = sanitizeSlug(slug || cleanNome);
    const cleanWhatsapp = whatsapp.trim().replace(/\D/g, '');
    const cleanEmail = email.trim().toLowerCase();
    const cleanSenha = senha.trim();

    if (!cleanNome || !cleanSlug || !cleanWhatsapp || !cleanEmail || !cleanSenha) {
      setErro('Por favor, preencha todos os campos obrigatórios.');
      return;
    }
    if (!aceitouTermos) {
      setErro('Você precisa concordar com os Termos de Uso e Política de Privacidade.');
      return;
    }

    setCarregando(true);
    try {
      const res = await DataService.cadastrarNovaLoja({
        nomeLoja: cleanNome,
        slug: cleanSlug,
        whatsapp: cleanWhatsapp,
        email: cleanEmail,
        senha: cleanSenha,
        logo_url: logoUrl.trim(),
        segmento,
      });
      AppStorage.setActiveLojaId(res.loja.id);
      AppStorage.setAuthenticatedMerchantLojaId(res.loja.id);
      onSuccess(res.loja.id, res.loja);
    } catch (err: any) {
      setErro(err.message || 'Erro ao criar sua loja. Tente novamente.');
    } finally {
      setCarregando(false);
    }
  }

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center p-4 text-white">
      <div className="max-w-md w-full space-y-6">
        <div className="text-center space-y-2">
          <div className="flex justify-center mb-1">
            {branding.logo_url ? (
              <img
                src={branding.logo_url}
                alt="ARMONIX STORE"
                className="w-14 h-14 rounded-2xl object-contain bg-white/5 border border-slate-800 p-1 shadow-lg"
              />
            ) : (
              <div className="inline-flex p-3 bg-red-600/10 text-red-500 rounded-2xl border border-red-500/20">
                <Store className="w-8 h-8" />
              </div>
            )}
          </div>
          <h1 className="text-2xl font-black tracking-tight">Crie sua Loja de Delivery</h1>
          <p className="text-xs text-slate-400">
            Comece a vender online na <strong>{branding.nome_marca || 'ARMONIX STORE'}</strong> com cardápio digital próprio.
          </p>
        </div>

        <div className="bg-gradient-to-r from-amber-500/10 via-red-500/10 to-amber-500/10 border border-amber-500/30 rounded-2xl p-3 text-center flex items-center justify-center gap-2">
          <Clock className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-bold text-amber-300">
            {AppStorage.getSaasPlanSettings().dias_teste_padrao} Dias de Teste Grátis
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-5">
          {erro && (
            <div className="p-3 bg-red-500/10 border border-red-500/30 text-red-400 text-xs rounded-xl font-medium">
              {erro}
            </div>
          )}
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Nome do Estabelecimento *
              </label>
              <input
                type="text"
                required
                placeholder="Ex: Pizzaria Forno Nobre"
                value={nomeLoja}
                onChange={handleNomeChange}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Tipo de Loja / Segmento *
              </label>
              <p className="text-[11px] text-slate-400 mb-2">
                Selecione o ramo do seu negócio para gerarmos categorias e produtos sob medida:
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto p-1 border border-slate-800 rounded-xl bg-slate-950/60">
                {SEGMENTOS_DISPONIVEIS.map((s) => {
                  const isSelected = segmento === s.id;
                  return (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => setSegmento(s.id)}
                      className={`p-2.5 rounded-xl border text-left transition flex items-center gap-2 cursor-pointer ${
                        isSelected
                          ? 'border-red-500 bg-red-600/20 text-white font-bold ring-1 ring-red-500'
                          : 'border-slate-800 bg-slate-900/60 text-slate-300 hover:border-slate-700 hover:bg-slate-800/80'
                      }`}
                    >
                      <span className="text-base">{s.icon}</span>
                      <span className="text-[11px] leading-tight truncate">{s.label}</span>
                    </button>
                  );
                })}
              </div>
              <div className="mt-2.5 p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px] flex items-center justify-between text-slate-300">
                <div className="flex items-center gap-2">
                  <span className="text-xl">{SEGMENTOS_DISPONIVEIS.find((s) => s.id === segmento)?.icon}</span>
                  <div>
                    <span className="font-bold text-white block">{SEGMENTOS_DISPONIVEIS.find((s) => s.id === segmento)?.label}</span>
                    <span className="text-slate-400 text-[10px]">{SEGMENTOS_DISPONIVEIS.find((s) => s.id === segmento)?.resumo}</span>
                  </div>
                </div>
                <span className="text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20 text-[10px] shrink-0">
                  Cardápio Sob Medida
                </span>
              </div>
            </div>

            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Link da Loja (Slug) *
              </label>
              <div className="flex items-center bg-slate-950 border border-slate-700 rounded-xl overflow-hidden focus-within:border-red-500">
                <span className="text-slate-500 pl-3 pr-1 text-[11px] font-mono">/loja/</span>
                <input
                  type="text"
                  required
                  placeholder="pizzaria-forno-nobre"
                  value={slug}
                  onChange={(e) => setSlug(e.target.value.toLowerCase().replace(/[\s_]+/g, '-').replace(/[^a-z0-9-]/g, ''))}
                  className="w-full bg-transparent p-3 text-white font-mono text-xs focus:outline-none"
                />
              </div>
            </div>
            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                WhatsApp de Atendimento *
              </label>
              <input
                type="text"
                required
                placeholder="11999999999 (com DDD)"
                value={whatsapp}
                onChange={(e) => setWhatsapp(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-red-500"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                E-mail de Acesso *
              </label>
              <input
                type="email"
                required
                placeholder="contato@seuestabelecimento.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-red-500"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Senha de Acesso *
              </label>
              <input
                type="password"
                required
                placeholder="Mínimo de 6 caracteres"
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-red-500"
              />
            </div>
            <div className="pt-2 border-t border-slate-800 space-y-2">
              <label className="font-semibold text-slate-300 block flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-red-500" />
                <span>Logomarca da Loja (Opcional)</span>
              </label>
              <StoreLogoUploader
                nomeLoja={nomeLoja || 'Sua Nova Loja'}
                logoUrl={logoUrl}
                onChange={(url) => setLogoUrl(url)}
              />
            </div>
            <div className="pt-2 border-t border-slate-800">
              <label className="flex items-start gap-2.5 cursor-pointer text-slate-300 text-xs">
                <input
                  type="checkbox"
                  required
                  checked={aceitouTermos}
                  onChange={(e) => setAceitouTermos(e.target.checked)}
                  className="mt-0.5 rounded border-slate-700 bg-slate-950 text-red-600 focus:ring-red-500 w-4 h-4 cursor-pointer shrink-0"
                />
                <span className="leading-tight text-[11px] text-slate-400">
                  Li e concordo com os{' '}
                  <button
                    type="button"
                    onClick={onNavigateTermos}
                    className="text-red-400 hover:text-red-300 font-bold underline inline cursor-pointer"
                  >
                    Termos de Uso e Política de Privacidade
                  </button>.
                </span>
              </label>
            </div>
            <button
              type="submit"
              disabled={carregando}
              className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3.5 rounded-xl transition shadow-lg flex items-center justify-center gap-2 text-xs disabled:opacity-50 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              {carregando ? 'Criando sua loja...' : 'Criar Minha Loja Grátis'}
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
          <div className="pt-2 text-center text-xs text-slate-400">
            Já tem uma conta?{' '}
            <button
              type="button"
              onClick={onNavigateLogin}
              className="text-red-400 font-bold hover:underline cursor-pointer"
            >
              Fazer Login
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

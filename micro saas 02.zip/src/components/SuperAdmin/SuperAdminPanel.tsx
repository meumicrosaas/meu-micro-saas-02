import { useState, useEffect } from 'react';
import {
  Store,
  ShieldCheck,
  TrendingUp,
  HardDrive,
  CheckCircle2,
  Trash2,
  Clock,
  ExternalLink,
  DollarSign,
  UserCheck,
  Ban,
  CalendarPlus,
  RefreshCw,
  Search,
  Sparkles,
  Database,
  LogOut,
  Megaphone,
  Sliders,
  UserPlus,
  Copy,
  Check,
  X,
  Palette,
  Edit3,
  KeyRound,
  Plus,
  Eye,
  EyeOff,
  Phone,
  Mail,
  Tag,
  CreditCard,
} from 'lucide-react';
import { AppStorage } from '../../lib/storage';
import { DataService } from '../../lib/supabase';
import { sanitizeSlug } from '../../lib/slug';
import { Loja, SaasAssinatura, StorageMetrics, SaasPaymentLog } from '../../types';
import SupabaseConfigManager from './SupabaseConfigManager';
import MuralAvisosManager from './MuralAvisosManager';
import SaasPlanSettingsManager from './SaasPlanSettingsManager';
import TelaInicialDesignManager from './TelaInicialDesignManager';
import StoreLogoAvatar from '../Common/StoreLogoAvatar';

interface SuperAdminPanelProps {
  onNavigateToStore: (slug: string) => void;
  onNavigateToAdmin: (lojaId: string) => void;
  onLogoutSuperAdmin?: () => void;
  onNavigateToCadastro?: () => void;
  onSelectTenant?: (loja: Loja) => void;
}

export default function SuperAdminPanel({
  onNavigateToStore,
  onNavigateToAdmin,
  onLogoutSuperAdmin,
  onNavigateToCadastro,
  onSelectTenant,
}: SuperAdminPanelProps) {
  const [abaAtiva, setAbaAtiva] = useState<
    'visao_geral' | 'tela_inicial' | 'avisos' | 'planos' | 'supabase'
  >('visao_geral');
  const [modalOnboarding, setModalOnboarding] = useState(false);
  const [copiadoLink, setCopiadoLink] = useState(false);
  const [lojas, setLojas] = useState<Loja[]>([]);
  const [assinaturas, setAssinaturas] = useState<SaasAssinatura[]>([]);
  const [metrics, setMetrics] = useState<StorageMetrics>(AppStorage.getMetrics());
  const [pagamentos, setPagamentos] = useState<SaasPaymentLog[]>([]);
  const [filtroStatus, setFiltroStatus] = useState<'Todas' | 'Em Teste' | 'Ativas' | 'Bloqueadas'>('Todas');
  const [busca, setBusca] = useState('');
  const [feedbackMsg, setFeedbackMsg] = useState<{ tipo: 'sucesso' | 'erro'; texto: string } | null>(null);

  const [modalPreco, setModalPreco] = useState<{ aberto: boolean; lojaId: string; nome: string; valorAtual: number } | null>(null);
  const [novoValorInput, setNovoValorInput] = useState<string>('');

  const [modalEditarTeste, setModalEditarTeste] = useState<{
    aberto: boolean;
    lojaId: string;
    nomeLoja: string;
    diasAtuais: number;
    dataVencimento?: string;
  } | null>(null);
  const [novosDiasTesteInput, setNovosDiasTesteInput] = useState<string>('7');

  const [modalExcluir, setModalExcluir] = useState<{
    aberto: boolean;
    lojaId: string;
    nomeLoja: string;
  } | null>(null);

  // Modal Master: Editar Dados Completos da Loja / Tenant (Controle Total)
  const [modalEditarTenant, setModalEditarTenant] = useState<{
    aberto: boolean;
    loja: Loja;
    assinatura?: SaasAssinatura;
  } | null>(null);
  const [formTenantNome, setFormTenantNome] = useState('');
  const [formTenantSlug, setFormTenantSlug] = useState('');
  const [formTenantSegmento, setFormTenantSegmento] = useState('hamburgueria');
  const [formTenantTelefone, setFormTenantTelefone] = useState('');
  const [formTenantEmail, setFormTenantEmail] = useState('');
  const [formTenantSenha, setFormTenantSenha] = useState('');
  const [formTenantMostrarSenha, setFormTenantMostrarSenha] = useState(false);
  const [formTenantValorMensal, setFormTenantValorMensal] = useState('169.99');
  const [formTenantDiasTeste, setFormTenantDiasTeste] = useState('7');
  const [formTenantStatus, setFormTenantStatus] = useState<'ativa' | 'bloqueada'>('ativa');
  const [formTenantChavePix, setFormTenantChavePix] = useState('');
  const [formTenantLogoUrl, setFormTenantLogoUrl] = useState('');
  const [salvandoTenant, setSalvandoTenant] = useState(false);

  // Modal Criar Nova Loja Direto pelo Super Admin
  const [modalCriarLoja, setModalCriarLoja] = useState(false);
  const [novaLojaNome, setNovaLojaNome] = useState('');
  const [novaLojaSlug, setNovaLojaSlug] = useState('');
  const [novaLojaSegmento, setNovaLojaSegmento] = useState('hamburgueria');
  const [novaLojaTelefone, setNovaLojaTelefone] = useState('');
  const [novaLojaEmail, setNovaLojaEmail] = useState('');
  const [novaLojaSenha, setNovaLojaSenha] = useState('123456');
  const [novaLojaDiasTeste, setNovaLojaDiasTeste] = useState('7');
  const [novaLojaValorMensal, setNovaLojaValorMensal] = useState('169.99');
  const [criandoLoja, setCriandoLoja] = useState(false);

  useEffect(() => {
    carregarDados();
    const handleStorage = () => carregarDados();
    window.addEventListener('app_storage_change', handleStorage);
    return () => {
      window.removeEventListener('app_storage_change', handleStorage);
    };
  }, []);

  function carregarDados() {
    setLojas(AppStorage.getLojas());
    setAssinaturas(AppStorage.getAssinaturas());
    setMetrics(AppStorage.getMetrics());
    setPagamentos(AppStorage.getPagamentosSaas());
  }

  function mostrarFeedback(texto: string, tipo: 'sucesso' | 'erro' = 'sucesso') {
    setFeedbackMsg({ texto, tipo });
    setTimeout(() => setFeedbackMsg(null), 4000);
  }

  async function handleConfirmarExclusaoLoja() {
    if (!modalExcluir) return;
    const { lojaId, nomeLoja } = modalExcluir;
    setModalExcluir(null);

    const sucessoLocal = AppStorage.deleteLoja(lojaId);
    carregarDados();
    try {
      await DataService.deleteLoja(lojaId);
    } catch {}

    if (sucessoLocal) {
      mostrarFeedback(`A loja "${nomeLoja}" foi excluída permanentemente.`, 'sucesso');
    } else {
      mostrarFeedback('Não foi possível excluir a loja.', 'erro');
    }
  }

  const totalLojas = lojas.length;
  const lojasIds = new Set(lojas.map((l) => l.id));
  const assinaturasValidas = assinaturas.filter((a) => lojasIds.has(a.loja_id));
  const lojasEmTeste = assinaturasValidas.filter((a) => a.dias_teste && a.dias_teste > 0 && a.status === 'ativa').length;
  const lojasAtivasPagas = assinaturasValidas.filter((a) => (!a.dias_teste || a.dias_teste === 0) && a.status === 'ativa').length;
  const lojasBloqueadas = lojas.filter((l) => l.status_conta === 'bloqueada').length;
  const mrrEstimado = assinaturasValidas
    .filter((a) => a.status === 'ativa')
    .reduce((acc, curr) => acc + (Number(curr.valor) || 169.99), 0);

  const dbPercentual = Math.min(100, Math.round((metrics.db_size_mb / metrics.db_limit_mb) * 100));
  const fotosPercentual = Math.min(100, Math.round((metrics.photos_size_mb / metrics.photos_limit_mb) * 100));

  function handleAdicionarDias(lojaId: string, dias: number) {
    AppStorage.adicionarDiasAssinatura(lojaId, dias);
    carregarDados();
    mostrarFeedback(`+${dias} dias adicionados à loja!`);
  }

  function handleToggleBloqueio(lojaId: string) {
    const agoraAtiva = AppStorage.toggleBloqueioLoja(lojaId);
    carregarDados();
    mostrarFeedback(agoraAtiva ? 'Loja DESBLOQUEADA!' : 'Loja BLOQUEADA!');
  }

  async function handleSalvarNovoValor() {
    if (!modalPreco) return;
    const valor = parseFloat(novoValorInput);
    if (isNaN(valor) || valor <= 0) return;
    AppStorage.atualizarValorMensalidade(modalPreco.lojaId, valor);
    try {
      await DataService.atualizarValorMensalidade(modalPreco.lojaId, valor);
    } catch {}
    setModalPreco(null);
    carregarDados();
    mostrarFeedback(`Valor da mensalidade de "${modalPreco.nome}" atualizado para R$ ${valor.toFixed(2)}!`);
  }

  async function handleSalvarTempoTeste(diasOverride?: number) {
    if (!modalEditarTeste) return;
    const dias = diasOverride !== undefined ? diasOverride : parseInt(novosDiasTesteInput, 10);
    if (isNaN(dias) || dias < 0) return;

    AppStorage.atualizarTempoTesteLoja(modalEditarTeste.lojaId, dias);
    try {
      await DataService.atualizarTempoTesteLoja(modalEditarTeste.lojaId, dias);
    } catch {}

    setModalEditarTeste(null);
    carregarDados();
    if (dias === 0) {
      mostrarFeedback(`Período de teste de "${modalEditarTeste.nomeLoja}" encerrado!`, 'sucesso');
    } else {
      mostrarFeedback(`Tempo de teste de "${modalEditarTeste.nomeLoja}" definido para ${dias} dias!`, 'sucesso');
    }
  }

  function handleSimularWebhook(lojaId: string) {
    const res = AppStorage.processarWebhookPagamentoSaas(lojaId, 'mercadopago', `SIM-${Date.now().toString().slice(-6)}`);
    carregarDados();
    mostrarFeedback(res.mensagem);
  }

  function abrirModalEditarTenant(loja: Loja, ass?: SaasAssinatura) {
    setModalEditarTenant({
      aberto: true,
      loja,
      assinatura: ass,
    });
    setFormTenantNome(loja.nome_loja || loja.nome || '');
    setFormTenantSlug(loja.slug || '');
    setFormTenantSegmento(loja.segmento || 'hamburgueria');
    setFormTenantTelefone(loja.telefone_whatsapp || loja.whatsapp || '');
    setFormTenantEmail((loja as any).email || (loja as any).email_loja || '');
    setFormTenantSenha((loja as any).senha || (loja as any).senha_lojista || '');
    setFormTenantMostrarSenha(false);
    setFormTenantValorMensal((ass?.valor || 169.99).toString());
    setFormTenantDiasTeste((ass?.dias_teste || 0).toString());
    setFormTenantStatus(loja.status_conta === 'bloqueada' ? 'bloqueada' : 'ativa');
    setFormTenantChavePix(loja.chave_pix || '');
    setFormTenantLogoUrl(loja.logo_url || '');
  }

  async function handleSalvarEdicaoTenant(e: React.FormEvent) {
    e.preventDefault();
    if (!modalEditarTenant) return;
    setSalvandoTenant(true);

    const lojaId = modalEditarTenant.loja.id;
    const cleanNome = formTenantNome.trim();
    const cleanSlug = sanitizeSlug(formTenantSlug || cleanNome);
    const cleanTelefone = formTenantTelefone.trim().replace(/\D/g, '');
    const cleanEmail = formTenantEmail.trim().toLowerCase();
    const cleanSenha = formTenantSenha.trim();
    const valorMensal = parseFloat(formTenantValorMensal) || 169.99;
    const diasTeste = parseInt(formTenantDiasTeste, 10) || 0;

    const updates: Partial<Loja> = {
      nome_loja: cleanNome,
      nome: cleanNome,
      slug: cleanSlug,
      segmento: formTenantSegmento,
      telefone_whatsapp: cleanTelefone,
      whatsapp: cleanTelefone,
      chave_pix: formTenantChavePix.trim(),
      logo_url: formTenantLogoUrl.trim(),
      status_conta: formTenantStatus,
    };
    if (cleanEmail) (updates as any).email = cleanEmail;
    if (cleanSenha) (updates as any).senha = cleanSenha;

    try {
      AppStorage.updateLoja(lojaId, updates);
      AppStorage.atualizarValorMensalidade(lojaId, valorMensal);
      AppStorage.atualizarTempoTesteLoja(lojaId, diasTeste);

      try {
        await DataService.updateLoja(lojaId, updates);
        await DataService.atualizarValorMensalidade(lojaId, valorMensal);
        await DataService.atualizarTempoTesteLoja(lojaId, diasTeste);
      } catch {}

      setModalEditarTenant(null);
      carregarDados();
      mostrarFeedback(`Loja "${cleanNome}" atualizada com sucesso! Todas as alterações foram salvas.`, 'sucesso');
    } catch (err: any) {
      mostrarFeedback('Erro ao salvar edições da loja.', 'erro');
    } finally {
      setSalvandoTenant(false);
    }
  }

  async function handleCriarNovaLojaSuperAdmin(e: React.FormEvent) {
    e.preventDefault();
    const cleanNome = novaLojaNome.trim();
    const cleanSlug = sanitizeSlug(novaLojaSlug || cleanNome);
    const cleanTelefone = novaLojaTelefone.trim().replace(/\D/g, '');
    const cleanEmail = novaLojaEmail.trim().toLowerCase();
    const cleanSenha = novaLojaSenha.trim();
    const diasTeste = parseInt(novaLojaDiasTeste, 10) || 7;
    const valorMensal = parseFloat(novaLojaValorMensal) || 169.99;

    if (!cleanNome || !cleanSlug || !cleanTelefone || !cleanEmail || !cleanSenha) {
      mostrarFeedback('Preencha os campos obrigatórios da nova loja.', 'erro');
      return;
    }

    setCriandoLoja(true);
    try {
      const res = await DataService.cadastrarNovaLoja({
        nomeLoja: cleanNome,
        slug: cleanSlug,
        whatsapp: cleanTelefone,
        email: cleanEmail,
        senha: cleanSenha,
        segmento: novaLojaSegmento,
      });

      if (diasTeste !== 7) {
        AppStorage.atualizarTempoTesteLoja(res.loja.id, diasTeste);
      }
      if (valorMensal !== 169.99) {
        AppStorage.atualizarValorMensalidade(res.loja.id, valorMensal);
      }

      setModalCriarLoja(false);
      setNovaLojaNome('');
      setNovaLojaSlug('');
      setNovaLojaTelefone('');
      setNovaLojaEmail('');
      carregarDados();
      mostrarFeedback(`Nova loja "${cleanNome}" cadastrada com sucesso pelo Super Admin!`, 'sucesso');
    } catch (err: any) {
      mostrarFeedback(err.message || 'Erro ao cadastrar loja.', 'erro');
    } finally {
      setCriandoLoja(false);
    }
  }

  const lojasFiltradas = lojas.filter((loja) => {
    const ass = assinaturas.find((a) => a.loja_id === loja.id);
    const emTeste = Boolean(ass?.dias_teste && ass.dias_teste > 0);
    const ativas = loja.status_conta === 'ativa' && !emTeste;
    const bloqueadas = loja.status_conta === 'bloqueada';
    let matchStatus = true;
    if (filtroStatus === 'Em Teste') matchStatus = emTeste;
    if (filtroStatus === 'Ativas') matchStatus = ativas;
    if (filtroStatus === 'Bloqueadas') matchStatus = bloqueadas;
    const matchBusca =
      loja.nome_loja.toLowerCase().includes(busca.toLowerCase()) ||
      loja.slug.toLowerCase().includes(busca.toLowerCase()) ||
      loja.telefone_whatsapp.includes(busca);
    return matchStatus && matchBusca;
  });

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-red-500/20 text-red-400 text-xs px-2.5 py-0.5 rounded-full font-semibold border border-red-500/30 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" /> ROLE: SUPER_ADMIN
            </span>
          </div>
          <h1 className="text-2xl font-extrabold tracking-tight">Painel Super Admin do Dono do SaaS</h1>
          <p className="text-slate-400 text-sm">
            Gestão de faturamento, infraestrutura Supabase e lojas multi-tenant.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setModalOnboarding(true)}
            className="inline-flex items-center gap-1.5 text-xs bg-red-600 hover:bg-red-700 text-white px-3.5 py-2 rounded-xl transition font-extrabold shadow-md cursor-pointer"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Gerar Link de Cadastro / Criar Nova Loja</span>
          </button>
          <button
            type="button"
            onClick={carregarDados}
            className="inline-flex items-center gap-2 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 px-3.5 py-2 rounded-xl transition border border-slate-700 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Atualizar
          </button>
          {onLogoutSuperAdmin && (
            <button
              type="button"
              onClick={onLogoutSuperAdmin}
              className="inline-flex items-center gap-1.5 text-xs bg-red-600/20 hover:bg-red-600/30 text-red-300 border border-red-500/30 px-3.5 py-2 rounded-xl transition font-bold cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" /> Sair
            </button>
          )}
        </div>
      </div>

      <div className="flex border-b border-slate-800 gap-1 sm:gap-2 pb-px overflow-x-auto">
        <button
          type="button"
          onClick={() => setAbaAtiva('visao_geral')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-bold transition border-b-2 shrink-0 cursor-pointer ${
            abaAtiva === 'visao_geral'
              ? 'border-red-600 text-red-500 bg-slate-900/50 rounded-t-xl'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Store className="w-4 h-4" />
          <span>Visão Geral & Tenants</span>
        </button>
        <button
          type="button"
          onClick={() => setAbaAtiva('tela_inicial')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-bold transition border-b-2 shrink-0 cursor-pointer ${
            abaAtiva === 'tela_inicial'
              ? 'border-red-600 text-red-500 bg-slate-900/50 rounded-t-xl'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Palette className="w-4 h-4" />
          <span>Design & Tela Inicial</span>
        </button>
        <button
          type="button"
          onClick={() => setAbaAtiva('avisos')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-bold transition border-b-2 shrink-0 cursor-pointer ${
            abaAtiva === 'avisos'
              ? 'border-red-600 text-red-500 bg-slate-900/50 rounded-t-xl'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Megaphone className="w-4 h-4" />
          <span>Mural de Avisos Globais</span>
        </button>
        <button
          type="button"
          onClick={() => setAbaAtiva('planos')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-bold transition border-b-2 shrink-0 cursor-pointer ${
            abaAtiva === 'planos'
              ? 'border-red-600 text-red-500 bg-slate-900/50 rounded-t-xl'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>Assinatura & Planos</span>
        </button>
        <button
          type="button"
          onClick={() => setAbaAtiva('supabase')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-bold transition border-b-2 shrink-0 cursor-pointer ${
            abaAtiva === 'supabase'
              ? 'border-red-600 text-red-500 bg-slate-900/50 rounded-t-xl'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Database className="w-4 h-4" />
          <span>Base de Dados & Supabase</span>
        </button>
      </div>

      {feedbackMsg && (
        <div
          className={`p-4 rounded-xl text-sm font-medium flex items-center justify-between border ${
            feedbackMsg.tipo === 'sucesso'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
              : 'bg-red-500/10 border-red-500/30 text-red-400'
          }`}
        >
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5" />
            <span>{feedbackMsg.texto}</span>
          </div>
        </div>
      )}

      {abaAtiva === 'tela_inicial' && <TelaInicialDesignManager />}
      {abaAtiva === 'avisos' && <MuralAvisosManager />}
      {abaAtiva === 'planos' && <SaasPlanSettingsManager />}
      {abaAtiva === 'supabase' && <SupabaseConfigManager />}

      {abaAtiva === 'visao_geral' && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
              <div className="flex justify-between items-center text-slate-400 text-xs font-semibold mb-2">
                <span>TOTAL DE LOJAS</span>
                <Store className="w-4 h-4 text-slate-400" />
              </div>
              <p className="text-3xl font-extrabold text-white">{totalLojas}</p>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
              <div className="flex justify-between items-center text-slate-400 text-xs font-semibold mb-2">
                <span>EM TESTE (TRIAL)</span>
                <Clock className="w-4 h-4 text-amber-400" />
              </div>
              <p className="text-3xl font-extrabold text-amber-400">{lojasEmTeste}</p>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
              <div className="flex justify-between items-center text-slate-400 text-xs font-semibold mb-2">
                <span>ATIVAS (PAGAS)</span>
                <UserCheck className="w-4 h-4 text-emerald-400" />
              </div>
              <p className="text-3xl font-extrabold text-emerald-400">{lojasAtivasPagas}</p>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
              <div className="flex justify-between items-center text-slate-400 text-xs font-semibold mb-2">
                <span>BLOQUEADAS</span>
                <Ban className="w-4 h-4 text-red-400" />
              </div>
              <p className="text-3xl font-extrabold text-red-400">{lojasBloqueadas}</p>
            </div>
            <div className="bg-gradient-to-br from-red-950/40 via-slate-900 to-slate-900 border border-red-500/30 p-5 rounded-2xl">
              <div className="flex justify-between items-center text-red-300 text-xs font-bold mb-2">
                <span>MRR ESTIMADO</span>
                <TrendingUp className="w-4 h-4 text-red-400" />
              </div>
              <p className="text-3xl font-extrabold text-white">R$ {mrrEstimado.toFixed(2)}</p>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
            <div className="flex justify-between items-center border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-blue-500/10 text-blue-400 rounded-xl">
                  <HardDrive className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white flex items-center gap-2">
                    Monitor de Armazenamento Supabase
                  </h2>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-950/60 p-5 rounded-xl border border-slate-800 space-y-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-300">Banco de Dados PostgreSQL (500 MB)</span>
                  <span className="font-mono text-slate-400 font-bold">
                    {metrics.db_size_mb.toFixed(1)} MB / {metrics.db_limit_mb} MB ({dbPercentual}%)
                  </span>
                </div>
                <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden p-0.5">
                  <div
                    className="h-full rounded-full transition-all duration-500 bg-emerald-500"
                    style={{ width: `${dbPercentual}%` }}
                  />
                </div>
              </div>
              <div className="bg-slate-950/60 p-5 rounded-xl border border-slate-800 space-y-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-300">Fotos de Produtos (1 GB Cota)</span>
                  <span className="font-mono text-slate-400 font-bold">
                    {metrics.photos_size_mb.toFixed(1)} MB / {metrics.photos_limit_mb} MB ({fotosPercentual}%)
                  </span>
                </div>
                <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden p-0.5">
                  <div
                    className="h-full rounded-full transition-all duration-500 bg-emerald-500"
                    style={{ width: `${fotosPercentual}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="flex items-center gap-3">
                <h2 className="text-lg font-bold text-white">Tenants & Lojas Cadastradas</h2>
                <button
                  type="button"
                  onClick={() => setModalCriarLoja(true)}
                  className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl transition shadow-md flex items-center gap-1.5 cursor-pointer active:scale-95"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Nova Loja</span>
                </button>
              </div>
              <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
                <div className="relative flex-1 sm:w-64">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="text"
                    placeholder="Buscar por nome, slug..."
                    value={busca}
                    onChange={(e) => setBusca(e.target.value)}
                    className="w-full pl-9 pr-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500"
                  />
                </div>
                <div className="flex bg-slate-800 p-1 rounded-xl text-xs font-medium">
                  {(['Todas', 'Em Teste', 'Ativas', 'Bloqueadas'] as const).map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => setFiltroStatus(st)}
                      className={`px-3 py-1 rounded-lg transition cursor-pointer ${
                        filtroStatus === st
                          ? 'bg-red-600 text-white font-bold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="overflow-x-auto rounded-xl border border-slate-800">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 uppercase font-semibold border-b border-slate-800">
                  <tr>
                    <th className="p-3.5">Loja / Slug</th>
                    <th className="p-3.5">Contato</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5">Valor Mensal</th>
                    <th className="p-3.5 text-right">Ações de Controle Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 bg-slate-900/60">
                  {lojasFiltradas.map((loja) => {
                    const ass = assinaturas.find((a) => a.loja_id === loja.id);
                    return (
                      <tr key={loja.id} className="hover:bg-slate-800/40 transition">
                        <td className="p-3.5">
                          <div className="flex items-center gap-3">
                            <StoreLogoAvatar nomeLoja={loja.nome_loja} logoUrl={loja.logo_url} size="sm" />
                            <div>
                              <div className="font-bold text-white text-sm">{loja.nome_loja}</div>
                              <div className="text-[11px] font-mono text-red-400">/loja/{loja.slug}</div>
                              {loja.segmento && (
                                <span className="text-[10px] text-slate-400 bg-slate-800 px-1.5 py-0.2 rounded font-mono">
                                  {loja.segmento}
                                </span>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="p-3.5 text-slate-400">
                          <div>{loja.telefone_whatsapp}</div>
                          {((loja as any).email || (loja as any).email_loja) && (
                            <div className="text-[11px] text-slate-500 truncate max-w-[150px]">
                              {(loja as any).email || (loja as any).email_loja}
                            </div>
                          )}
                        </td>
                        <td className="p-3.5">
                          {loja.status_conta === 'bloqueada' ? (
                            <span className="inline-flex items-center gap-1 bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded-full font-semibold text-[10px]">
                              <Ban className="w-3 h-3" /> BLOQUEADA
                            </span>
                          ) : ass?.dias_teste && ass.dias_teste > 0 ? (
                            <span className="inline-flex items-center gap-1 bg-amber-500/15 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full font-bold text-[10px]">
                              <Clock className="w-3 h-3 text-amber-400" /> EM TESTE ({ass.dias_teste}d)
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full font-semibold text-[10px]">
                              <CheckCircle2 className="w-3 h-3" /> ATIVA (PAGA)
                            </span>
                          )}
                        </td>
                        <td className="p-3.5 font-bold text-white">
                          <div className="flex items-center gap-2">
                            <span>R$ {(ass?.valor || 169.99).toFixed(2)}</span>
                            <button
                              type="button"
                              onClick={() => {
                                setModalPreco({
                                  aberto: true,
                                  lojaId: loja.id,
                                  nome: loja.nome_loja,
                                  valorAtual: ass?.valor || 169.99,
                                });
                                setNovoValorInput((ass?.valor || 169.99).toString());
                              }}
                              className="p-1 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 rounded-md transition cursor-pointer"
                              title="Alterar valor da mensalidade cobrada deste lojista"
                            >
                              <DollarSign className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                        <td className="p-3.5 text-right space-x-1.5 whitespace-nowrap">
                          {/* Botão Master: Editar Todos os Dados */}
                          <button
                            type="button"
                            onClick={() => abrirModalEditarTenant(loja, ass)}
                            className="p-1.5 bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded-lg transition inline-flex items-center gap-1 text-[11px] font-bold cursor-pointer"
                            title="Editar Dados Completos da Loja, Acesso, Valores e Status"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>Editar Tudo</span>
                          </button>

                          {/* Botão de Editar Tempo de Teste Grátis */}
                          <button
                            type="button"
                            onClick={() => {
                              setModalEditarTeste({
                                aberto: true,
                                lojaId: loja.id,
                                nomeLoja: loja.nome_loja,
                                diasAtuais: ass?.dias_teste || 0,
                                dataVencimento: ass?.data_vencimento,
                              });
                              setNovosDiasTesteInput((ass?.dias_teste || 7).toString());
                            }}
                            className="p-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-lg transition inline-flex items-center gap-1 text-[11px] font-bold cursor-pointer"
                            title="Editar Tempo de Teste Grátis desta Loja"
                          >
                            <Clock className="w-3.5 h-3.5 text-amber-400" />
                            <span>Teste</span>
                          </button>

                          {/* Extensões rápidas de teste */}
                          <button
                            type="button"
                            onClick={() => handleAdicionarDias(loja.id, 7)}
                            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-amber-300 rounded-lg transition inline-flex items-center gap-1 text-[11px] font-semibold cursor-pointer"
                            title="Adicionar +7 dias de teste grátis"
                          >
                            <CalendarPlus className="w-3.5 h-3.5" /> +7d
                          </button>
                          <button
                            type="button"
                            onClick={() => handleAdicionarDias(loja.id, 15)}
                            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-amber-300 rounded-lg transition inline-flex items-center gap-1 text-[11px] font-semibold cursor-pointer"
                            title="Adicionar +15 dias de teste grátis"
                          >
                            +15d
                          </button>

                          {/* Bloquear / Desbloquear */}
                          <button
                            type="button"
                            onClick={() => handleToggleBloqueio(loja.id)}
                            className={`p-1.5 rounded-lg transition inline-flex items-center gap-1 text-[11px] font-semibold cursor-pointer ${
                              loja.status_conta === 'ativa'
                                ? 'bg-red-500/20 hover:bg-red-500/30 text-red-300'
                                : 'bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300'
                            }`}
                            title={loja.status_conta === 'ativa' ? 'Bloquear acesso do lojista' : 'Desbloquear acesso do lojista'}
                          >
                            <Ban className="w-3.5 h-3.5" />
                            {loja.status_conta === 'ativa' ? 'Bloquear' : 'Desbloquear'}
                          </button>

                          {/* Entrar no painel do lojista */}
                          <button
                            type="button"
                            onClick={() => {
                              AppStorage.setActiveLojaId(loja.id);
                              AppStorage.setAuthenticatedMerchantLojaId(loja.id);
                              if (onSelectTenant) onSelectTenant(loja);
                              onNavigateToAdmin(loja.id);
                            }}
                            className="px-2 py-1.5 bg-slate-800 hover:bg-slate-700 text-blue-400 rounded-lg transition inline-flex items-center gap-1 text-[11px] font-semibold cursor-pointer"
                            title="Acessar painel do lojista com privilégios master"
                          >
                            Painel Lojista
                          </button>

                          {/* Ver Cardápio Público */}
                          <button
                            type="button"
                            onClick={() => onNavigateToStore(loja.slug || loja.id)}
                            className="px-2.5 py-1.5 bg-red-950/40 hover:bg-red-900/50 text-red-300 hover:text-white border border-red-800/40 rounded-lg transition inline-flex items-center gap-1 text-[11px] font-medium cursor-pointer"
                            title="Abrir cardápio público oficial desta loja"
                          >
                            <ExternalLink className="w-3.5 h-3.5 text-red-400" />
                            <span>Ver Cardápio</span>
                          </button>

                          {/* Excluir Loja */}
                          <button
                            type="button"
                            onClick={() =>
                              setModalExcluir({
                                aberto: true,
                                lojaId: loja.id,
                                nomeLoja: loja.nome_loja,
                              })
                            }
                            className="p-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg transition inline-flex items-center cursor-pointer"
                            title="Excluir Loja Permanentemente"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {modalOnboarding && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-5 text-white shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <h3 className="font-black text-base tracking-tight">Onboarding de Nova Loja</h3>
              <button
                type="button"
                onClick={() => setModalOnboarding(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-300 mb-1.5">Link de Cadastro:</label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={`${window.location.origin}/cadastro`}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-300 font-mono text-[11px] select-all"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(`${window.location.origin}/cadastro`);
                      setCopiadoLink(true);
                      setTimeout(() => setCopiadoLink(false), 3000);
                    }}
                    className="px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl font-bold flex items-center gap-1.5 shrink-0 cursor-pointer"
                  >
                    {copiadoLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiadoLink ? 'Copiado!' : 'Copiar'}</span>
                  </button>
                </div>
              </div>
              {onNavigateToCadastro && (
                <button
                  type="button"
                  onClick={() => {
                    setModalOnboarding(false);
                    onNavigateToCadastro();
                  }}
                  className="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-extrabold transition shadow-md flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Cadastrar Loja Agora</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {modalExcluir && modalExcluir.aberto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-red-500/30 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl text-white">
            <h3 className="text-lg font-black text-white">Excluir Loja</h3>
            <p className="text-xs text-slate-300">
              Tem certeza que deseja excluir permanentemente a loja <strong>{modalExcluir.nomeLoja}</strong>?
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setModalExcluir(null)}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmarExclusaoLoja}
                className="px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition shadow-md flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                <span>Confirmar Exclusão</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {modalPreco && modalPreco.aberto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-5 text-white shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-emerald-400" />
                <h3 className="font-black text-base tracking-tight">Alterar Valor da Mensalidade</h3>
              </div>
              <button
                type="button"
                onClick={() => setModalPreco(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <p className="text-slate-300">
                Ajuste o valor que será cobrado mensalmente do lojista{' '}
                <strong className="text-white">"{modalPreco.nome}"</strong>:
              </p>

              <div>
                <label className="block font-bold text-slate-300 mb-1.5">Novo Valor Mensal (R$):</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-slate-400 font-bold text-sm">R$</span>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    value={novoValorInput}
                    onChange={(e) => setNovoValorInput(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-3 py-2.5 text-white font-extrabold text-base focus:outline-none focus:border-red-500"
                    autoFocus
                  />
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Atalhos de Valores:</span>
                <div className="flex flex-wrap gap-1.5">
                  {['99.00', '149.00', '169.99', '199.00', '249.90'].map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setNovoValorInput(val)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                        novoValorInput === val
                          ? 'bg-red-600 text-white'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                      }`}
                    >
                      R$ {parseFloat(val).toFixed(2)}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalPreco(null)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold cursor-pointer transition"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleSalvarNovoValor}
                  className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl font-extrabold cursor-pointer transition shadow-md flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Salvar Valor</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {modalEditarTeste && modalEditarTeste.aberto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-5 text-white shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-amber-400" />
                <h3 className="font-black text-base tracking-tight">Editar Tempo de Teste Grátis</h3>
              </div>
              <button
                type="button"
                onClick={() => setModalEditarTeste(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl space-y-1">
                <p className="text-slate-300">
                  Loja: <strong className="text-white text-sm">{modalEditarTeste.nomeLoja}</strong>
                </p>
                <p className="text-slate-400">
                  Dias de teste atualmente configurados:{' '}
                  <strong className="text-amber-400">{modalEditarTeste.diasAtuais} dias</strong>
                </p>
                {modalEditarTeste.dataVencimento && (
                  <p className="text-[11px] text-slate-500">
                    Vencimento atual: {new Date(modalEditarTeste.dataVencimento).toLocaleDateString()}
                  </p>
                )}
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1.5">
                  Novo Prazo de Teste Grátis (em dias):
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="number"
                    min="0"
                    max="180"
                    value={novosDiasTesteInput}
                    onChange={(e) => setNovosDiasTesteInput(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-white font-extrabold text-lg focus:outline-none focus:border-amber-500"
                    autoFocus
                  />
                  <span className="text-slate-400 font-bold shrink-0">dias</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  O acesso será estendido por este número de dias a partir de agora sem cobrança.
                </p>
              </div>

              <div className="space-y-1.5">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                  Atalhos Rápidos de Prazo:
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { label: '3 Dias', val: '3' },
                    { label: '7 Dias', val: '7' },
                    { label: '14 Dias', val: '14' },
                    { label: '30 Dias', val: '30' },
                    { label: '60 Dias', val: '60' },
                    { label: '90 Dias', val: '90' },
                  ].map((item) => (
                    <button
                      key={item.val}
                      type="button"
                      onClick={() => setNovosDiasTesteInput(item.val)}
                      className={`py-1.5 px-2 rounded-xl text-xs font-bold transition cursor-pointer text-center ${
                        novosDiasTesteInput === item.val
                          ? 'bg-amber-500 text-slate-950 font-black'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-3 bg-red-950/30 border border-red-900/40 rounded-xl flex items-center justify-between">
                <div>
                  <span className="font-bold text-red-300 block">Encerrar Teste Grátis Agora</span>
                  <span className="text-[10px] text-slate-400">Exige pagamento imediato da mensalidade</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleSalvarTempoTeste(0)}
                  className="px-3 py-1.5 bg-red-600/30 hover:bg-red-600 text-red-200 hover:text-white rounded-lg font-bold text-[11px] transition cursor-pointer border border-red-500/30"
                >
                  Encerrar (0d)
                </button>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalEditarTeste(null)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold cursor-pointer transition"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={() => handleSalvarTempoTeste()}
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-xl font-extrabold cursor-pointer transition shadow-md flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Salvar Tempo de Teste</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 1: EDITAR DADOS COMPLETOS DA LOJA / TENANT (CONTROLE TOTAL MASTER) */}
      {modalEditarTenant && modalEditarTenant.aberto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xs overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 text-white shadow-2xl my-8">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-blue-500/10 text-blue-400 flex items-center justify-center border border-blue-500/20">
                  <Edit3 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-lg tracking-tight text-white">
                    Editar Loja / Tenant (Controle Total Master)
                  </h3>
                  <p className="text-xs text-slate-400">
                    Como dono do SaaS, altere qualquer dado cadastral, financeiro ou de acesso desta loja.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setModalEditarTenant(null)}
                className="text-slate-400 hover:text-white p-1 rounded-xl cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSalvarEdicaoTenant} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    Nome do Estabelecimento *
                  </label>
                  <input
                    type="text"
                    required
                    value={formTenantNome}
                    onChange={(e) => setFormTenantNome(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-red-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    Slug Oficial (/loja/...) *
                  </label>
                  <div className="flex items-center bg-slate-950 border border-slate-700 rounded-xl overflow-hidden focus-within:border-red-500">
                    <span className="text-slate-500 pl-3 pr-1 text-[11px] font-mono">/loja/</span>
                    <input
                      type="text"
                      required
                      value={formTenantSlug}
                      onChange={(e) => setFormTenantSlug(sanitizeSlug(e.target.value))}
                      className="w-full bg-transparent p-3 text-white font-mono text-xs focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    Tipo de Loja / Segmento *
                  </label>
                  <select
                    value={formTenantSegmento}
                    onChange={(e) => setFormTenantSegmento(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-red-500"
                  >
                    <option value="hamburgueria">🍔 Hamburgueria & Lanches</option>
                    <option value="pizzaria">🍕 Pizzaria & Forno a Lenha</option>
                    <option value="sushi">🍱 Sushi & Japonesa</option>
                    <option value="restaurante">🍛 Restaurante & Marmitex</option>
                    <option value="acaiteria">🍧 Açaiteria & Sorvetes</option>
                    <option value="bebidas">🍺 Bebidas, Adega & Distribuidora</option>
                    <option value="doceria">🎂 Doceria & Confeitaria</option>
                    <option value="farmacia">💊 Farmácia & Cosméticos</option>
                    <option value="mercado">🛒 Mercado & Hortifruti</option>
                    <option value="petshop">🐶 Pet Shop & Rações</option>
                    <option value="moda">👕 Moda, Roupas & Acessórios</option>
                    <option value="manicure">💅 Salão, Manicure & Estética</option>
                    <option value="outro">🏪 Geral & Outro Negócio</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    WhatsApp de Contato *
                  </label>
                  <input
                    type="text"
                    required
                    value={formTenantTelefone}
                    onChange={(e) => setFormTenantTelefone(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-red-500"
                    placeholder="11999999999"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    E-mail de Login do Lojista *
                  </label>
                  <input
                    type="email"
                    required
                    value={formTenantEmail}
                    onChange={(e) => setFormTenantEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-red-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    Senha de Acesso do Lojista
                  </label>
                  <div className="relative">
                    <input
                      type={formTenantMostrarSenha ? 'text' : 'password'}
                      value={formTenantSenha}
                      onChange={(e) => setFormTenantSenha(e.target.value)}
                      placeholder="Deixe em branco para manter a atual"
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 pr-10 text-white focus:outline-none focus:border-red-500"
                    />
                    <button
                      type="button"
                      onClick={() => setFormTenantMostrarSenha(!formTenantMostrarSenha)}
                      className="absolute right-3 top-3 text-slate-400 hover:text-white"
                    >
                      {formTenantMostrarSenha ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    Valor da Mensalidade (R$)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={formTenantValorMensal}
                    onChange={(e) => setFormTenantValorMensal(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white font-extrabold focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    Dias de Teste Grátis
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formTenantDiasTeste}
                    onChange={(e) => setFormTenantDiasTeste(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white font-extrabold focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    Status da Conta *
                  </label>
                  <select
                    value={formTenantStatus}
                    onChange={(e) => setFormTenantStatus(e.target.value as any)}
                    className={`w-full border rounded-xl p-3 font-bold focus:outline-none ${
                      formTenantStatus === 'ativa'
                        ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-400'
                        : 'bg-red-950/40 border-red-500/40 text-red-400'
                    }`}
                  >
                    <option value="ativa">🟢 LOJA ATIVA</option>
                    <option value="bloqueada">🔴 BLOQUEADA</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    Chave PIX da Loja (Para receber pedidos)
                  </label>
                  <input
                    type="text"
                    value={formTenantChavePix}
                    onChange={(e) => setFormTenantChavePix(e.target.value)}
                    placeholder="Chave PIX do lojista..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-red-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    URL do Logotipo da Loja
                  </label>
                  <input
                    type="text"
                    value={formTenantLogoUrl}
                    onChange={(e) => setFormTenantLogoUrl(e.target.value)}
                    placeholder="Link da imagem do logo..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalEditarTenant(null)}
                  className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold cursor-pointer transition"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={salvandoTenant}
                  className="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl font-black cursor-pointer transition shadow-lg flex items-center gap-2 disabled:opacity-50"
                >
                  <Check className="w-4 h-4" />
                  <span>{salvandoTenant ? 'Salvando...' : 'Salvar Todas as Alterações'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: CADASTRAR NOVA LOJA DIRETO PELO SUPER ADMIN */}
      {modalCriarLoja && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xs overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 text-white shadow-2xl my-8">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-red-500/10 text-red-500 flex items-center justify-center border border-red-500/20">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-lg tracking-tight text-white">
                    Cadastrar Nova Loja
                  </h3>
                  <p className="text-xs text-slate-400">
                    Crie uma loja personalizada direto pelo painel de controle do SaaS.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setModalCriarLoja(false)}
                className="text-slate-400 hover:text-white p-1 rounded-xl cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCriarNovaLojaSuperAdmin} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Nome do Estabelecimento *
                </label>
                <input
                  type="text"
                  required
                  value={novaLojaNome}
                  onChange={(e) => {
                    setNovaLojaNome(e.target.value);
                    setNovaLojaSlug(sanitizeSlug(e.target.value));
                  }}
                  placeholder="Ex: Pizzaria Forno Nobre"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-red-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    Slug Oficial *
                  </label>
                  <input
                    type="text"
                    required
                    value={novaLojaSlug}
                    onChange={(e) => setNovaLojaSlug(sanitizeSlug(e.target.value))}
                    placeholder="pizzaria-forno-nobre"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white font-mono focus:outline-none focus:border-red-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    Tipo de Loja / Segmento *
                  </label>
                  <select
                    value={novaLojaSegmento}
                    onChange={(e) => setNovaLojaSegmento(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-red-500"
                  >
                    <option value="hamburgueria">🍔 Hamburgueria & Lanches</option>
                    <option value="pizzaria">🍕 Pizzaria & Forno a Lenha</option>
                    <option value="sushi">🍱 Sushi & Japonesa</option>
                    <option value="restaurante">🍛 Restaurante & Marmitex</option>
                    <option value="acaiteria">🍧 Açaiteria & Sorvetes</option>
                    <option value="bebidas">🍺 Bebidas, Adega & Distribuidora</option>
                    <option value="doceria">🎂 Doceria & Confeitaria</option>
                    <option value="farmacia">💊 Farmácia & Cosméticos</option>
                    <option value="mercado">🛒 Mercado & Hortifruti</option>
                    <option value="petshop">🐶 Pet Shop & Rações</option>
                    <option value="moda">👕 Moda, Roupas & Acessórios</option>
                    <option value="manicure">💅 Salão, Manicure & Estética</option>
                    <option value="outro">🏪 Geral & Outro Negócio</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    WhatsApp *
                  </label>
                  <input
                    type="text"
                    required
                    value={novaLojaTelefone}
                    onChange={(e) => setNovaLojaTelefone(e.target.value)}
                    placeholder="11999999999"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-red-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    E-mail de Login *
                  </label>
                  <input
                    type="email"
                    required
                    value={novaLojaEmail}
                    onChange={(e) => setNovaLojaEmail(e.target.value)}
                    placeholder="contato@loja.com"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    Senha de Acesso *
                  </label>
                  <input
                    type="text"
                    required
                    value={novaLojaSenha}
                    onChange={(e) => setNovaLojaSenha(e.target.value)}
                    placeholder="123456"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-red-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    Dias de Teste
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={novaLojaDiasTeste}
                    onChange={(e) => setNovaLojaDiasTeste(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white font-extrabold focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">
                    Mensalidade (R$)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    value={novaLojaValorMensal}
                    onChange={(e) => setNovaLojaValorMensal(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white font-extrabold focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalCriarLoja(false)}
                  className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold cursor-pointer transition"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={criandoLoja}
                  className="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl font-black cursor-pointer transition shadow-lg flex items-center gap-2 disabled:opacity-50"
                >
                  <Plus className="w-4 h-4" />
                  <span>{criandoLoja ? 'Cadastrando...' : 'Cadastrar Loja Agora'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

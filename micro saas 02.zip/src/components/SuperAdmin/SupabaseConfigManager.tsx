import { useState, useEffect } from 'react';
import {
  Database,
  RefreshCw,
  Eye,
  EyeOff,
  Copy,
  Check,
  Server,
  Zap,
  Terminal,
  AlertTriangle,
  Sparkles,
  ShieldCheck,
} from 'lucide-react';
import { AppStorage } from '../../lib/storage';
import {
  testSupabaseCredentials,
  getActiveSupabaseCredentials,
  DataService,
} from '../../lib/supabase';

const FULL_SQL_SCHEMA = `-- ==============================================================================
-- SCHEMA SUPABASE COMPLETO & MULTI-TENANT (ARMONIX STORE DELIVERY & SAAS)
-- Copie e cole este script no SQL Editor do seu novo projeto Supabase e clique em RUN
-- ==============================================================================

-- SE PRECISAR LIMPAR O BANCO ANTES DE CRIAR AS NOVAS TABELAS, DESCOMENTE A LINHA ABAIXO:
-- DROP TABLE IF EXISTS public.itens_pedido, public.pedidos, public.clientes, public.produtos, public.categorias, public.saas_pagamentos_logs, public.saas_assinaturas, public.avisos_globais, public.configuracoes_saas, public.lojas CASCADE;

-- 1. Habilitar extensões necessárias para UUID e Criptografia
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- TABELA 1: LOJAS (TENANTS ISOLADOS)
CREATE TABLE IF NOT EXISTS public.lojas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT,
  owner_id TEXT,
  nome TEXT NOT NULL,
  nome_loja TEXT,
  slug TEXT NOT NULL UNIQUE,
  whatsapp TEXT NOT NULL,
  telefone_whatsapp TEXT,
  email TEXT,
  senha TEXT,
  cidade TEXT DEFAULT 'Campo Grande, MS',
  status_conta TEXT DEFAULT 'ativa' NOT NULL,
  aberto BOOLEAN DEFAULT TRUE NOT NULL,
  taxa_base_entrega NUMERIC(10, 2) DEFAULT 5.00 NOT NULL,
  valor_por_km NUMERIC(10, 2) DEFAULT 1.50 NOT NULL,
  taxas_bairros JSONB DEFAULT '[]'::jsonb,
  origem_lat DOUBLE PRECISION DEFAULT -20.4697 NOT NULL,
  origem_lng DOUBLE PRECISION DEFAULT -54.6201 NOT NULL,
  origem_endereco_texto TEXT DEFAULT 'Av. Afonso Pena, 1500 - Centro',
  chave_pix TEXT,
  mercadopago_access_token TEXT,
  mercadopago_public_key TEXT,
  abacatepay_api_key TEXT,
  abacatepay_webhook_secret TEXT,
  logo_url TEXT,
  cor_tema TEXT DEFAULT '#DC2626',
  cor_primaria TEXT DEFAULT '#DC2626',
  impressora_largura VARCHAR(10) DEFAULT '80mm' NOT NULL,
  impressora_fonte VARCHAR(10) DEFAULT 'normal' NOT NULL,
  impressora_vias INTEGER DEFAULT 1 NOT NULL,
  impressora_auto_imprimir BOOLEAN DEFAULT FALSE NOT NULL,
  impressora_espaco_corte INTEGER DEFAULT 4 NOT NULL,
  impressora_rodape_texto TEXT DEFAULT 'Agradecemos a preferência! Volte sempre.',
  banner_oferta JSONB DEFAULT '{"ativo": false}'::jsonb,
  modelo_calculo_entrega TEXT DEFAULT 'raio_km' NOT NULL,
  raios_entrega JSONB DEFAULT '[{"id":"r-1","de_km":0,"ate_km":3,"valor":5.00,"tempo_estimado_min":"30-40 min"},{"id":"r-2","de_km":3,"ate_km":6,"valor":8.50,"tempo_estimado_min":"35-45 min"},{"id":"r-3","de_km":6,"ate_km":10,"valor":12.00,"tempo_estimado_min":"45-60 min"}]'::jsonb,
  raio_maximo_km NUMERIC(10, 2) DEFAULT 15.00 NOT NULL,
  valor_km_excedente NUMERIC(10, 2) DEFAULT 2.00 NOT NULL,
  valor_pedido_frete_gratis NUMERIC(10, 2),
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- Atualizações automáticas para tabelas já existentes:
ALTER TABLE public.lojas ADD COLUMN IF NOT EXISTS modelo_calculo_entrega TEXT DEFAULT 'raio_km';
ALTER TABLE public.lojas ADD COLUMN IF NOT EXISTS raios_entrega JSONB DEFAULT '[{"id":"r-1","de_km":0,"ate_km":3,"valor":5.00,"tempo_estimado_min":"30-40 min"},{"id":"r-2","de_km":3,"ate_km":6,"valor":8.50,"tempo_estimado_min":"35-45 min"},{"id":"r-3","de_km":6,"ate_km":10,"valor":12.00,"tempo_estimado_min":"45-60 min"}]'::jsonb;
ALTER TABLE public.lojas ADD COLUMN IF NOT EXISTS raio_maximo_km NUMERIC(10, 2) DEFAULT 15.00;
ALTER TABLE public.lojas ADD COLUMN IF NOT EXISTS valor_km_excedente NUMERIC(10, 2) DEFAULT 2.00;
ALTER TABLE public.lojas ADD COLUMN IF NOT EXISTS valor_pedido_frete_gratis NUMERIC(10, 2);
ALTER TABLE public.lojas ADD COLUMN IF NOT EXISTS impressora_espaco_corte INTEGER DEFAULT 4;
ALTER TABLE public.lojas ADD COLUMN IF NOT EXISTS impressora_rodape_texto TEXT DEFAULT 'Agradecemos a preferência! Volte sempre.';

-- TABELA 2: CATEGORIAS DO CARDÁPIO
CREATE TABLE IF NOT EXISTS public.categorias (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  loja_id UUID NOT NULL REFERENCES public.lojas(id) ON DELETE CASCADE,
  store_id UUID,
  nome TEXT NOT NULL,
  ordem INTEGER DEFAULT 0 NOT NULL,
  ativa BOOLEAN DEFAULT TRUE NOT NULL,
  ativo BOOLEAN DEFAULT TRUE,
  icone TEXT DEFAULT 'Utensils',
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- TABELA 3: PRODUTOS DO CARDÁPIO
CREATE TABLE IF NOT EXISTS public.produtos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  loja_id UUID NOT NULL REFERENCES public.lojas(id) ON DELETE CASCADE,
  store_id UUID,
  categoria_id UUID NOT NULL REFERENCES public.categorias(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  descricao TEXT,
  preco NUMERIC(10, 2) NOT NULL,
  preco_promocional NUMERIC(10, 2),
  preco_original TEXT,
  imagem TEXT,
  imagem_url TEXT,
  destaque_oferta BOOLEAN DEFAULT FALSE NOT NULL,
  destaque_mais_pedido BOOLEAN DEFAULT FALSE NOT NULL,
  ativo BOOLEAN DEFAULT TRUE NOT NULL,
  disponivel BOOLEAN DEFAULT TRUE NOT NULL,
  opcionais JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- TABELA 4: CLIENTES (HISTÓRICO E AUTO-PREENCHIMENTO)
CREATE TABLE IF NOT EXISTS public.clientes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  loja_id UUID NOT NULL REFERENCES public.lojas(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  telefone TEXT NOT NULL,
  endereco TEXT,
  numero TEXT,
  complemento TEXT,
  bairro TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- TABELA 5: PEDIDOS EM TEMPO REAL
CREATE TABLE IF NOT EXISTS public.pedidos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  loja_id UUID NOT NULL REFERENCES public.lojas(id) ON DELETE CASCADE,
  codigo_pedido TEXT DEFAULT ('#' || floor(random() * 9000 + 1000)::text),
  cliente_nome TEXT NOT NULL,
  cliente_telefone TEXT NOT NULL,
  tipo_entrega TEXT DEFAULT 'delivery' NOT NULL,
  endereco_destino TEXT,
  endereco_completo TEXT,
  distancia_km NUMERIC(10, 2) DEFAULT 0.00,
  taxa_entrega NUMERIC(10, 2) DEFAULT 0.00 NOT NULL,
  subtotal NUMERIC(10, 2) DEFAULT 0.00,
  total NUMERIC(10, 2) NOT NULL,
  status TEXT DEFAULT 'pendente' NOT NULL,
  status_pagamento TEXT DEFAULT 'pendente' NOT NULL,
  metodo_pagamento TEXT DEFAULT 'pix_online' NOT NULL,
  forma_pagamento TEXT,
  troco_para NUMERIC(10, 2),
  impresso BOOLEAN DEFAULT FALSE NOT NULL,
  pix_copia_cola TEXT,
  pix_qrcode_url TEXT,
  gateway_transacao_id TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- TABELA 6: ITENS DO PEDIDO
CREATE TABLE IF NOT EXISTS public.itens_pedido (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pedido_id UUID NOT NULL REFERENCES public.pedidos(id) ON DELETE CASCADE,
  produto_id UUID NOT NULL REFERENCES public.produtos(id) ON DELETE RESTRICT,
  produto_nome TEXT,
  quantidade INTEGER DEFAULT 1 NOT NULL,
  preco_unitario NUMERIC(10, 2) NOT NULL,
  total_item NUMERIC(10, 2),
  observacao TEXT,
  opcionais JSONB DEFAULT '[]'::jsonb
);

-- TABELA 7: ASSINATURAS DO SAAS (SUPER ADMIN)
CREATE TABLE IF NOT EXISTS public.saas_assinaturas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  loja_id UUID NOT NULL REFERENCES public.lojas(id) ON DELETE CASCADE,
  status TEXT DEFAULT 'ativa' NOT NULL,
  plano TEXT DEFAULT 'mensal' NOT NULL,
  valor NUMERIC(10, 2) DEFAULT 169.99 NOT NULL,
  data_vencimento TIMESTAMPTZ NOT NULL,
  ultimo_pagamento TIMESTAMPTZ,
  dias_teste INTEGER DEFAULT 7,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- TABELA 8: LOGS DE PAGAMENTO DO SAAS
CREATE TABLE IF NOT EXISTS public.saas_pagamentos_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  loja_id UUID NOT NULL REFERENCES public.lojas(id) ON DELETE CASCADE,
  loja_nome TEXT NOT NULL,
  valor NUMERIC(10, 2) NOT NULL,
  metodo TEXT DEFAULT 'pix' NOT NULL,
  gateway TEXT DEFAULT 'mercadopago' NOT NULL,
  status TEXT DEFAULT 'confirmado' NOT NULL,
  data_pagamento TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  comprovante_id TEXT
);

-- TABELA 9: CONFIGURAÇÕES GLOBAIS DO SAAS (SUPER ADMIN)
CREATE TABLE IF NOT EXISTS public.configuracoes_saas (
  chave TEXT PRIMARY KEY,
  valor JSONB NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- TABELA 10: AVISOS GLOBAIS DO SAAS (SUPER ADMIN)
CREATE TABLE IF NOT EXISTS public.avisos_globais (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  titulo TEXT NOT NULL,
  mensagem TEXT NOT NULL,
  tipo TEXT DEFAULT 'informativo' NOT NULL,
  ativo BOOLEAN DEFAULT TRUE NOT NULL,
  data_criacao TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- TABELA 11: CONTAS DOS LOJISTAS (ACESSO MULTI-DISPOSITIVO)
CREATE TABLE IF NOT EXISTS public.saas_contas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  loja_id UUID REFERENCES public.lojas(id) ON DELETE CASCADE,
  nome_responsavel TEXT,
  nome_loja TEXT NOT NULL,
  slug TEXT NOT NULL,
  email TEXT NOT NULL,
  whatsapp TEXT NOT NULL,
  senha TEXT NOT NULL,
  status TEXT DEFAULT 'ativa' NOT NULL,
  plano TEXT DEFAULT 'mensal' NOT NULL,
  dispositivos_conectados INTEGER DEFAULT 1,
  ultimo_acesso TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- ÍNDICES PARA ALTA VELOCIDADE & MULTI-TENANCY
CREATE INDEX IF NOT EXISTS idx_lojas_slug ON public.lojas(slug);
CREATE INDEX IF NOT EXISTS idx_saas_contas_email ON public.saas_contas(email);
CREATE INDEX IF NOT EXISTS idx_saas_contas_whatsapp ON public.saas_contas(whatsapp);
CREATE INDEX IF NOT EXISTS idx_saas_contas_slug ON public.saas_contas(slug);
CREATE INDEX IF NOT EXISTS idx_categorias_loja ON public.categorias(loja_id, ordem);
CREATE INDEX IF NOT EXISTS idx_produtos_loja ON public.produtos(loja_id, categoria_id);
CREATE INDEX IF NOT EXISTS idx_clientes_loja ON public.clientes(loja_id, telefone);
CREATE INDEX IF NOT EXISTS idx_pedidos_loja ON public.pedidos(loja_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_itens_pedido_pedido ON public.itens_pedido(pedido_id);
CREATE INDEX IF NOT EXISTS idx_saas_assinaturas_loja ON public.saas_assinaturas(loja_id);

-- POLÍTICAS DE ACESSO RLS (ROW LEVEL SECURITY)
ALTER TABLE public.lojas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.saas_contas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categorias ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.produtos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pedidos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.itens_pedido ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.saas_assinaturas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.saas_pagamentos_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.configuracoes_saas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.avisos_globais ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public access lojas" ON public.lojas;
CREATE POLICY "Public access lojas" ON public.lojas FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access saas_contas" ON public.saas_contas;
CREATE POLICY "Public access saas_contas" ON public.saas_contas FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access categorias" ON public.categorias;
CREATE POLICY "Public access categorias" ON public.categorias FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access produtos" ON public.produtos;
CREATE POLICY "Public access produtos" ON public.produtos FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access clientes" ON public.clientes;
CREATE POLICY "Public access clientes" ON public.clientes FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access pedidos" ON public.pedidos;
CREATE POLICY "Public access pedidos" ON public.pedidos FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access itens_pedido" ON public.itens_pedido;
CREATE POLICY "Public access itens_pedido" ON public.itens_pedido FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access saas_assinaturas" ON public.saas_assinaturas;
CREATE POLICY "Public access saas_assinaturas" ON public.saas_assinaturas FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access saas_pagamentos_logs" ON public.saas_pagamentos_logs;
CREATE POLICY "Public access saas_pagamentos_logs" ON public.saas_pagamentos_logs FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access configuracoes_saas" ON public.configuracoes_saas;
CREATE POLICY "Public access configuracoes_saas" ON public.configuracoes_saas FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access avisos_globais" ON public.avisos_globais;
CREATE POLICY "Public access avisos_globais" ON public.avisos_globais FOR ALL USING (true) WITH CHECK (true);
`;

export default function SupabaseConfigManager() {
  const currentSaved = AppStorage.getSupabaseConfig();
  const activeCreds = getActiveSupabaseCredentials();
  const [url, setUrl] = useState(currentSaved.url || activeCreds.url || 'https://eyaufwzdrjtfzcvtuxyw.supabase.co');
  const [anonKey, setAnonKey] = useState(currentSaved.anonKey || activeCreds.anonKey || 'sb_publishable_safdydwDCc5Z6KZrXxRUGQ_ui9kB0Vl');
  const [serviceRoleKey, setServiceRoleKey] = useState(
    currentSaved.serviceRoleKey || activeCreds.serviceRoleKey || ''
  );
  const [showAnonKey, setShowAnonKey] = useState(false);
  const [showServiceKey, setShowServiceKey] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [testResult, setTestResult] = useState<{
    ok: boolean;
    message: string;
    latencyMs?: number;
    mode: 'supabase' | 'local';
  } | null>(null);
  const [copiedSql, setCopiedSql] = useState(false);
  const [sucessoMensagem, setSucessoMensagem] = useState<string | null>(null);
  const [confirmandoLimpar, setConfirmandoLimpar] = useState(false);

  useEffect(() => {
    if (url && anonKey) {
      handleTestConnection(false);
    }
  }, []);

  async function handleTestConnection(showFeedback = true) {
    setIsTesting(true);
    try {
      const res = await testSupabaseCredentials(url, anonKey);
      setTestResult(res);
      if (showFeedback && res.ok) {
        setSucessoMensagem(`Conexão confirmada com sucesso! Latência: ${res.latencyMs || 0}ms.`);
        setTimeout(() => setSucessoMensagem(null), 4000);
      }
    } catch (e: any) {
      setTestResult({
        ok: false,
        message: `Erro no teste: ${e?.message || e}`,
        mode: 'local',
      });
    } finally {
      setIsTesting(false);
    }
  }

  async function handleSalvar() {
    setIsSaving(true);
    try {
      const res = await DataService.saveConfig({
        url: url.trim(),
        anonKey: anonKey.trim(),
        serviceRoleKey: serviceRoleKey.trim(),
      });
      setTestResult(res);
      setSucessoMensagem('Configurações do banco de dados salvas com sucesso!');
      setTimeout(() => setSucessoMensagem(null), 4000);
    } catch (e: any) {
      setTestResult({
        ok: false,
        message: `Falha ao salvar: ${e?.message || e}`,
        mode: 'local',
      });
    } finally {
      setIsSaving(false);
    }
  }

  function handleCarregarCredenciaisPadrao() {
    setUrl('https://eyaufwzdrjtfzcvtuxyw.supabase.co');
    setAnonKey('sb_publishable_safdydwDCc5Z6KZrXxRUGQ_ui9kB0Vl');
    setServiceRoleKey('');
    setSucessoMensagem('Credenciais do novo projeto eyaufwzdrjtfzcvtuxyw carregadas!');
    setTimeout(() => setSucessoMensagem(null), 4000);
  }

  function handleExecutarLimpeza() {
    AppStorage.clearSupabaseConfig();
    setUrl('');
    setAnonKey('');
    setServiceRoleKey('');
    setConfirmandoLimpar(false);
    setTestResult({
      ok: true,
      message: 'Configuração anterior removida. Insira os dados do novo banco de dados Supabase.',
      mode: 'local',
    });
    setSucessoMensagem('Banco de dados anterior desconectado com sucesso.');
    setTimeout(() => setSucessoMensagem(null), 4000);
  }

  function copiarSql() {
    navigator.clipboard.writeText(FULL_SQL_SCHEMA);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 3000);
  }

  const isConnected = testResult?.ok && testResult?.mode === 'supabase';

  return (
    <div className="space-y-6">
      {sucessoMensagem && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2.5 animate-fadeIn">
          <Check className="w-4 h-4 shrink-0 text-emerald-400" />
          <span className="font-bold">{sucessoMensagem}</span>
        </div>
      )}

      {/* Status da Conexão */}
      <div
        className={`p-5 rounded-2xl border transition-all ${
          isConnected
            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-950 dark:text-emerald-100'
            : testResult && !testResult.ok
            ? 'bg-red-500/10 border-red-500/30 text-red-950 dark:text-red-100'
            : 'bg-amber-500/10 border-amber-500/30 text-amber-950 dark:text-amber-100'
        }`}
      >
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center gap-3">
            <div
              className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 shadow-sm ${
                isConnected
                  ? 'bg-emerald-500 text-white'
                  : testResult && !testResult.ok
                  ? 'bg-red-500 text-white'
                  : 'bg-amber-500 text-white'
              }`}
            >
              <Database className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base tracking-tight">
                  {isConnected
                    ? 'Conectado ao Supabase (Produção Relacional Ativa)'
                    : testResult && !testResult.ok
                    ? 'Aguardando Criação das Tabelas no Supabase'
                    : 'Modo Local Seguro Ativo (Resiliência Offline)'}
                </h3>
              </div>
              <p className="text-xs opacity-90 mt-0.5">
                {testResult?.message ||
                  'Configure sua URL e Anon Key para conectar a aplicação ao seu novo banco de dados Supabase.'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              disabled={isTesting}
              onClick={() => handleTestConnection(true)}
              className="px-3.5 py-2 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 shadow-xs flex items-center gap-1.5 transition cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
              {isTesting ? 'Testando...' : 'Testar Conexão'}
            </button>
          </div>
        </div>
      </div>

      {/* Caixa de Confirmação para Limpar Banco Antigo */}
      {confirmandoLimpar && (
        <div className="p-5 rounded-2xl bg-red-950/40 border border-red-500/40 text-white space-y-3">
          <div className="flex items-center gap-2 text-red-400 font-bold text-sm">
            <AlertTriangle className="w-5 h-5" />
            <span>Confirmar desconexão do banco antigo?</span>
          </div>
          <p className="text-xs text-slate-300">
            Isso limpará as chaves salvas localmente para que você possa apontar para o seu novo banco de dados Supabase.
          </p>
          <div className="flex items-center gap-3 pt-1">
            <button
              type="button"
              onClick={handleExecutarLimpeza}
              className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition cursor-pointer"
            >
              Sim, Limpar e Desconectar
            </button>
            <button
              type="button"
              onClick={() => setConfirmandoLimpar(false)}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition cursor-pointer"
            >
              Cancelar
            </button>
          </div>
        </div>
      )}

      {/* Formulário de Configuração */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-2xl shadow-xs space-y-5">
        <div className="border-b border-slate-100 dark:border-slate-800 pb-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <h3 className="text-base font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
              <Server className="w-4 h-4 text-red-600" />
              Credenciais do Novo Banco de Dados Supabase
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Configure a URL e as chaves do seu novo projeto Supabase aqui para sincronizar todas as lojas e pedidos.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCarregarCredenciaisPadrao}
              className="text-xs text-blue-600 dark:text-blue-400 hover:underline font-bold cursor-pointer flex items-center gap-1"
              title="Carregar credenciais do projeto eyaufwzdrjtfzcvtuxyw"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Usar eyaufwzdrjtfzcvtuxyw
            </button>
            <span className="text-slate-300 dark:text-slate-700">|</span>
            <button
              type="button"
              onClick={() => setConfirmandoLimpar(true)}
              className="text-xs text-red-600 hover:text-red-700 font-bold underline cursor-pointer"
            >
              Limpar Configuração Antiga
            </button>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              SUPABASE_URL (URL do Novo Projeto):
            </label>
            <input
              type="text"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://eyaufwzdrjtfzcvtuxyw.supabase.co"
              className="w-full text-xs font-mono bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-red-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              SUPABASE_ANON_KEY (Chave Pública Anon / Publishable Key):
            </label>
            <div className="relative">
              <input
                type={showAnonKey ? 'text' : 'password'}
                value={anonKey}
                onChange={(e) => setAnonKey(e.target.value)}
                placeholder="sb_publishable_safdydwDCc5Z6KZrXxRUGQ_ui9kB0Vl"
                className="w-full text-xs font-mono bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pl-3 pr-10 py-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-red-500"
              />
              <button
                type="button"
                onClick={() => setShowAnonKey(!showAnonKey)}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                {showAnonKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              SUPABASE_SERVICE_ROLE_KEY (Opcional - Chave de Admin):
            </label>
            <div className="relative">
              <input
                type={showServiceKey ? 'text' : 'password'}
                value={serviceRoleKey}
                onChange={(e) => setServiceRoleKey(e.target.value)}
                placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.service_role..."
                className="w-full text-xs font-mono bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pl-3 pr-10 py-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-red-500"
              />
              <button
                type="button"
                onClick={() => setShowServiceKey(!showServiceKey)}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                {showServiceKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={isSaving}
                onClick={handleSalvar}
                className="px-5 py-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white rounded-xl text-xs font-extrabold transition shadow-xs flex items-center gap-2 cursor-pointer"
              >
                {isSaving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                <span>Salvar e Conectar Novo Banco</span>
              </button>
              <button
                type="button"
                disabled={isTesting}
                onClick={() => handleTestConnection(true)}
                className="px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
              >
                <Zap className="w-3.5 h-3.5 text-amber-500" />
                Testar Credenciais
              </button>
            </div>

            <div className="text-[11px] text-slate-500 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
              <span>Multi-tenancy com isolamento absoluto por loja</span>
            </div>
          </div>
        </div>
      </div>

      {/* Script SQL Completo */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-2xl shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <h4 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-600" />
              Script SQL Completo para Rodar no Novo Supabase
            </h4>
            <p className="text-xs text-slate-500 mt-0.5">
              Execute este script completo no <b>SQL Editor</b> do seu novo Supabase (Projeto: <b>eyaufwzdrjtfzcvtuxyw</b>) para criar todas as 10 tabelas relacionais, índices e políticas de segurança.
            </p>
          </div>
          <button
            type="button"
            onClick={copiarSql}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shrink-0 shadow-xs"
          >
            {copiedSql ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            {copiedSql ? 'Copiado para Área de Transferência!' : 'Copiar Script SQL Completo'}
          </button>
        </div>
        <div className="bg-slate-950 text-slate-300 p-4 rounded-xl font-mono text-[11px] overflow-x-auto max-h-64 border border-slate-800 leading-relaxed scrollbar-thin">
          <pre>{FULL_SQL_SCHEMA}</pre>
        </div>
      </div>
    </div>
  );
}

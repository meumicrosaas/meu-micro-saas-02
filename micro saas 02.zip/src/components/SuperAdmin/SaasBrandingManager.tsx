import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Image as ImageIcon,
  Check,
  Eye,
  RefreshCw,
  Palette,
  Type,
  Layout,
  Save,
  Store,
} from 'lucide-react';
import { AppStorage } from '../../lib/storage';
import { DataService } from '../../lib/supabase';
import { SaasBranding } from '../../types';

const HERO_PRESETS = [
  {
    nome: 'Restaurante Sofisticado',
    url: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1200&auto=format&fit=crop&q=80',
  },
  {
    nome: 'Hambúrguer & Delivery Urbano',
    url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=1200&auto=format&fit=crop&q=80',
  },
  {
    nome: 'Pizzaria Forno a Lenha',
    url: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=1200&auto=format&fit=crop&q=80',
  },
  {
    nome: 'Sushi & Gastronomia Oriental',
    url: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=1200&auto=format&fit=crop&q=80',
  },
  {
    nome: 'Doceria & Confeitaria Fina',
    url: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=1200&auto=format&fit=crop&q=80',
  },
  {
    nome: 'Bebidas & Adega Premium',
    url: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?w=1200&auto=format&fit=crop&q=80',
  },
];

const CORES_PALETA = [
  { nome: 'Vermelho Armonix', hex: '#dc2626' },
  { nome: 'Roxo Moderno', hex: '#7c3aed' },
  { nome: 'Azul Tech', hex: '#2563eb' },
  { nome: 'Esmeralda', hex: '#059669' },
  { nome: 'Laranja Delivery', hex: '#ea580c' },
  { nome: 'Rosa Vibrante', hex: '#db2777' },
];

const VITRINE_SEGMENTOS_CONFIG = [
  {
    key: 'acai',
    label: 'Açaiteria & Sobremesas',
    defaultImg: 'https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?w=600&auto=format&fit=crop&q=80',
    presets: [
      'https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1577805947697-89e18249d767?w=600&auto=format&fit=crop&q=80',
    ],
  },
  {
    key: 'espetinhos',
    label: 'Espetaria & Churrasquinho',
    defaultImg: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=600&auto=format&fit=crop&q=80',
    presets: [
      'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1544025162-d76694265947?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1529193591184-b1d58069ecdd?w=600&auto=format&fit=crop&q=80',
    ],
  },
  {
    key: 'conveniencia',
    label: 'Conveniência 24h & Bebidas',
    defaultImg: 'https://images.unsplash.com/photo-1608270546124-7eb3e6ef6d7f?w=600&auto=format&fit=crop&q=80',
    presets: [
      'https://images.unsplash.com/photo-1608270546124-7eb3e6ef6d7f?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1527061011665-3652c757a4d4?w=600&auto=format&fit=crop&q=80',
    ],
  },
  {
    key: 'lanchonete',
    label: 'Lanchonete & Hambúrguer',
    defaultImg: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80',
    presets: [
      'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1550547660-d9450f859349?w=600&auto=format&fit=crop&q=80',
    ],
  },
  {
    key: 'petshop',
    label: 'Pet Shop & Ração',
    defaultImg: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=600&auto=format&fit=crop&q=80',
    presets: [
      'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1548767797-d8c844163c4c?w=600&auto=format&fit=crop&q=80',
    ],
  },
  {
    key: 'cosmeticos',
    label: 'Cosméticos & Perfumaria',
    defaultImg: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=600&auto=format&fit=crop&q=80',
    presets: [
      'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=600&auto=format&fit=crop&q=80',
    ],
  },
  {
    key: 'manicure',
    label: 'Manicure & Esmalteria',
    defaultImg: 'https://images.unsplash.com/photo-1632345031435-8727f6897d53?w=600&auto=format&fit=crop&q=80',
    presets: [
      'https://images.unsplash.com/photo-1632345031435-8727f6897d53?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1604654894610-df63bc536371?w=600&auto=format&fit=crop&q=80',
    ],
  },
  {
    key: 'variedades',
    label: 'Variedades & Bazar',
    defaultImg: 'https://images.unsplash.com/photo-1513151233558-d860c5398176?w=600&auto=format&fit=crop&q=80',
    presets: [
      'https://images.unsplash.com/photo-1513151233558-d860c5398176?w=600&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=600&auto=format&fit=crop&q=80',
    ],
  },
];

export default function SaasBrandingManager() {
  const [branding, setBranding] = useState<SaasBranding>(() => AppStorage.getSaasBranding());
  const [salvando, setSalvando] = useState(false);
  const [salvoFeedback, setSalvoFeedback] = useState(false);

  useEffect(() => {
    DataService.getSaasBranding().then((b) => setBranding(b)).catch(() => {});
  }, []);

  async function handleSalvar() {
    setSalvando(true);
    try {
      AppStorage.saveSaasBranding(branding);
      await DataService.saveSaasBranding(branding);
      setSalvoFeedback(true);
      setTimeout(() => setSalvoFeedback(false), 3000);
    } catch (e) {
      console.error('Erro ao salvar branding:', e);
    } finally {
      setSalvando(false);
    }
  }

  function handleSetVitrineImage(segmentKey: string, url: string) {
    setBranding((prev) => ({
      ...prev,
      imagens_vitrine: {
        ...(prev.imagens_vitrine || {}),
        [segmentKey]: url,
      },
    }));
  }

  return (
    <div className="space-y-8">
      {/* Header do Gerenciador de Design */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-red-500/20 text-red-400 text-xs px-2.5 py-0.5 rounded-full font-bold border border-red-500/30 flex items-center gap-1">
              <Palette className="w-3.5 h-3.5" /> CONTROLE TOTAL DE DESIGN
            </span>
          </div>
          <h2 className="text-xl font-black tracking-tight">Design & Imagens da Tela Inicial</h2>
          <p className="text-xs text-slate-400">
            Personalize a imagem hero, logomarca, textos, títulos, cores e imagens da vitrine demonstrativa.
          </p>
        </div>
        <button
          type="button"
          onClick={handleSalvar}
          disabled={salvando}
          className="px-5 py-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white rounded-xl text-xs font-black transition shadow-md flex items-center gap-2 cursor-pointer"
        >
          {salvando ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          <span>Salvar Design Global</span>
        </button>
      </div>

      {salvoFeedback && (
        <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold rounded-xl flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>Alterações de design salvas com sucesso e sincronizadas com a tela inicial!</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Formulário de Customização */}
        <div className="lg:col-span-7 space-y-6">
          {/* 1. Identidade & Marca */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Type className="w-4 h-4 text-red-500" />
              <span>Nome da Marca & Logomarca</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Nome da Marca:</label>
                <input
                  type="text"
                  value={branding.nome_marca || ''}
                  onChange={(e) => setBranding({ ...branding, nome_marca: e.target.value })}
                  placeholder="Ex: ARMONIX STORE"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-red-500 font-bold"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Subtítulo / Slogan:</label>
                <input
                  type="text"
                  value={branding.subtitulo || ''}
                  onChange={(e) => setBranding({ ...branding, subtitulo: e.target.value })}
                  placeholder="Ex: Plataforma de Delivery Multi-tenant"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <div className="text-xs">
              <label className="block text-slate-300 font-semibold mb-1">URL da Logomarca (Ícone ou Imagem PNG/SVG):</label>
              <input
                type="url"
                value={branding.logo_url || ''}
                onChange={(e) => setBranding({ ...branding, logo_url: e.target.value })}
                placeholder="https://exemplo.com/logo.png"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono text-[11px] focus:outline-none focus:border-red-500"
              />
            </div>

            {/* Paleta de Cores Primárias */}
            <div>
              <label className="block text-xs text-slate-300 font-semibold mb-1.5">Cor Primária do SaaS:</label>
              <div className="flex flex-wrap gap-2">
                {CORES_PALETA.map((c) => (
                  <button
                    key={c.hex}
                    type="button"
                    onClick={() => setBranding({ ...branding, cor_primaria: c.hex })}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
                      branding.cor_primaria === c.hex
                        ? 'border-white bg-slate-800 text-white'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: c.hex }} />
                    <span>{c.nome}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 2. Imagem Hero & Título Principal da Tela Inicial */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-amber-500" />
              <span>Banner & Imagem de Fundo da Tela Inicial</span>
            </h3>

            <div className="text-xs space-y-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Título de Destaque da Tela Inicial:</label>
                <input
                  type="text"
                  value={branding.titulo_principal || ''}
                  onChange={(e) => setBranding({ ...branding, titulo_principal: e.target.value })}
                  placeholder="Ex: Veja como sua loja pode ficar na internet"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-bold text-xs focus:outline-none focus:border-red-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Badge de Destaque:</label>
                  <input
                    type="text"
                    value={branding.badge_destaque || ''}
                    onChange={(e) => setBranding({ ...branding, badge_destaque: e.target.value })}
                    placeholder="Ex: Modelos Prontos • Simulação Completa"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-red-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Texto do Botão Principal:</label>
                  <input
                    type="text"
                    value={branding.texto_botao || ''}
                    onChange={(e) => setBranding({ ...branding, texto_botao: e.target.value })}
                    placeholder="Ex: Criar Meu Painel Agora"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">URL da Imagem Hero / Fundo Principal:</label>
                <input
                  type="url"
                  value={branding.imagem_hero || branding.banner_url || ''}
                  onChange={(e) =>
                    setBranding({
                      ...branding,
                      imagem_hero: e.target.value,
                      banner_url: e.target.value,
                    })
                  }
                  placeholder="https://images.unsplash.com/..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white font-mono text-[11px] focus:outline-none focus:border-red-500"
                />
              </div>

              {/* Galeria de Presets Hero em 1 Clique */}
              <div>
                <label className="block text-slate-400 font-semibold mb-1.5 text-[11px]">
                  Sugestões de Imagens Hero em Alta Resolução (1 Clique para aplicar):
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {HERO_PRESETS.map((p, idx) => {
                    const isSel = (branding.imagem_hero || branding.banner_url) === p.url;
                    return (
                      <button
                        key={idx}
                        type="button"
                        onClick={() =>
                          setBranding({
                            ...branding,
                            imagem_hero: p.url,
                            banner_url: p.url,
                          })
                        }
                        className={`p-1.5 rounded-xl border text-left transition flex items-center gap-2 cursor-pointer ${
                          isSel
                            ? 'border-red-500 bg-red-600/20 text-white font-bold ring-1 ring-red-500'
                            : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                        }`}
                      >
                        <img src={p.url} alt={p.nome} className="w-9 h-9 rounded-lg object-cover shrink-0" />
                        <span className="text-[10px] leading-tight truncate">{p.nome}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* 3. Imagens da Vitrine de Modelos Prontos */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Layout className="w-4 h-4 text-emerald-500" />
              <span>Imagens da Vitrine de Demonstração (Cards dos Nichos)</span>
            </h3>
            <p className="text-xs text-slate-400">
              Personalize a foto principal de cada segmento exibido na vitrine da tela inicial:
            </p>

            <div className="space-y-3">
              {VITRINE_SEGMENTOS_CONFIG.map((seg) => {
                const imgAtual =
                  (branding.imagens_vitrine && branding.imagens_vitrine[seg.key]) || seg.defaultImg;
                return (
                  <div
                    key={seg.key}
                    className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white">{seg.label}</span>
                      <span className="text-[10px] text-slate-500 font-mono">[{seg.key}]</span>
                    </div>

                    <div className="flex items-center gap-3">
                      <img
                        src={imgAtual}
                        alt={seg.label}
                        className="w-12 h-12 rounded-lg object-cover border border-slate-700 shrink-0"
                      />
                      <input
                        type="url"
                        value={imgAtual}
                        onChange={(e) => handleSetVitrineImage(seg.key, e.target.value)}
                        placeholder="https://images.unsplash.com/..."
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono text-[10px] focus:outline-none focus:border-red-500"
                      />
                    </div>

                    {seg.presets && seg.presets.length > 0 && (
                      <div className="flex gap-2 pt-1 overflow-x-auto">
                        {seg.presets.map((pUrl, pIdx) => (
                          <button
                            key={pIdx}
                            type="button"
                            onClick={() => handleSetVitrineImage(seg.key, pUrl)}
                            className="w-10 h-10 rounded-md overflow-hidden border border-slate-700 hover:border-red-500 shrink-0 cursor-pointer transition transform hover:scale-105"
                          >
                            <img src={pUrl} alt="Preset" className="w-full h-full object-cover" />
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Prévia ao Vivo no Painel Lateral */}
        <div className="lg:col-span-5 space-y-4">
          <div className="sticky top-20 bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5 text-amber-500" />
                Prévia ao Vivo do Topo / Hero da Tela Inicial:
              </span>
            </div>

            {/* Mockup do Header e Hero da Tela Inicial */}
            <div className="rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 shadow-xl">
              {/* Header Mock */}
              <div className="bg-slate-900 p-3 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {branding.logo_url ? (
                    <img
                      src={branding.logo_url}
                      alt="Logo"
                      className="w-6 h-6 rounded-lg object-contain bg-white/10"
                    />
                  ) : (
                    <div
                      className="w-6 h-6 rounded-lg text-white font-black text-xs flex items-center justify-center"
                      style={{ backgroundColor: branding.cor_primaria || '#dc2626' }}
                    >
                      A
                    </div>
                  )}
                  <div>
                    <span className="text-xs font-black text-white block leading-tight">
                      {branding.nome_marca || 'ARMONIX STORE'}
                    </span>
                    <span className="text-[9px] text-slate-400 block leading-none">
                      {branding.subtitulo || 'Plataforma de Delivery'}
                    </span>
                  </div>
                </div>
                <div
                  className="px-2.5 py-1 text-[10px] font-bold text-white rounded-lg shadow-xs"
                  style={{ backgroundColor: branding.cor_primaria || '#dc2626' }}
                >
                  Entrar
                </div>
              </div>

              {/* Hero Image Mock */}
              <div className="relative h-44 overflow-hidden">
                <img
                  src={
                    branding.imagem_hero ||
                    branding.banner_url ||
                    'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1200&auto=format&fit=crop&q=80'
                  }
                  alt="Hero Preview"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent p-4 flex flex-col justify-end text-white">
                  <span
                    className="inline-block text-[9px] font-black uppercase px-2 py-0.5 rounded-full w-fit mb-1 shadow-xs"
                    style={{ backgroundColor: branding.cor_primaria || '#dc2626' }}
                  >
                    {branding.badge_destaque || 'Modelos Prontos • Simulação Completa'}
                  </span>
                  <h4 className="text-sm font-black leading-snug line-clamp-2">
                    {branding.titulo_principal || 'Veja como sua loja pode ficar na internet'}
                  </h4>
                  <p className="text-[10px] text-slate-300 mt-0.5 line-clamp-2">
                    {branding.texto_chamada ||
                      'Tenha sua loja personalizada para seu negócio com pedidos direto no WhatsApp.'}
                  </p>
                </div>
              </div>

              {/* Botão Call to action Mock */}
              <div className="p-3 bg-slate-950 flex justify-center">
                <button
                  type="button"
                  className="w-full py-2 text-white font-black text-xs rounded-xl shadow-md cursor-pointer transition transform active:scale-95"
                  style={{ backgroundColor: branding.cor_primaria || '#dc2626' }}
                >
                  {branding.texto_botao || 'Criar Meu Painel Agora'}
                </button>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={handleSalvar}
                disabled={salvando}
                className="w-full py-3 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white rounded-xl text-xs font-black transition shadow-lg flex items-center justify-center gap-2 cursor-pointer"
              >
                {salvando ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                <span>Salvar e Aplicar em Todo o SaaS</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Upload,
  CheckCircle2,
  Trash2,
  Image as ImageIcon,
  Palette,
  Eye,
  Store,
  Layers,
  Save,
  RotateCcw,
  ExternalLink,
  Sliders,
} from 'lucide-react';
import { SaasBranding } from '../../types';
import { AppStorage } from '../../lib/storage';
import { DataService } from '../../lib/supabase';
import { compressAndConvertToWebP } from '../../lib/imageCompressor';
import { DEMO_STORES_DATA, DemoSegmentId } from '../CustomerStore/DemoStoresData';

export default function TelaInicialDesignManager() {
  const [branding, setBranding] = useState<SaasBranding>(() => AppStorage.getSaasBranding());

  // Form states
  const [nomeMarca, setNomeMarca] = useState(branding.nome_marca || 'ARMONIX STORE');
  const [subtitulo, setSubtitulo] = useState(branding.subtitulo || 'Plataforma de Delivery & Catálogo Digital');
  const [logoUrl, setLogoUrl] = useState(branding.logo_url || '');
  const [bannerUrl, setBannerUrl] = useState(branding.banner_url || '');
  const [imagemHero, setImagemHero] = useState(branding.imagem_hero || '');
  const [tituloPrincipal, setTituloPrincipal] = useState(branding.titulo_principal || 'Veja como sua loja pode ficar na internet');
  const [badgeDestaque, setBadgeDestaque] = useState(branding.badge_destaque || 'Modelos Prontos • Simulação Completa em Tela Cheia');
  const [textoChamada, setTextoChamada] = useState(branding.texto_chamada || '');
  const [textoBotao, setTextoBotao] = useState(branding.texto_botao || 'Criar Meu Painel Agora');
  const [corPrimaria, setCorPrimaria] = useState(branding.cor_primaria || '#dc2626');

  // Imagens personalizadas dos segmentos da vitrine
  const [imagensVitrine, setImagensVitrine] = useState<Record<string, string>>(() => {
    return branding.imagens_vitrine || {};
  });

  const [segmentoEditando, setSegmentoEditando] = useState<DemoSegmentId>('conveniencia');
  const [carregandoUpload, setCarregandoUpload] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [feedback, setFeedback] = useState<{ tipo: 'sucesso' | 'erro'; texto: string } | null>(null);

  useEffect(() => {
    async function carregar() {
      try {
        const remote = await DataService.getSaasBranding();
        setBranding(remote);
        setNomeMarca(remote.nome_marca || 'ARMONIX STORE');
        setSubtitulo(remote.subtitulo || 'Plataforma de Delivery & Catálogo Digital');
        setLogoUrl(remote.logo_url || '');
        setBannerUrl(remote.banner_url || '');
        setImagemHero(remote.imagem_hero || '');
        setTituloPrincipal(remote.titulo_principal || 'Veja como sua loja pode ficar na internet');
        setBadgeDestaque(remote.badge_destaque || 'Modelos Prontos • Simulação Completa em Tela Cheia');
        setTextoChamada(remote.texto_chamada || '');
        setTextoBotao(remote.texto_botao || 'Criar Meu Painel Agora');
        setCorPrimaria(remote.cor_primaria || '#dc2626');
        setImagensVitrine(remote.imagens_vitrine || {});
      } catch {}
    }
    carregar();
  }, []);

  async function handleUploadArquivo(
    e: React.ChangeEvent<HTMLInputElement>,
    tipo: 'logo' | 'banner' | 'hero' | 'vitrine',
    chaveVitrine?: string
  ) {
    const file = e.target.files?.[0];
    if (!file) return;

    setCarregandoUpload(chaveVitrine || tipo);
    try {
      const result = await compressAndConvertToWebP(file, tipo === 'logo' ? 400 : 1200, 0.85);
      const dataUrl = result.dataUrl;

      if (tipo === 'logo') setLogoUrl(dataUrl);
      if (tipo === 'banner') setBannerUrl(dataUrl);
      if (tipo === 'hero') setImagemHero(dataUrl);
      if (tipo === 'vitrine' && chaveVitrine) {
        setImagensVitrine((prev) => ({ ...prev, [chaveVitrine]: dataUrl }));
      }

      mostrarFeedback('Imagem carregada com sucesso! Clique em "Salvar Alterações de Design" para aplicar.', 'sucesso');
    } catch {
      const reader = new FileReader();
      reader.onload = () => {
        const res = reader.result as string;
        if (tipo === 'logo') setLogoUrl(res);
        if (tipo === 'banner') setBannerUrl(res);
        if (tipo === 'hero') setImagemHero(res);
        if (tipo === 'vitrine' && chaveVitrine) {
          setImagensVitrine((prev) => ({ ...prev, [chaveVitrine]: res }));
        }
        mostrarFeedback('Imagem carregada localmente! Clique em Salvar.', 'sucesso');
      };
      reader.readAsDataURL(file);
    } finally {
      setCarregandoUpload(null);
    }
  }

  function mostrarFeedback(texto: string, tipo: 'sucesso' | 'erro' = 'sucesso') {
    setFeedback({ tipo, texto });
    setTimeout(() => setFeedback(null), 4500);
  }

  async function handleSalvar(e?: React.FormEvent) {
    if (e) e.preventDefault();
    setIsSaving(true);

    const payload: SaasBranding = {
      nome_marca: nomeMarca.trim() || 'ARMONIX STORE',
      subtitulo: subtitulo.trim(),
      logo_url: logoUrl.trim(),
      banner_url: bannerUrl.trim(),
      imagem_hero: imagemHero.trim(),
      titulo_principal: tituloPrincipal.trim(),
      badge_destaque: badgeDestaque.trim(),
      texto_chamada: textoChamada.trim(),
      texto_botao: textoBotao.trim(),
      cor_primaria: corPrimaria,
      imagens_vitrine: imagensVitrine,
    };

    try {
      AppStorage.saveSaasBranding(payload);
      try {
        await DataService.saveSaasBranding(payload);
      } catch {}
      setBranding(payload);
      mostrarFeedback('Design e imagens da Tela Inicial atualizados com sucesso!', 'sucesso');
    } catch (err: any) {
      mostrarFeedback('Erro ao salvar design.', 'erro');
    } finally {
      setIsSaving(false);
    }
  }

  function handleRestaurarPadroes() {
    if (!confirm('Deseja restaurar todas as imagens e textos do design para as configurações padrão?')) return;
    const defaults = AppStorage.getSaasBranding();
    setNomeMarca('ARMONIX STORE');
    setSubtitulo('Plataforma de Delivery & Catálogo Digital');
    setLogoUrl('');
    setBannerUrl('https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1200&auto=format&fit=crop&q=80');
    setImagemHero('https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1200&auto=format&fit=crop&q=80');
    setTituloPrincipal('Veja como sua loja pode ficar na internet');
    setBadgeDestaque('Modelos Prontos • Simulação Completa em Tela Cheia');
    setTextoChamada('Você pode ter uma página exclusiva e personalizada para sua empresa, com seus próprios produtos, fotos de alta qualidade, preços, cores, horários e link direto para o seu WhatsApp e painel de pedidos.');
    setTextoBotao('Criar Meu Painel Agora');
    setCorPrimaria('#dc2626');
    setImagensVitrine({});
    mostrarFeedback('Configurações padrão carregadas no formulário. Clique em Salvar para gravar.', 'sucesso');
  }

  const segmentosList: DemoSegmentId[] = [
    'acai',
    'espetinhos',
    'lanchonete',
    'conveniencia',
    'petshop',
    'manicure',
    'cosmeticos',
    'variedades',
  ];

  const presetsCores = [
    { nome: 'Vermelho Armonix', hex: '#dc2626' },
    { nome: 'Azul Real', hex: '#2563eb' },
    { nome: 'Roxo Moderno', hex: '#7c3aed' },
    { nome: 'Verde Esmeralda', hex: '#059669' },
    { nome: 'Laranja / Âmbar', hex: '#ea580c' },
    { nome: 'Preto & Grafite', hex: '#0f172a' },
  ];

  return (
    <div className="space-y-8">
      {/* Cabeçalho */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="bg-red-500/10 text-red-400 text-xs px-3 py-1 rounded-full font-bold border border-red-500/20 flex items-center gap-1.5">
              <Palette className="w-3.5 h-3.5" /> CONTROLE TOTAL DO DESIGN DA TELA INICIAL
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight">
            Gerenciador de Imagens & Design do SaaS
          </h2>
          <p className="text-slate-400 text-xs mt-1 max-w-2xl leading-relaxed">
            Como dono do SaaS, você tem controle total para personalizar imagens de capa, banner principal, vitrines de demonstração, textos, logotipo e cores da tela inicial.
          </p>
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <button
            type="button"
            onClick={handleRestaurarPadroes}
            className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer"
            title="Restaurar valores padrão"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Padrões</span>
          </button>
          <button
            type="button"
            onClick={() => handleSalvar()}
            disabled={isSaving}
            className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white text-xs font-extrabold rounded-xl transition shadow-lg flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'Salvando...' : 'Salvar Alterações'}</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div
          className={`p-4 rounded-2xl text-xs font-bold flex items-center gap-2.5 border shadow-md ${
            feedback.tipo === 'sucesso'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
              : 'bg-red-500/10 border-red-500/30 text-red-400'
          }`}
        >
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{feedback.texto}</span>
        </div>
      )}

      {/* Grid de Configurações */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Coluna da Esquerda: Formulários de Imagens & Textos */}
        <div className="lg:col-span-7 space-y-6">
          {/* Seção 1: Logotipo & Identidade Visual */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
              <div className="w-10 h-10 rounded-2xl bg-red-500/10 text-red-400 flex items-center justify-center border border-red-500/20">
                <Store className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm">1. Logotipo Oficial & Nome da Marca</h3>
                <p className="text-[11px] text-slate-400">Aparece no topo do SaaS, tela de login e cabeçalhos.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Nome da Marca</label>
                <input
                  type="text"
                  value={nomeMarca}
                  onChange={(e) => setNomeMarca(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-red-500"
                  placeholder="Ex: ARMONIX STORE"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Subtítulo do Header</label>
                <input
                  type="text"
                  value={subtitulo}
                  onChange={(e) => setSubtitulo(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-red-500"
                  placeholder="Ex: Plataforma de Delivery Multi-tenant"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Upload do Logotipo (PNG/JPG/WEBP ou Link)
              </label>
              <div className="flex flex-col sm:flex-row items-center gap-3">
                <label className="w-full sm:w-auto px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-xl transition flex items-center justify-center gap-2 cursor-pointer border border-slate-700 shrink-0">
                  <Upload className="w-4 h-4 text-red-400" />
                  <span>{carregandoUpload === 'logo' ? 'Enviando...' : 'Fazer Upload do Arquivo'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleUploadArquivo(e, 'logo')}
                    className="hidden"
                  />
                </label>
                <input
                  type="text"
                  value={logoUrl}
                  onChange={(e) => setLogoUrl(e.target.value)}
                  placeholder="Ou cole a URL direta da imagem do logotipo..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-red-500 font-mono"
                />
                {logoUrl && (
                  <button
                    type="button"
                    onClick={() => setLogoUrl('')}
                    className="p-2 text-red-400 hover:bg-slate-800 rounded-xl cursor-pointer"
                    title="Remover logotipo"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Seção 2: Imagens de Destaque da Tela Inicial (Hero & Banner) */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-400 flex items-center justify-center border border-amber-500/20">
                <ImageIcon className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm">2. Banner Principal & Imagem Hero da Tela Inicial</h3>
                <p className="text-[11px] text-slate-400">Controle as imagens principais que os visitantes veem ao abrir o site.</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                Imagem Hero / Mockup Principal
              </label>
              <div className="flex flex-col sm:flex-row items-center gap-3">
                <label className="w-full sm:w-auto px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-xl transition flex items-center justify-center gap-2 cursor-pointer border border-slate-700 shrink-0">
                  <Upload className="w-4 h-4 text-amber-400" />
                  <span>{carregandoUpload === 'hero' ? 'Enviando...' : 'Fazer Upload'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleUploadArquivo(e, 'hero')}
                    className="hidden"
                  />
                </label>
                <input
                  type="text"
                  value={imagemHero}
                  onChange={(e) => setImagemHero(e.target.value)}
                  placeholder="URL da imagem hero principal..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-red-500 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                Banner de Fundo / Capa Superior
              </label>
              <div className="flex flex-col sm:flex-row items-center gap-3">
                <label className="w-full sm:w-auto px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-xl transition flex items-center justify-center gap-2 cursor-pointer border border-slate-700 shrink-0">
                  <Upload className="w-4 h-4 text-red-400" />
                  <span>{carregandoUpload === 'banner' ? 'Enviando...' : 'Fazer Upload'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleUploadArquivo(e, 'banner')}
                    className="hidden"
                  />
                </label>
                <input
                  type="text"
                  value={bannerUrl}
                  onChange={(e) => setBannerUrl(e.target.value)}
                  placeholder="URL do banner de fundo..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-red-500 font-mono"
                />
              </div>
            </div>

            {/* Presets de Imagens em Alta Resolução */}
            <div className="pt-2">
              <span className="text-[11px] font-bold text-slate-400 block mb-2">
                Sugestões de Imagens de Alta Resolução (1 Clique):
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { nome: 'Restaurante Moderno', url: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1200&auto=format&fit=crop&q=80' },
                  { nome: 'Lanches & Hamburgueria', url: 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=1200&auto=format&fit=crop&q=80' },
                  { nome: 'Pizzaria Nobre', url: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=1200&auto=format&fit=crop&q=80' },
                  { nome: 'Delivery Gourmet', url: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=1200&auto=format&fit=crop&q=80' },
                ].map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setBannerUrl(preset.url);
                      setImagemHero(preset.url);
                    }}
                    className="p-1.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-red-500 transition text-left group cursor-pointer"
                  >
                    <img
                      src={preset.url}
                      alt={preset.nome}
                      className="w-full h-14 object-cover rounded-lg group-hover:scale-105 transition"
                    />
                    <span className="text-[10px] text-slate-300 font-medium block truncate mt-1">
                      {preset.nome}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Seção 3: Imagens dos Modelos da Vitrine (Conveniência, Pet Shop, etc.) */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
              <div className="w-10 h-10 rounded-2xl bg-blue-500/10 text-blue-400 flex items-center justify-center border border-blue-500/20">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm">3. Imagens da Vitrine de Modelos Prontos</h3>
                <p className="text-[11px] text-slate-400">
                  Mude individualmente as fotos de capa dos segmentos demonstrativos da tela inicial.
                </p>
              </div>
            </div>

            {/* Abas dos segmentos */}
            <div className="flex flex-wrap gap-1.5 p-1 bg-slate-950 rounded-2xl border border-slate-800">
              {segmentosList.map((segKey) => {
                const item = DEMO_STORES_DATA[segKey];
                const isSel = segmentoEditando === segKey;
                return (
                  <button
                    key={segKey}
                    type="button"
                    onClick={() => setSegmentoEditando(segKey)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                      isSel
                        ? 'bg-red-600 text-white shadow-md'
                        : 'text-slate-400 hover:text-white hover:bg-slate-900'
                    }`}
                  >
                    <span>{item.nome.split('&')[0].trim()}</span>
                  </button>
                );
              })}
            </div>

            {/* Editor do segmento selecionado */}
            {(() => {
              const demoInfo = DEMO_STORES_DATA[segmentoEditando];
              const fotoAtual = imagensVitrine[segmentoEditando] || demoInfo.bannerImg;
              return (
                <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-red-500" />
                      Modelo: <strong>{demoInfo.nome}</strong>
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      Segmento: {segmentoEditando}
                    </span>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-4 items-center">
                    <div className="w-full sm:w-36 h-24 rounded-xl overflow-hidden bg-slate-800 border border-slate-700 shrink-0 relative">
                      <img
                        src={fotoAtual}
                        alt={demoInfo.nome}
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute bottom-1 right-1 text-[9px] bg-black/70 px-1.5 py-0.5 rounded text-white font-mono">
                        Prévia
                      </span>
                    </div>

                    <div className="flex-1 space-y-2 w-full">
                      <div className="flex flex-col sm:flex-row gap-2">
                        <label className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer border border-slate-700 shrink-0">
                          <Upload className="w-3.5 h-3.5 text-blue-400" />
                          <span>{carregandoUpload === segmentoEditando ? 'Enviando...' : 'Trocar Foto'}</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleUploadArquivo(e, 'vitrine', segmentoEditando)}
                            className="hidden"
                          />
                        </label>
                        <input
                          type="text"
                          value={imagensVitrine[segmentoEditando] || ''}
                          onChange={(e) =>
                            setImagensVitrine((prev) => ({
                              ...prev,
                              [segmentoEditando]: e.target.value,
                            }))
                          }
                          placeholder="Ou cole o link direto da imagem..."
                          className="flex-1 bg-slate-900 border border-slate-700 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-red-500 font-mono"
                        />
                      </div>

                      {imagensVitrine[segmentoEditando] && (
                        <button
                          type="button"
                          onClick={() => {
                            setImagensVitrine((prev) => {
                              const copia = { ...prev };
                              delete copia[segmentoEditando];
                              return copia;
                            });
                          }}
                          className="text-[11px] text-red-400 hover:underline flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" /> Restaurar foto padrão deste modelo
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>

          {/* Seção 4: Textos de Impacto & Chamada da Tela Inicial */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
              <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center border border-emerald-500/20">
                <Sliders className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm">4. Textos de Apresentação & Chamadas</h3>
                <p className="text-[11px] text-slate-400">Personalize os slogans e mensagens exibidas na página inicial.</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Badge Superior</label>
              <input
                type="text"
                value={badgeDestaque}
                onChange={(e) => setBadgeDestaque(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-red-500"
                placeholder="Ex: Modelos Prontos • Simulação Completa"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Título Principal de Destaque</label>
              <input
                type="text"
                value={tituloPrincipal}
                onChange={(e) => setTituloPrincipal(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-red-500"
                placeholder="Ex: Veja como sua loja pode ficar na internet"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Texto de Chamada / Descrição</label>
              <textarea
                rows={3}
                value={textoChamada}
                onChange={(e) => setTextoChamada(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-red-500"
                placeholder="Explique os benefícios de criar uma loja online na sua plataforma..."
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Texto do Botão de Cadastro</label>
              <input
                type="text"
                value={textoBotao}
                onChange={(e) => setTextoBotao(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-red-500"
                placeholder="Ex: Cadastrar Nova Loja Grátis"
              />
            </div>

            {/* Cores & Tema */}
            <div className="pt-2">
              <label className="block text-xs font-bold text-slate-300 mb-2">
                Cor de Destaque do SaaS:
              </label>
              <div className="flex flex-wrap items-center gap-2">
                {presetsCores.map((cor) => {
                  const isSel = corPrimaria === cor.hex;
                  return (
                    <button
                      key={cor.hex}
                      type="button"
                      onClick={() => setCorPrimaria(cor.hex)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition cursor-pointer ${
                        isSel
                          ? 'border-white bg-slate-800 text-white shadow-md'
                          : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-white'
                      }`}
                    >
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-white/20"
                        style={{ backgroundColor: cor.hex }}
                      />
                      <span>{cor.nome}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Coluna da Direita: Prévia ao Vivo em Tempo Real */}
        <div className="lg:col-span-5 space-y-4">
          <div className="sticky top-20 bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white space-y-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-emerald-400" />
                <h3 className="font-extrabold text-sm">Prévia ao Vivo da Tela Inicial</h3>
              </div>
              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20">
                Live Preview
              </span>
            </div>

            {/* Miniatura da Tela Inicial */}
            <div className="rounded-2xl border border-slate-800 bg-slate-950 p-4 space-y-4 shadow-inner">
              {/* Header simulado */}
              <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
                <div className="flex items-center gap-2">
                  {logoUrl ? (
                    <img src={logoUrl} alt="Logo" className="w-6 h-6 rounded-lg object-contain bg-white/10" />
                  ) : (
                    <div
                      className="w-6 h-6 rounded-lg flex items-center justify-center text-white text-[10px] font-bold"
                      style={{ backgroundColor: corPrimaria }}
                    >
                      A
                    </div>
                  )}
                  <div>
                    <span className="font-extrabold text-xs text-white block leading-none">{nomeMarca}</span>
                    <span className="text-[9px] text-slate-400 block">{subtitulo}</span>
                  </div>
                </div>
                <span
                  className="text-[9px] font-bold px-2 py-0.5 rounded-full text-white"
                  style={{ backgroundColor: corPrimaria }}
                >
                  Entrar
                </span>
              </div>

              {/* Banner / Hero simulado */}
              <div className="relative rounded-xl overflow-hidden h-36 bg-slate-800">
                <img
                  src={bannerUrl || imagemHero || 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=600&auto=format&fit=crop&q=80'}
                  alt="Banner Hero"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent flex flex-col justify-end p-3">
                  <span className="text-[9px] font-black text-white/90 drop-shadow-sm line-clamp-1">
                    {badgeDestaque}
                  </span>
                  <h4 className="text-xs font-black text-white leading-tight drop-shadow-md line-clamp-2">
                    {tituloPrincipal}
                  </h4>
                </div>
              </div>

              {/* Texto de chamada simulado */}
              <p className="text-[10px] text-slate-400 line-clamp-2 leading-relaxed">
                {textoChamada || 'Página exclusiva e personalizada para sua empresa com produtos, fotos e pedidos.'}
              </p>

              {/* Botão de ação simulado */}
              <button
                type="button"
                className="w-full py-2.5 rounded-xl text-xs font-extrabold text-white shadow-md transition flex items-center justify-center gap-1.5"
                style={{ backgroundColor: corPrimaria }}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{textoBotao}</span>
              </button>

              {/* Vitrine mini */}
              <div className="pt-2 border-t border-slate-800/80">
                <span className="text-[10px] font-bold text-slate-400 block mb-2">
                  Prévia dos Modelos Prontos:
                </span>
                <div className="grid grid-cols-3 gap-1.5">
                  {segmentosList.slice(0, 3).map((segKey) => {
                    const item = DEMO_STORES_DATA[segKey];
                    const img = imagensVitrine[segKey] || item.bannerImg;
                    return (
                      <div key={segKey} className="rounded-lg overflow-hidden bg-slate-900 border border-slate-800">
                        <img src={img} alt={item.nome} className="w-full h-10 object-cover" />
                        <span className="block text-[8px] font-bold text-slate-300 p-1 truncate text-center">
                          {item.nome.split('&')[0]}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => handleSalvar()}
              disabled={isSaving}
              className="w-full py-3.5 bg-red-600 hover:bg-red-700 text-white text-xs font-black rounded-2xl transition shadow-xl flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? 'Salvando Alterações...' : 'Salvar Todo o Design Agora'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState, useEffect } from 'react';
import {
  Megaphone,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  AlertTriangle,
  Info,
  Sparkles,
  ToggleLeft,
  ToggleRight,
  Eye,
  Check,
  X,
} from 'lucide-react';
import { AvisoGlobal, AvisoTipo } from '../../types';
import { AppStorage } from '../../lib/storage';

export default function MuralAvisosManager() {
  const [avisos, setAvisos] = useState<AvisoGlobal[]>([]);
  const [modalAberto, setModalAberto] = useState(false);
  const [editandoId, setEditandoId] = useState<string | null>(null);

  const [titulo, setTitulo] = useState('');
  const [mensagem, setMensagem] = useState('');
  const [tipo, setTipo] = useState<AvisoTipo>('informativo');
  const [ativo, setAtivo] = useState(true);
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => {
    carregarAvisos();
    const handleUpdate = () => carregarAvisos();
    window.addEventListener('avisos_atualizados', handleUpdate);
    return () => window.removeEventListener('avisos_atualizados', handleUpdate);
  }, []);

  function carregarAvisos() {
    setAvisos(AppStorage.getAvisosGlobais());
  }

  function abrirModalCriacao() {
    setEditandoId(null);
    setTitulo('');
    setMensagem('');
    setTipo('informativo');
    setAtivo(true);
    setModalAberto(true);
  }

  function abrirModalEdicao(aviso: AvisoGlobal) {
    setEditandoId(aviso.id);
    setTitulo(aviso.titulo);
    setMensagem(aviso.mensagem);
    setTipo(aviso.tipo);
    setAtivo(aviso.ativo);
    setModalAberto(true);
  }

  function handleSalvar(e: React.FormEvent) {
    e.preventDefault();
    if (!titulo.trim() || !mensagem.trim()) return;

    const novoAviso: AvisoGlobal = {
      id: editandoId || `aviso-${Date.now()}`,
      titulo: titulo.trim(),
      mensagem: mensagem.trim(),
      tipo,
      ativo,
      data_criacao: editandoId
        ? avisos.find((a) => a.id === editandoId)?.data_criacao || new Date().toISOString()
        : new Date().toISOString(),
    };

    AppStorage.saveAvisoGlobal(novoAviso);
    setModalAberto(false);
    carregarAvisos();
    setFeedback(editandoId ? 'Comunicado atualizado!' : 'Comunicado publicado!');
    setTimeout(() => setFeedback(null), 3500);
  }

  const [avisoParaExcluir, setAvisoParaExcluir] = useState<{ id: string; titulo: string } | null>(null);

  function handleExcluir(id: string, titulo: string) {
    setAvisoParaExcluir({ id, titulo });
  }

  function confirmarExclusao() {
    if (!avisoParaExcluir) return;
    AppStorage.deleteAvisoGlobal(avisoParaExcluir.id);
    setAvisoParaExcluir(null);
    carregarAvisos();
    setFeedback('Aviso excluído com sucesso.');
    setTimeout(() => setFeedback(null), 3000);
  }

  function handleToggle(id: string) {
    AppStorage.toggleAvisoGlobal(id);
    carregarAvisos();
  }

  function getBadgeTipo(t: AvisoTipo) {
    switch (t) {
      case 'alerta':
        return {
          label: 'Alerta de Manutenção',
          bg: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
          icon: <AlertTriangle className="w-3 h-3" />,
        };
      case 'promocao':
        return {
          label: 'Oferta / Promoção',
          bg: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
          icon: <Sparkles className="w-3 h-3" />,
        };
      case 'informativo':
      default:
        return {
          label: 'Informativo Geral',
          bg: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
          icon: <Info className="w-3 h-3" />,
        };
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-purple-500/20 text-purple-400 text-xs px-2.5 py-0.5 rounded-full font-semibold border border-purple-500/30 flex items-center gap-1">
              <Megaphone className="w-3.5 h-3.5" /> COMUNICAÇÃO SUPER ADMIN
            </span>
          </div>
          <h2 className="text-xl font-black tracking-tight">Mural de Avisos Globais aos Lojistas</h2>
          <p className="text-slate-400 text-xs mt-0.5">
            Publique novidades ou alertas exibidos no topo do painel de todas as lojas.
          </p>
        </div>
        <button
          type="button"
          onClick={abrirModalCriacao}
          className="px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-extrabold transition shadow-md flex items-center gap-2 shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Criar Novo Comunicado</span>
        </button>
      </div>

      {feedback && (
        <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-200">
            Comunicados ({avisos.length})
          </h3>
        </div>

        {avisos.length === 0 ? (
          <div className="text-center py-10 bg-slate-950/40 rounded-xl border border-dashed border-slate-800 text-slate-400 text-xs space-y-2">
            <Megaphone className="w-8 h-8 text-slate-600 mx-auto" />
            <p>Nenhum comunicado criado ainda.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {avisos.map((aviso) => {
              const badge = getBadgeTipo(aviso.tipo);
              return (
                <div
                  key={aviso.id}
                  className={`p-4 rounded-xl border transition flex flex-col md:flex-row justify-between items-start md:items-center gap-4 ${
                    aviso.ativo
                      ? 'bg-slate-950/70 border-slate-800'
                      : 'bg-slate-950/30 border-slate-800/50 opacity-60'
                  }`}
                >
                  <div className="space-y-1.5 max-w-2xl">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border flex items-center gap-1 ${badge.bg}`}>
                        {badge.icon}
                        {badge.label}
                      </span>
                      <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                        aviso.ativo ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {aviso.ativo ? 'PUBLICADO' : 'INATIVO'}
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-white tracking-tight">{aviso.titulo}</h4>
                    <p className="text-xs text-slate-300 leading-relaxed">{aviso.mensagem}</p>
                  </div>
                  <div className="flex items-center gap-2 self-end md:self-center shrink-0">
                    <button
                      type="button"
                      onClick={() => handleToggle(aviso.id)}
                      className="p-2 rounded-lg text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 cursor-pointer"
                    >
                      {aviso.ativo ? <ToggleRight className="w-4 h-4 text-emerald-400" /> : <ToggleLeft className="w-4 h-4 text-slate-500" />}
                    </button>
                    <button
                      type="button"
                      onClick={() => abrirModalEdicao(aviso)}
                      className="p-2 rounded-lg text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 cursor-pointer"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleExcluir(aviso.id, aviso.titulo)}
                      className="p-2 rounded-lg text-xs bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 cursor-pointer"
                      title="Excluir comunicado"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {modalAberto && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl text-white space-y-5 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <h3 className="text-base font-black tracking-tight">
                {editandoId ? 'Editar Comunicado Global' : 'Novo Comunicado aos Lojistas'}
              </h3>
              <button
                type="button"
                onClick={() => setModalAberto(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSalvar} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Tipo de Comunicado:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setTipo('informativo')}
                    className={`p-2.5 rounded-xl border text-center font-bold flex flex-col items-center gap-1 cursor-pointer transition ${
                      tipo === 'informativo'
                        ? 'border-blue-500 bg-blue-500/20 text-blue-300'
                        : 'border-slate-800 bg-slate-950 text-slate-400'
                    }`}
                  >
                    <Info className="w-4 h-4 text-blue-400" />
                    <span>Informativo</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setTipo('alerta')}
                    className={`p-2.5 rounded-xl border text-center font-bold flex flex-col items-center gap-1 cursor-pointer transition ${
                      tipo === 'alerta'
                        ? 'border-amber-500 bg-amber-500/20 text-amber-300'
                        : 'border-slate-800 bg-slate-950 text-slate-400'
                    }`}
                  >
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                    <span>Manutenção</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setTipo('promocao')}
                    className={`p-2.5 rounded-xl border text-center font-bold flex flex-col items-center gap-1 cursor-pointer transition ${
                      tipo === 'promocao'
                        ? 'border-emerald-500 bg-emerald-500/20 text-emerald-300'
                        : 'border-slate-800 bg-slate-950 text-slate-400'
                    }`}
                  >
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    <span>Promoção</span>
                  </button>
                </div>
              </div>
              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Título:
                </label>
                <input
                  type="text"
                  required
                  value={titulo}
                  onChange={(e) => setTitulo(e.target.value)}
                  placeholder="Ex: Manutenção Programada"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-red-500 font-semibold"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Mensagem:
                </label>
                <textarea
                  required
                  rows={4}
                  value={mensagem}
                  onChange={(e) => setMensagem(e.target.value)}
                  placeholder="Escreva a mensagem..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-red-500 leading-relaxed resize-none"
                />
              </div>
              <div className="pt-3 flex gap-2 justify-end border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalAberto(false)}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold cursor-pointer transition"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl font-extrabold shadow-md cursor-pointer transition flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>{editandoId ? 'Atualizar' : 'Publicar'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {avisoParaExcluir && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-red-500/30 rounded-3xl p-6 max-w-md w-full shadow-2xl text-white space-y-4">
            <h3 className="text-base font-black text-white">Excluir Comunicado Global</h3>
            <p className="text-xs text-slate-300">
              Tem certeza que deseja excluir o aviso <strong>"{avisoParaExcluir.titulo}"</strong>? Esta ação removerá a mensagem do painel de todos os lojistas.
            </p>
            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setAvisoParaExcluir(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={confirmarExclusao}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1.5 shadow-md"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Confirmar Exclusão</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

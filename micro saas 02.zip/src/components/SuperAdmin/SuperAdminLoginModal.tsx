import { useState } from 'react';
import { ShieldCheck, KeyRound, ArrowRight, Eye, EyeOff, AlertCircle, User, X } from 'lucide-react';

interface SuperAdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  onNavigateTermos?: () => void;
}

export default function SuperAdminLoginModal({
  isOpen,
  onClose,
  onSuccess,
  onNavigateTermos,
}: SuperAdminLoginModalProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    const cleanUser = username.trim().toLowerCase();
    const cleanPass = password.trim();

    if (cleanUser === 'adileradm' && cleanPass === 'Adiler692233#') {
      sessionStorage.setItem('superadmin_authenticated', 'true');
      setUsername('');
      setPassword('');
      setLoading(false);
      onSuccess();
    } else {
      setLoading(false);
      setError('Credenciais inválidas. Verifique seu usuário e senha de Super Admin.');
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="max-w-md w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 relative animate-in zoom-in-95 duration-150">
        <button
          type="button"
          onClick={onClose}
          className="absolute right-5 top-5 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          title="Fechar"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-red-600/10 text-red-600 flex items-center justify-center mx-auto border border-red-600/20 shadow-inner">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
            Acesso Restrito Super Admin
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Painel exclusivo do proprietário da plataforma SaaS. Digite seu usuário e senha master para continuar.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              Usuário Super Admin
            </label>
            <div className="relative">
              <input
                type="text"
                required
                autoFocus
                autoCapitalize="none"
                autoCorrect="off"
                placeholder="Digite seu usuário..."
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl pl-9 pr-3 py-3 text-slate-900 dark:text-white focus:outline-none focus:border-red-500 font-medium"
              />
              <div className="absolute left-3 top-3.5 text-slate-400">
                <User className="w-4 h-4" />
              </div>
            </div>
          </div>
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              Senha Master de Acesso
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                placeholder="Digite sua senha master..."
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl pl-9 pr-10 py-3 text-slate-900 dark:text-white focus:outline-none focus:border-red-500 font-medium"
              />
              <div className="absolute left-3 top-3.5 text-slate-400">
                <KeyRound className="w-4 h-4" />
              </div>
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black transition shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <span>{loading ? 'Validando...' : 'Acessar Painel Master do SaaS'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <div className="pt-2 text-center space-y-2">
            <button
              type="button"
              onClick={onClose}
              className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-white transition cursor-pointer"
            >
              Cancelar e voltar
            </button>
            {onNavigateTermos && (
              <div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onNavigateTermos();
                  }}
                  className="text-[11px] text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition underline cursor-pointer"
                >
                  Termos de Uso e Privacidade • ARMONIX STORE
                </button>
              </div>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}

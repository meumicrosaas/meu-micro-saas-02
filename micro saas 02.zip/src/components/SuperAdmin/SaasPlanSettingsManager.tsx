import { useState, useEffect } from 'react';
import {
  Percent,
  Clock,
  CheckCircle2,
  Sliders,
  Wallet,
  CreditCard,
  Eye,
  EyeOff,
  DollarSign,
  Image as ImageIcon,
  Upload,
  RefreshCw,
  Sparkles,
  Store,
  Trash2,
} from 'lucide-react';
import { SaasPlanSettings, TipoChavePix, SaasBranding } from '../../types';
import { AppStorage } from '../../lib/storage';
import DataService from '../../lib/supabase';
import { compressAndConvertToWebP } from '../../lib/imageCompressor';

export default function SaasPlanSettingsManager() {
  const [settings, setSettings] = useState<SaasPlanSettings>(AppStorage.getSaasPlanSettings());
  const [branding, setBranding] = useState<SaasBranding>(AppStorage.getSaasBranding());

  const [diasTeste, setDiasTeste] = useState<number>(settings.dias_teste_padrao || 7);
  const [diasAntecipada, setDiasAntecipada] = useState<number>(settings.renovacao_antecipada_dias || 7);
  const [descontoPct, setDescontoPct] = useState<number>(settings.renovacao_antecipada_desconto_percentual || 15);
  const [valorMensalPadrao, setValorMensalPadrao] = useState<string>(
    (settings.valor_mensal_padrao || 169.99).toString()
  );

  // Branding da ARMONIX STORE (Tela Principal / Header / Login)
  const [brandingLogoUrl, setBrandingLogoUrl] = useState<string>(branding.logo_url || '');
  const [brandingSubtitulo, setBrandingSubtitulo] = useState<string>(
    branding.subtitulo || 'Plataforma de Delivery Multi-tenant'
  );
  const [carregandoImagem, setCarregandoImagem] = useState(false);

  const [pixTipoChave, setPixTipoChave] = useState<TipoChavePix>(settings.pix_tipo_chave || 'cnpj');
  const [pixChave, setPixChave] = useState<string>(settings.pix_chave || '');
  const [pixTitular, setPixTitular] = useState<string>(settings.pix_titular || '');
  const [pixBanco, setPixBanco] = useState<string>(settings.pix_banco || '');
  const [mpAccessToken, setMpAccessToken] = useState<string>(settings.mercadopago_access_token || '');
  const [abacatepayApiKey, setAbacatepayApiKey] = useState<string>(settings.abacatepay_api_key || '');
  const [showMpToken, setShowMpToken] = useState(false);
  const [showAbacateKey, setShowAbacateKey] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    async function carregar() {
      const current = await DataService.getSaasPlanSettings();
      setSettings(current);
      setDiasTeste(current.dias_teste_padrao || 7);
      setDiasAntecipada(current.renovacao_antecipada_dias || 7);
      setDescontoPct(current.renovacao_antecipada_desconto_percentual || 15);
      setValorMensalPadrao((current.valor_mensal_padrao || 169.99).toString());
      setPixTipoChave(current.pix_tipo_chave || 'cnpj');
      setPixChave(current.pix_chave || '');
      setPixTitular(current.pix_titular || '');
      setPixBanco(current.pix_banco || '');
      setMpAccessToken(current.mercadopago_access_token || '');
      setAbacatepayApiKey(current.abacatepay_api_key || '');

      const currentBrand = await DataService.getSaasBranding();
      setBranding(currentBrand);
      setBrandingLogoUrl(currentBrand.logo_url || '');
      setBrandingSubtitulo(currentBrand.subtitulo || 'Plataforma de Delivery Multi-tenant');
    }
    carregar();
  }, []);

  async function handleUploadImagemBranding(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    setCarregandoImagem(true);
    try {
      const result = await compressAndConvertToWebP(file, 600, 0.85);
      setBrandingLogoUrl(result.dataUrl);
      setFeedback('Imagem da tela principal carregada com sucesso! Clique em "Salvar Configurações".');
      setTimeout(() => setFeedback(null), 4000);
    } catch {
      // Fallback para FileReader simples
      const reader = new FileReader();
      reader.onload = () => {
        setBrandingLogoUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    } finally {
      setCarregandoImagem(false);
    }
  }

  function handleRemoverImagemBranding() {
    setBrandingLogoUrl('');
  }

  async function handleSalvar(e: React.FormEvent) {
    e.preventDefault();
    setIsSaving(true);
    const novodiasTeste = Math.max(1, Math.min(90, Number(diasTeste) || 7));
    const novoDiasAntecipada = Math.max(1, Math.min(30, Number(diasAntecipada) || 7));
    const novoDesconto = Math.max(0, Math.min(50, Number(descontoPct) || 15));
    const novoValorPadrao = Math.max(10, parseFloat(valorMensalPadrao) || 169.99);

    const updatedSettings: SaasPlanSettings = {
      dias_teste_padrao: novodiasTeste,
      renovacao_antecipada_dias: novoDiasAntecipada,
      renovacao_antecipada_desconto_percentual: novoDesconto,
      valor_mensal_padrao: Math.round(novoValorPadrao * 100) / 100,
      pix_tipo_chave: pixTipoChave,
      pix_chave: pixChave.trim(),
      pix_titular: pixTitular.trim(),
      pix_banco: pixBanco.trim(),
      mercadopago_access_token: mpAccessToken.trim(),
      abacatepay_api_key: abacatepayApiKey.trim(),
    };

    const updatedBranding: SaasBranding = {
      logo_url: brandingLogoUrl.trim(),
      nome_marca: 'ARMONIX STORE',
      subtitulo: brandingSubtitulo.trim(),
    };

    try {
      const savedSettings = await DataService.saveSaasPlanSettings(updatedSettings);
      setSettings(savedSettings);

      const savedBrand = await DataService.saveSaasBranding(updatedBranding);
      setBranding(savedBrand);

      setFeedback('Configurações do SaaS e Imagem da ARMONIX STORE salvas com sucesso!');
    } catch (err: any) {
      setFeedback(`Salvo com sucesso no armazenamento local!`);
    } finally {
      setIsSaving(false);
      setTimeout(() => setFeedback(null), 4000);
    }
  }

  const valorBase = parseFloat(valorMensalPadrao) || 169.99;
  const valorComDesconto = valorBase * (1 - descontoPct / 100);

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-emerald-500/20 text-emerald-400 text-xs px-2.5 py-0.5 rounded-full font-semibold border border-emerald-500/30 flex items-center gap-1">
              <Sliders className="w-3.5 h-3.5" /> GESTÃO DO SAAS & BRANDING
            </span>
          </div>
          <h2 className="text-xl font-black tracking-tight">Valores das Mensalidades & Imagem da ARMONIX STORE</h2>
          <p className="text-slate-400 text-xs mt-0.5">
            Defina o valor cobrado dos seus clientes, a imagem oficial da tela principal e os gateways de pagamento.
          </p>
        </div>
      </div>

      {feedback && (
        <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2 shadow-md">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      <form onSubmit={handleSalvar} className="space-y-6">
        {/* SEÇÃO 1: IMAGEM DA TELA PRINCIPAL ARMONIX STORE */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-500/10 text-red-500 flex items-center justify-center border border-red-500/20">
                <ImageIcon className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-extrabold tracking-tight">
                  Imagem da Tela Principal (ARMONIX STORE)
                </h3>
                <p className="text-xs text-slate-400">
                  Esta imagem / logotipo aparece na tela principal de entrada, no topo de todas as páginas e na tela de login dos lojistas.
                </p>
              </div>
            </div>
            {brandingLogoUrl && (
              <button
                type="button"
                onClick={handleRemoverImagemBranding}
                className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1 cursor-pointer bg-red-950/40 px-3 py-1.5 rounded-xl border border-red-900"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Restaurar Padrão</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  1. Fazer Upload de Imagem do seu Computador / Celular:
                </label>
                <label className="flex flex-col items-center justify-center p-4 border-2 border-dashed border-slate-700 hover:border-red-500 rounded-2xl cursor-pointer bg-slate-950/60 hover:bg-slate-950 transition text-center group">
                  <Upload className="w-6 h-6 text-slate-400 group-hover:text-red-500 mb-1 transition" />
                  <span className="text-xs font-bold text-slate-300">
                    {carregandoImagem ? 'Compactando foto...' : 'Clique para selecionar arquivo de imagem'}
                  </span>
                  <span className="text-[10px] text-slate-500 mt-0.5">PNG, JPG, WEBP (recomendado com fundo transparente ou 500x500)</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleUploadImagemBranding}
                    className="hidden"
                  />
                </label>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  2. Ou Cole a URL Direta da Imagem:
                </label>
                <input
                  type="url"
                  placeholder="https://exemplo.com/logo-armonix.png"
                  value={brandingLogoUrl}
                  onChange={(e) => setBrandingLogoUrl(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white text-xs font-mono focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Subtítulo Oficial do SaaS:
                </label>
                <input
                  type="text"
                  placeholder="Plataforma de Delivery Multi-tenant"
                  value={brandingSubtitulo}
                  onChange={(e) => setBrandingSubtitulo(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            {/* PREVIEW EM TEMPO REAL */}
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-3">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Pré-visualização em Tempo Real na Tela Principal:
              </span>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-3.5 shadow-inner">
                {brandingLogoUrl ? (
                  <img
                    src={brandingLogoUrl}
                    alt="ARMONIX STORE"
                    className="w-12 h-12 rounded-xl object-contain bg-white/5 border border-slate-700 shadow-md p-1"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-xl bg-red-600 text-white flex items-center justify-center font-black text-xl shadow-md">
                    A
                  </div>
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-black text-white tracking-tight">ARMONIX STORE</span>
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-sm bg-red-950 text-red-400 border border-red-900">
                      PRO
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 font-medium">
                    {brandingSubtitulo || 'Plataforma de Delivery Multi-tenant'}
                  </p>
                </div>
              </div>
              <p className="text-[11px] text-slate-500">
                Esta identidade visual será aplicada em todos os cabeçalhos, telas de login e telas de cadastro.
              </p>
            </div>
          </div>
        </div>

        {/* SEÇÃO 2: VALOR DA MENSALIDADE & PLANOS */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* VALOR MENSAL PADRÃO */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center border border-emerald-500/20">
                <DollarSign className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-extrabold tracking-tight">
                  Valor Mensal Cobrado dos Clientes
                </h3>
                <p className="text-[11px] text-slate-400">Preço padrão da mensalidade do SaaS</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Valor da Mensalidade (R$):
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-2.5 text-slate-400 font-bold text-sm">R$</span>
                <input
                  type="number"
                  step="0.01"
                  min="1"
                  value={valorMensalPadrao}
                  onChange={(e) => setValorMensalPadrao(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-3 py-2.5 text-white font-extrabold text-lg focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Valores Sugeridos:</span>
              <div className="flex flex-wrap gap-1.5">
                {['99.00', '149.00', '169.99', '199.00', '249.90'].map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setValorMensalPadrao(val)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                      valorMensalPadrao === val
                        ? 'bg-red-600 text-white'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                    }`}
                  >
                    R$ {parseFloat(val).toFixed(2)}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* PERÍODO DE TESTE */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center border border-blue-500/20">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-extrabold tracking-tight">
                  Período de Teste Grátis (Trial)
                </h3>
                <p className="text-[11px] text-slate-400">Dias de cortesia no cadastro inicial</p>
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-300">
                Duração do Teste:
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  min="1"
                  max="90"
                  value={diasTeste}
                  onChange={(e) => setDiasTeste(Number(e.target.value))}
                  className="w-28 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white font-bold text-base text-center focus:outline-none focus:border-red-500"
                />
                <span className="text-xs text-slate-400">dias grátis</span>
              </div>
              <p className="text-[11px] text-slate-500">
                Após este prazo, o lojista precisará pagar a mensalidade para continuar utilizando o painel.
              </p>
            </div>
          </div>

          {/* RENOVAÇÃO ANTECIPADA */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center border border-amber-500/20">
                <Percent className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-extrabold tracking-tight">
                  Desconto por Renovação Antecipada
                </h3>
                <p className="text-[11px] text-slate-400">Incentivo para pagamento adiantado</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Dias Antes:
                </label>
                <input
                  type="number"
                  min="1"
                  max="30"
                  value={diasAntecipada}
                  onChange={(e) => setDiasAntecipada(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-bold text-sm text-center"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Desconto (%):
                </label>
                <input
                  type="number"
                  min="0"
                  max="50"
                  value={descontoPct}
                  onChange={(e) => setDescontoPct(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-bold text-sm text-center"
                />
              </div>
            </div>

            <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-xs">
              <span className="text-slate-400">Com {descontoPct}% OFF:</span>{' '}
              <strong className="text-emerald-400 font-mono font-extrabold">
                R$ {valorComDesconto.toFixed(2)}
              </strong>
            </div>
          </div>
        </div>

        {/* SEÇÃO 3: RECEBIMENTO (PIX & GATEWAYS DO DONO) */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
            <div className="w-10 h-10 rounded-xl bg-red-500/10 text-red-400 flex items-center justify-center border border-red-500/20">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold tracking-tight">
                Gateways de Pagamento do Dono (Mercado Pago & Abacate Pay)
              </h3>
              <p className="text-xs text-slate-400">
                Receba os pagamentos das mensalidades dos seus clientes de forma automática via PIX ou Cartão. Assim que confirmado o pagamento, o acesso do cliente é liberado imediatamente.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Tipo de Chave PIX:
              </label>
              <select
                value={pixTipoChave}
                onChange={(e) => setPixTipoChave(e.target.value as TipoChavePix)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white font-semibold text-xs"
              >
                <option value="cnpj">CNPJ</option>
                <option value="cpf">CPF</option>
                <option value="email">E-mail</option>
                <option value="telefone">Telefone Celular</option>
                <option value="aleatoria">Chave Aleatória (EVP)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Chave PIX do Dono:
              </label>
              <input
                type="text"
                value={pixChave}
                onChange={(e) => setPixChave(e.target.value)}
                placeholder="Informe sua chave PIX..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white font-mono text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Nome do Titular / Beneficiário:
              </label>
              <input
                type="text"
                value={pixTitular}
                onChange={(e) => setPixTitular(e.target.value)}
                placeholder="Seu nome ou Razão Social"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Instituição Financeira / Banco:
              </label>
              <input
                type="text"
                value={pixBanco}
                onChange={(e) => setPixBanco(e.target.value)}
                placeholder="Ex: Nubank, Inter, Itaú"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white text-xs"
              />
            </div>
          </div>

          <div className="pt-2 border-t border-slate-800 space-y-4">
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-emerald-400" />
              <span>Credenciais das APIs de Baixa Automática</span>
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <div className="flex justify-between items-center">
                  <label className="font-bold text-xs text-blue-400">
                    Mercado Pago - Access Token (Dono do SaaS)
                  </label>
                  <span className="text-[10px] bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded-full font-semibold">
                    PIX & Cartão
                  </span>
                </div>
                <div className="relative">
                  <input
                    type={showMpToken ? 'text' : 'password'}
                    value={mpAccessToken}
                    onChange={(e) => setMpAccessToken(e.target.value)}
                    placeholder="APP_USR-0000000000000000-..."
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 pr-10 text-white font-mono text-xs focus:outline-none focus:border-blue-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowMpToken(!showMpToken)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-white cursor-pointer"
                  >
                    {showMpToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-[11px] text-slate-500">
                  Gera pagamentos de mensalidade com liberação automática após confirmação do webhook do Mercado Pago.
                </p>
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <div className="flex justify-between items-center">
                  <label className="font-bold text-xs text-green-400">
                    AbacatePay - API Key (Dono do SaaS)
                  </label>
                  <span className="text-[10px] bg-green-500/20 text-green-300 px-2 py-0.5 rounded-full font-semibold">
                    PIX Instantâneo
                  </span>
                </div>
                <div className="relative">
                  <input
                    type={showAbacateKey ? 'text' : 'password'}
                    value={abacatepayApiKey}
                    onChange={(e) => setAbacatepayApiKey(e.target.value)}
                    placeholder="aba_sec_00000000000000..."
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 pr-10 text-white font-mono text-xs focus:outline-none focus:border-green-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowAbacateKey(!showAbacateKey)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-white cursor-pointer"
                  >
                    {showAbacateKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-[11px] text-slate-500">
                  Gera pagamentos via AbacatePay com QR Code PIX e liberação instantânea de acesso ao painel do cliente.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={isSaving}
            className="px-6 py-3.5 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white rounded-xl text-xs font-extrabold transition shadow-lg cursor-pointer flex items-center gap-2 active:scale-95"
          >
            <Sparkles className="w-4 h-4" />
            <span>{isSaving ? 'Salvando Configurações...' : 'Salvar Todas as Configurações'}</span>
          </button>
        </div>
      </form>
    </div>
  );
}

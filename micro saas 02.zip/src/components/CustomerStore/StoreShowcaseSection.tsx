import React, { useState, useEffect } from 'react';
import {
  Store,
  Sparkles,
  ShoppingBag,
  ArrowRight,
  Eye,
  Check,
  Zap,
} from 'lucide-react';
import { DEMO_STORES_DATA, DemoSegmentId } from './DemoStoresData';
import DemoStoreModal from './DemoStoreModal';
import { AppStorage } from '../../lib/storage';
import { SaasBranding } from '../../types';

interface StoreShowcaseSectionProps {
  onNavigateToSignup: () => void;
}

export default function StoreShowcaseSection({
  onNavigateToSignup,
}: StoreShowcaseSectionProps) {
  const [modalAberto, setModalAberto] = useState(false);
  const [segmentoSelecionado, setSegmentoSelecionado] = useState<DemoSegmentId>('conveniencia');
  const [filtroSegmento, setFiltroSegmento] = useState<string>('todos');
  const [branding, setBranding] = useState<SaasBranding>(() => AppStorage.getSaasBranding());

  useEffect(() => {
    const handleBranding = () => setBranding(AppStorage.getSaasBranding());
    window.addEventListener('saas_branding_atualizado', handleBranding);
    return () => window.removeEventListener('saas_branding_atualizado', handleBranding);
  }, []);

  const segmentosList: DemoSegmentId[] = [
    'acai',
    'espetinhos',
    'lanchonete',
    'conveniencia',
    'petshop',
    'manicure',
    'cosmeticos',
    'variedades',
  ];

  const segmentosFiltrados = segmentosList.filter((s) => {
    if (filtroSegmento === 'todos') return true;
    return s === filtroSegmento;
  });

  function abrirDemo(segId: DemoSegmentId) {
    setSegmentoSelecionado(segId);
    setModalAberto(true);
  }

  return (
    <section className="py-12 space-y-10">
      {/* Banner Hero Customizável do SaaS pelo Dono */}
      {branding.banner_url && (
        <div className="max-w-5xl mx-auto px-4">
          <div className="relative rounded-3xl overflow-hidden h-44 sm:h-60 shadow-xl border border-slate-200 dark:border-slate-800">
            <img
              src={branding.banner_url}
              alt={branding.nome_marca || 'Banner Oficial'}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent flex flex-col justify-end p-6 text-white">
              <span className="text-xs font-bold text-red-400 uppercase tracking-wider">
                {branding.nome_marca || 'ARMONIX STORE'}
              </span>
              <h3 className="text-base sm:text-2xl font-black">
                {branding.titulo_principal || 'A Melhor Plataforma de Cardápio Digital & Delivery'}
              </h3>
            </div>
          </div>
        </div>
      )}

      {/* Cabeçalho da Vitrine Demonstrativa */}
      <div className="text-center space-y-3 max-w-3xl mx-auto px-4">
        <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-600 dark:text-red-400 text-xs font-bold tracking-wide shadow-xs">
          <Sparkles className="w-3.5 h-3.5" />
          <span>{branding.badge_destaque || 'Modelos Prontos • Simulação Completa em Tela Cheia'}</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-black tracking-tight text-slate-900 dark:text-white">
          {branding.titulo_principal || 'Veja como sua loja pode ficar na internet'}
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed max-w-2xl mx-auto">
          {branding.texto_chamada ||
            'Escolha seu segmento abaixo e experimente um modelo de loja digital interativa em Tela Cheia ou Modo Celular (Android & iPhone). Navegue por categorias, produtos e simule pedidos em tempo real.'}
        </p>

        {/* Barra de Filtros de Segmentos */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-3">
          <button
            type="button"
            onClick={() => setFiltroSegmento('todos')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              filtroSegmento === 'todos'
                ? 'bg-red-600 text-white shadow-md'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            Todos os Modelos
          </button>
          {segmentosList.map((segKey) => {
            const seg = DEMO_STORES_DATA[segKey];
            const isSel = filtroSegmento === segKey;
            return (
              <button
                key={segKey}
                type="button"
                onClick={() => setFiltroSegmento(segKey)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  isSel
                    ? 'bg-red-600 text-white shadow-md'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {seg.nome.split('&')[0].trim()}
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid de Cards dos Segmentos */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 px-2 sm:px-4">
        {segmentosFiltrados.map((segKey) => {
          const item = DEMO_STORES_DATA[segKey];
          const IconComp = item.icone;
          return (
            <div
              key={segKey}
              className="group bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-md hover:shadow-xl hover:border-red-500/50 dark:hover:border-red-500/50 transition duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Imagem de Capa com badge */}
                <div className="relative h-44 w-full overflow-hidden bg-slate-800">
                  <img
                    src={(branding.imagens_vitrine && branding.imagens_vitrine[segKey]) || item.bannerImg}
                    alt={item.nome}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-black/30" />

                  <div className="absolute top-3 left-3">
                    <span
                      className={`text-[10px] font-black px-2.5 py-1 rounded-full border shadow-xs flex items-center gap-1 ${item.corBadge}`}
                    >
                      <IconComp className="w-3 h-3" />
                      <span>{item.segmentoTitulo}</span>
                    </span>
                  </div>

                  <div className="absolute bottom-3 left-3 right-3 text-white flex items-center gap-2.5">
                    <img
                      src={item.logoImg}
                      alt={item.nomeLojaExemplo}
                      className="w-10 h-10 rounded-xl object-cover border-2 border-white/80 shadow-md"
                    />
                    <div>
                      <h3 className="text-sm font-black leading-tight text-white drop-shadow-xs">
                        {item.nomeLojaExemplo}
                      </h3>
                      <p className="text-[10px] text-slate-200 line-clamp-1">
                        {item.tagline}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Conteúdo do Card */}
                <div className="p-5 space-y-3">
                  <div className="space-y-1">
                    <h4 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                      {item.nome}
                    </h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                      {item.descricaoSegmento}
                    </p>
                  </div>

                  {/* Prévia de Produtos */}
                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                      Destaques na Vitrine:
                    </span>
                    <div className="space-y-1.5">
                      {item.produtos.slice(0, 2).map((p) => (
                        <div
                          key={p.id}
                          className="flex items-center justify-between text-xs bg-slate-50 dark:bg-slate-950/60 p-2 rounded-xl border border-slate-100 dark:border-slate-800/80"
                        >
                          <span className="font-medium text-slate-700 dark:text-slate-300 truncate max-w-[180px]">
                            {p.nome}
                          </span>
                          <span className="font-black text-slate-900 dark:text-white shrink-0">
                            R$ {p.preco.toFixed(2)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Botões de Ação */}
              <div className="p-5 pt-0 space-y-2">
                <button
                  type="button"
                  onClick={() => abrirDemo(segKey)}
                  className="w-full py-3.5 bg-red-600 hover:bg-red-700 text-white rounded-2xl text-xs font-black transition shadow-md flex items-center justify-center gap-2 group-hover:scale-[1.01] cursor-pointer active:scale-95"
                >
                  <Eye className="w-4 h-4" />
                  <span>Visualizar Loja Completa (Tela Cheia)</span>
                </button>
                <div className="flex items-center justify-center gap-2 text-[10px] text-slate-400 font-medium">
                  <span>📱 Celular Android & iPhone</span>
                  <span>•</span>
                  <span>💻 Computador</span>
                  <span>•</span>
                  <span className="text-emerald-500 font-bold">Interativo</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Seção de Conversão: Gostou do modelo? Podemos criar o seu */}
      <div className="mt-12 bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 text-white rounded-3xl p-6 sm:p-10 border border-slate-800 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-4xl mx-auto space-y-8">
          <div className="text-center space-y-2">
            <span className="text-xs font-black tracking-widest text-red-400 uppercase px-3 py-1 bg-red-500/10 rounded-full border border-red-500/20 inline-block">
              Personalização Completa Para Sua Marca
            </span>
            <h3 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Gostou do modelo? Podemos criar o seu!
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mx-auto leading-relaxed">
              Você pode ter uma página exclusiva e personalizada para sua empresa, com seus próprios produtos, fotos de alta qualidade, preços, cores, horários e link direto para o seu WhatsApp e painel de pedidos.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
            <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/60 space-y-1.5">
              <div className="w-8 h-8 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center font-bold text-xs">
                1
              </div>
              <h4 className="text-xs font-bold text-white">Seus Produtos & Preços</h4>
              <p className="text-[11px] text-slate-400">
                Cadastre seus itens, combos, promoções e fotos reais sem limites.
              </p>
            </div>

            <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/60 space-y-1.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
                2
              </div>
              <h4 className="text-xs font-bold text-white">Cálculo de Entrega no Mapa</h4>
              <p className="text-[11px] text-slate-400">
                Calcule o frete exato por quilômetro ou por bairros atendidos.
              </p>
            </div>

            <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/60 space-y-1.5">
              <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold text-xs">
                3
              </div>
              <h4 className="text-xs font-bold text-white">Seu Próprio Link Exclusivo</h4>
              <p className="text-[11px] text-slate-400">
                Divulgue sua loja no Instagram e receba pedidos organizados no WhatsApp.
              </p>
            </div>
          </div>

          {/* Botão rápido para cadastro imediato */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              type="button"
              onClick={onNavigateToSignup}
              className="w-full sm:w-auto px-8 py-3.5 bg-red-600 hover:bg-red-700 text-white font-black rounded-2xl text-xs uppercase tracking-wider transition shadow-xl flex items-center justify-center gap-2 cursor-pointer active:scale-95"
            >
              <Zap className="w-4 h-4" />
              <span>Quero Criar Minha Vitrine Grátis Agora</span>
            </button>
          </div>

          {/* Chamada para Ação Imediata: Crie seu Painel SaaS Instantaneamente */}
          <div className="bg-gradient-to-r from-red-950/60 via-slate-900 to-amber-950/60 border border-red-500/30 rounded-3xl p-6 sm:p-8 space-y-4 text-center sm:text-left flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="space-y-1.5 max-w-xl">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-black uppercase tracking-wider border border-emerald-500/30">
                <Check className="w-3 h-3" />
                <span>Ativação Instantânea • Sem Espera</span>
              </div>
              <h4 className="text-lg sm:text-xl font-black text-white">
                Crie seu painel completo e coloque sua loja no ar em minutos
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                Você mesmo configura seus produtos, fotos, valores de frete e horários pelo painel administrativo intuitivo. Teste todas as funções com período de teste grátis!
              </p>
            </div>

            <div className="w-full sm:w-auto shrink-0">
              <button
                type="button"
                onClick={onNavigateToSignup}
                className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-black rounded-2xl text-xs uppercase tracking-wider transition shadow-xl shadow-red-600/25 flex items-center justify-center gap-2 cursor-pointer active:scale-95"
              >
                <Zap className="w-4 h-4 fill-white" />
                <span>Criar Meu Painel Agora</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Modal de visualização detalhada da loja */}
      <DemoStoreModal
        segmentId={segmentoSelecionado}
        isOpen={modalAberto}
        onClose={() => setModalAberto(false)}
        onNavigateToSignup={onNavigateToSignup}
        onSwitchSegment={(newSeg) => setSegmentoSelecionado(newSeg)}
      />
    </section>
  );
}

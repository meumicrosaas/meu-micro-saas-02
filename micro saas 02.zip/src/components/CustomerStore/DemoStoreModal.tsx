import React, { useState, useEffect } from 'react';
import {
  ArrowRight,
  Eye,
  BadgeCheck,
  Search,
  ShoppingBag,
  Sparkles,
  Clock,
  MapPin,
  Phone,
  Plus,
  Minus,
  X,
  Check,
  Send,
  Calendar,
  ShieldCheck,
  Smartphone,
  Maximize2,
  ChevronRight,
  Sparkle,
} from 'lucide-react';
import { DemoCategoryInfo, DemoProductItem, DEMO_STORES_DATA, DemoSegmentId } from './DemoStoresData';

interface DemoStoreModalProps {
  segmentId: DemoSegmentId;
  isOpen: boolean;
  onClose: () => void;
  onNavigateToSignup: () => void;
  onSwitchSegment: (newSegment: DemoSegmentId) => void;
}

interface DemoCartItem {
  produto: DemoProductItem;
  quantidade: number;
}

export default function DemoStoreModal({
  segmentId,
  isOpen,
  onClose,
  onNavigateToSignup,
  onSwitchSegment,
}: DemoStoreModalProps) {
  if (!isOpen) return null;

  const storeInfo: DemoCategoryInfo = DEMO_STORES_DATA[segmentId] || DEMO_STORES_DATA.conveniencia;

  const [categoriaAtiva, setCategoriaAtiva] = useState<string>('Todos');
  const [busca, setBusca] = useState<string>('');
  const [carrinho, setCarrinho] = useState<DemoCartItem[]>([]);
  const [carrinhoAberto, setCarrinhoAberto] = useState<boolean>(false);
  const [agendamentoModal, setAgendamentoModal] = useState<DemoProductItem | null>(null);
  const [produtoDetalhesModal, setProdutoDetalhesModal] = useState<DemoProductItem | null>(null);
  const [qtdModal, setQtdModal] = useState<number>(1);
  const [sucessoSimulacao, setSucessoSimulacao] = useState<string | null>(null);
  const [modoVisualizacao, setModoVisualizacao] = useState<'fullscreen' | 'mobile'>('fullscreen');

  // Form agendamento / simulação
  const [nomeCliente, setNomeCliente] = useState('');
  const [dataHoraSimulada, setDataHoraSimulada] = useState('');

  // Fechar no ESC
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        if (produtoDetalhesModal) {
          setProdutoDetalhesModal(null);
        } else if (carrinhoAberto) {
          setCarrinhoAberto(false);
        } else if (agendamentoModal) {
          setAgendamentoModal(null);
        } else {
          onClose();
        }
      }
    }
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose, produtoDetalhesModal, carrinhoAberto, agendamentoModal]);

  const produtosFiltrados = storeInfo.produtos.filter((p) => {
    const matchCat = categoriaAtiva === 'Todos' || p.categoria === categoriaAtiva;
    const matchBusca =
      !busca.trim() ||
      p.nome.toLowerCase().includes(busca.toLowerCase()) ||
      p.descricao.toLowerCase().includes(busca.toLowerCase());
    return matchCat && matchBusca;
  });

  const totalItens = carrinho.reduce((sum, item) => sum + item.quantidade, 0);
  const totalValor = carrinho.reduce((sum, item) => sum + item.quantidade * item.produto.preco, 0);

  function adicionarAoCarrinho(prod: DemoProductItem, qtd: number = 1) {
    if (prod.tipoItem === 'servico') {
      setAgendamentoModal(prod);
      return;
    }

    setCarrinho((prev) => {
      const idx = prev.findIndex((i) => i.produto.id === prod.id);
      if (idx !== -1) {
        const novo = [...prev];
        novo[idx].quantidade += qtd;
        return novo;
      }
      return [...prev, { produto: prod, quantidade: qtd }];
    });
  }

  function alterarQtd(prodId: string, delta: number) {
    setCarrinho((prev) =>
      prev
        .map((i) => {
          if (i.produto.id === prodId) {
            const novaQtd = i.quantidade + delta;
            return novaQtd > 0 ? { ...i, quantidade: novaQtd } : null;
          }
          return i;
        })
        .filter(Boolean) as DemoCartItem[]
    );
  }

  function handleSimularPedido() {
    setSucessoSimulacao(
      `Demonstração: Pedido simulado com sucesso no valor de R$ ${totalValor.toFixed(
        2
      )}! Na loja real da sua empresa, esse pedido chegaria com som de alerta no painel do caixa e notificação no seu WhatsApp.`
    );
    setCarrinho([]);
    setCarrinhoAberto(false);
  }

  function handleSimularAgendamento(e: React.FormEvent) {
    e.preventDefault();
    if (!agendamentoModal) return;
    setSucessoSimulacao(
      `Demonstração: Agendamento de "${agendamentoModal.nome}" simulado com sucesso para ${
        nomeCliente || 'Cliente'
      }! No seu negócio real, os clientes agendam e você recebe a lista organizada de horários no painel.`
    );
    setAgendamentoModal(null);
    setNomeCliente('');
    setDataHoraSimulada('');
  }

  const segmentosList: DemoSegmentId[] = [
    'acai',
    'espetinhos',
    'lanchonete',
    'conveniencia',
    'petshop',
    'manicure',
    'cosmeticos',
    'variedades',
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950 text-slate-100 flex flex-col animate-in fade-in duration-200">
      {/* Barra de Controles Superior Fixa */}
      <header className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur-md border-b border-slate-800 px-3 sm:px-6 py-2.5 shadow-xl">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
          {/* Identificação da Demonstração */}
          <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-red-600/20 text-red-400 border border-red-500/30 rounded-xl flex items-center justify-center">
                <Eye className="w-4 h-4 text-red-400" />
              </span>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase tracking-wider bg-red-600 text-white px-2 py-0.5 rounded-full">
                    Vitrine Ao Vivo
                  </span>
                  <span className="text-xs font-bold text-white hidden sm:inline">
                    {storeInfo.nomeLojaExemplo}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Modelo para: <strong className="text-amber-400">{storeInfo.segmentoTitulo}</strong>
                </p>
              </div>
            </div>

            {/* Alternador de Modo: Tela Cheia vs Celular */}
            <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-1 gap-1">
              <button
                type="button"
                onClick={() => setModoVisualizacao('fullscreen')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  modoVisualizacao === 'fullscreen'
                    ? 'bg-amber-400 text-slate-950 font-black shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Visualização expandida em tela cheia total"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Tela Cheia</span>
              </button>
              <button
                type="button"
                onClick={() => setModoVisualizacao('mobile')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  modoVisualizacao === 'mobile'
                    ? 'bg-amber-400 text-slate-950 font-black shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Visualização simulada de Smartphone"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Modo Celular</span>
              </button>
            </div>
          </div>

          {/* Botões de Ação Direta */}
          <div className="flex items-center gap-2 w-full md:w-auto justify-end">
            {/* Botão Ver Pedido no Header */}
            <button
              type="button"
              onClick={() => setCarrinhoAberto(true)}
              className="relative px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer border border-slate-700"
            >
              <ShoppingBag className="w-3.5 h-3.5 text-amber-400" />
              <span>Pedido Simulado</span>
              {totalItens > 0 && (
                <span className="bg-red-600 text-white px-2 py-0.5 rounded-full font-black text-[10px]">
                  {totalItens} (R$ {totalValor.toFixed(2)})
                </span>
              )}
            </button>

            {/* Quero Criar Uma Para Mim */}
            <button
              type="button"
              onClick={onNavigateToSignup}
              className="px-4 py-1.5 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-extrabold rounded-xl transition shadow-md flex items-center gap-1.5 text-xs cursor-pointer active:scale-95"
            >
              <span>Quero Criar Uma Loja</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            {/* Fechar */}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl transition cursor-pointer"
              title="Fechar Demonstração (ESC)"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Switcher Rápido de Segmentos */}
        <div className="max-w-7xl mx-auto mt-2 pt-2 border-t border-slate-900 flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <span className="text-[11px] font-bold text-slate-400 whitespace-nowrap pl-1 pr-1">
            Trocar Segmento:
          </span>
          {segmentosList.map((segKey) => {
            const segItem = DEMO_STORES_DATA[segKey];
            const isAtivo = segKey === segmentId;
            const SegIcon = segItem.icone;
            return (
              <button
                key={segKey}
                type="button"
                onClick={() => {
                  onSwitchSegment(segKey);
                  setCategoriaAtiva('Todos');
                  setBusca('');
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                  isAtivo
                    ? 'bg-red-600 text-white shadow-md ring-2 ring-red-400'
                    : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800'
                }`}
              >
                <SegIcon className={`w-3.5 h-3.5 ${isAtivo ? 'text-white' : 'text-red-400'}`} />
                <span>{segItem.nome.split('&')[0].trim()}</span>
              </button>
            );
          })}
        </div>
      </header>

      {/* Conteúdo Principal da Loja Demonstrativa */}
      <main className="flex-1 w-full flex flex-col items-center">
        <div
          className={`w-full transition-all duration-300 ${
            modoVisualizacao === 'mobile'
              ? 'max-w-md mx-auto my-6 rounded-[2.5rem] border-8 border-slate-800 shadow-2xl overflow-hidden bg-white dark:bg-slate-900'
              : 'w-full bg-white dark:bg-slate-900'
          }`}
        >
          {/* Notch do Celular se estiver em modo mobile */}
          {modoVisualizacao === 'mobile' && (
            <div className="w-full bg-slate-900 py-1.5 flex justify-center items-center">
              <div className="w-24 h-3.5 bg-black rounded-full" />
            </div>
          )}

          {/* Banner de Topo da Loja */}
          <div className="relative h-52 sm:h-72 w-full overflow-hidden bg-slate-900">
            <img
              src={storeInfo.bannerImg}
              alt={storeInfo.nomeLojaExemplo}
              className="w-full h-full object-cover opacity-90"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/50 to-transparent" />

            <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <img
                  src={storeInfo.logoImg}
                  alt={storeInfo.nomeLojaExemplo}
                  className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-white dark:border-slate-700 shadow-xl bg-slate-800 shrink-0"
                />
                <div className="text-white space-y-1">
                  <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-emerald-500 text-white uppercase tracking-wider inline-flex items-center gap-1.5 shadow-xs">
                    <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                    Loja Aberta • Catálogo Online
                  </span>
                  <h1 className="text-xl sm:text-3xl font-black tracking-tight text-white drop-shadow-md">
                    {storeInfo.nomeLojaExemplo}
                  </h1>
                  <p className="text-xs text-slate-200 line-clamp-1 max-w-xl">
                    {storeInfo.tagline}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Faixa de Informações da Loja */}
          <div className="bg-slate-100 dark:bg-slate-950/80 border-b border-slate-200 dark:border-slate-800 px-4 sm:px-8 py-3 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600 dark:text-slate-400">
            <div className="flex flex-wrap items-center gap-4 sm:gap-6">
              <span className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-500" />
                <strong>Horário:</strong> {storeInfo.horario}
              </span>
              <span className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-red-500" />
                <strong>Endereço:</strong> {storeInfo.endereco}
              </span>
              <span className="flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-emerald-500" />
                <strong>WhatsApp:</strong> {storeInfo.telefone}
              </span>
            </div>

            <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>Armonix Store SaaS</span>
            </div>
          </div>

          {/* Mensagem de Simulação Concluída se houver */}
          {sucessoSimulacao && (
            <div className="m-4 sm:m-6 p-4 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-300 dark:border-emerald-800 rounded-2xl text-emerald-950 dark:text-emerald-100 text-xs space-y-2">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2 font-black text-sm text-emerald-700 dark:text-emerald-300">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Simulação Realizada com Sucesso!</span>
                </div>
                <button
                  type="button"
                  onClick={() => setSucessoSimulacao(null)}
                  className="text-emerald-600 hover:text-emerald-800 dark:hover:text-emerald-100"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="leading-relaxed">{sucessoSimulacao}</p>
              <div className="pt-2 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={onNavigateToSignup}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md"
                >
                  <span>Criar Minha Loja Oficial Agora</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => setSucessoSimulacao(null)}
                  className="text-xs text-emerald-700 dark:text-emerald-400 underline font-bold cursor-pointer"
                >
                  Continuar Explorando Itens da Demonstração
                </button>
              </div>
            </div>
          )}

          {/* Barra de Pesquisa e Filtros */}
          <div className="p-4 sm:p-6 space-y-4 border-b border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900">
            <div className="relative w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="text"
                placeholder={`Buscar produtos ou serviços em ${storeInfo.nomeLojaExemplo}...`}
                value={busca}
                onChange={(e) => setBusca(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl pl-10 pr-9 py-3 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-red-500 shadow-xs"
              />
              {busca && (
                <button
                  type="button"
                  onClick={() => setBusca('')}
                  className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Categorias com contadores */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
              {storeInfo.categoriasMenu.map((cat) => {
                const selecionada = categoriaAtiva === cat;
                const qtdCategoria =
                  cat === 'Todos'
                    ? storeInfo.produtos.length
                    : storeInfo.produtos.filter((p) => p.categoria === cat).length;
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setCategoriaAtiva(cat)}
                    className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                      selecionada
                        ? 'bg-red-600 text-white shadow-md ring-2 ring-red-400'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    <span>{cat}</span>
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded-full font-black ${
                        selecionada
                          ? 'bg-white text-red-600'
                          : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {qtdCategoria}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Grade Completa de Produtos em Tela Cheia */}
          <div className="p-4 sm:p-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <span>Itens na Vitrine Digital</span>
                <span className="text-xs text-slate-400 font-medium">
                  ({produtosFiltrados.length} disponíveis)
                </span>
              </h2>
              <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                💡 Clique em qualquer item para ver detalhes completos e opções
              </span>
            </div>

            {produtosFiltrados.length === 0 ? (
              <div className="py-16 text-center text-slate-400 text-xs space-y-3 bg-slate-50 dark:bg-slate-950 rounded-3xl border border-slate-200 dark:border-slate-800">
                <Search className="w-10 h-10 mx-auto text-slate-300" />
                <p className="text-sm font-bold text-slate-600 dark:text-slate-300">
                  Nenhum item encontrado para esta busca na demonstração.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setBusca('');
                    setCategoriaAtiva('Todos');
                  }}
                  className="px-4 py-2 bg-red-600 text-white font-bold rounded-xl text-xs cursor-pointer"
                >
                  Limpar filtros de busca
                </button>
              </div>
            ) : (
              <div
                className={`grid ${
                  modoVisualizacao === 'mobile'
                    ? 'grid-cols-1 sm:grid-cols-2 gap-4'
                    : 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5'
                }`}
              >
                {produtosFiltrados.map((item) => {
                  const noCarrinho = carrinho.find((c) => c.produto.id === item.id);
                  return (
                    <div
                      key={item.id}
                      className="group bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-3xl p-3.5 shadow-sm hover:shadow-xl hover:border-red-500/50 dark:hover:border-red-500/50 transition duration-300 flex flex-col justify-between gap-3 cursor-pointer"
                      onClick={() => {
                        setProdutoDetalhesModal(item);
                        setQtdModal(noCarrinho ? noCarrinho.quantidade : 1);
                      }}
                    >
                      <div className="space-y-3">
                        <div className="relative h-48 sm:h-52 rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-900">
                          <img
                            src={item.imagem}
                            alt={item.nome}
                            className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                            loading="lazy"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition duration-300 flex items-end p-2.5">
                            <span className="text-[10px] font-bold text-white bg-black/60 backdrop-blur-xs px-2 py-0.5 rounded-lg flex items-center gap-1">
                              <Eye className="w-3 h-3" /> Ver Detalhes
                            </span>
                          </div>
                          {item.destaque && (
                            <span className="absolute top-2.5 left-2.5 bg-red-600 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full shadow-sm">
                              ★ Destaque
                            </span>
                          )}
                          {item.tipoItem === 'servico' && (
                            <span className="absolute top-2.5 right-2.5 bg-purple-600 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full shadow-sm">
                              {item.duracao || 'Serviço'}
                            </span>
                          )}
                        </div>

                        <div>
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                            {item.categoria}
                          </span>
                          <h3 className="text-sm font-extrabold text-slate-900 dark:text-white line-clamp-2 leading-tight group-hover:text-red-500 transition">
                            {item.nome}
                          </h3>
                          <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mt-1 leading-relaxed">
                            {item.descricao}
                          </p>
                        </div>
                      </div>

                      <div
                        className="flex items-center justify-between gap-2 pt-3 border-t border-slate-100 dark:border-slate-800"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div>
                          {item.precoOriginal && (
                            <span className="text-[10px] line-through text-slate-400 block">
                              R$ {item.precoOriginal.toFixed(2)}
                            </span>
                          )}
                          <span className="text-base font-black text-slate-900 dark:text-white">
                            R$ {item.preco.toFixed(2)}
                          </span>
                        </div>

                        {item.tipoItem === 'servico' ? (
                          <button
                            type="button"
                            onClick={() => setAgendamentoModal(item)}
                            className="px-3.5 py-2 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl transition shadow-xs flex items-center gap-1.5 cursor-pointer active:scale-95"
                          >
                            <Calendar className="w-3.5 h-3.5" />
                            <span>Agendar</span>
                          </button>
                        ) : noCarrinho ? (
                          <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 rounded-xl p-1">
                            <button
                              type="button"
                              onClick={() => alterarQtd(item.id, -1)}
                              className="p-1 hover:bg-white dark:hover:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-200 transition cursor-pointer"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="text-xs font-black text-slate-900 dark:text-white px-1">
                              {noCarrinho.quantidade}
                            </span>
                            <button
                              type="button"
                              onClick={() => alterarQtd(item.id, 1)}
                              className="p-1 hover:bg-white dark:hover:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-200 transition cursor-pointer"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => adicionarAoCarrinho(item)}
                            className="px-3.5 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl transition shadow-xs flex items-center gap-1 cursor-pointer active:scale-95"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>Adicionar</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Painel de Vantagens e Conversão do Segmento */}
            <div className="mt-12 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 space-y-5">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-amber-500" />
                    <span>Pronto para ter este modelo para o seu negócio?</span>
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Painel completo com pedidos automáticos, impressão térmica e cardápio digital próprio para o segmento de{' '}
                    <strong className="text-red-500">{storeInfo.segmentoTitulo}</strong>.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={onNavigateToSignup}
                  className="px-6 py-3 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white text-xs font-black rounded-2xl transition shadow-lg flex items-center gap-2 shrink-0 cursor-pointer active:scale-95"
                >
                  <span>Cadastrar Minha Loja Grátis (7 Dias)</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-2">
                {storeInfo.beneficios.map((b, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800/90 p-3 rounded-2xl border border-slate-200 dark:border-slate-700/60 shadow-xs"
                  >
                    <BadgeCheck className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span className="font-medium">{b}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Rodapé da Loja Demonstrativa */}
          <footer className="p-6 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
            <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span>Vitrine Demonstrativa Armonix Store • Totalmente funcional para testes em tela cheia</span>
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 sm:flex-none px-5 py-2.5 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold rounded-xl transition cursor-pointer"
              >
                Voltar à Tela de Login
              </button>
              <button
                type="button"
                onClick={onNavigateToSignup}
                className="flex-1 sm:flex-none px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white font-extrabold rounded-xl transition shadow-md flex items-center justify-center gap-2 cursor-pointer active:scale-95"
              >
                <span>Criar Meu Painel Agora</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </footer>
        </div>
      </main>

      {/* Botão Flutuante de Carrinho no Canto Inferior Direito */}
      {totalItens > 0 && (
        <div className="fixed bottom-6 right-6 z-40 animate-in slide-in-from-bottom-4">
          <button
            type="button"
            onClick={() => setCarrinhoAberto(true)}
            className="px-5 py-3.5 bg-gradient-to-r from-red-600 to-rose-600 text-white rounded-2xl shadow-2xl flex items-center gap-3 cursor-pointer hover:scale-105 active:scale-95 transition ring-4 ring-red-500/20"
          >
            <div className="w-8 h-8 rounded-full bg-white text-red-600 flex items-center justify-center font-black text-xs shadow-xs">
              {totalItens}
            </div>
            <div className="text-left">
              <span className="text-[10px] uppercase font-bold text-red-100 block leading-tight">
                Pedido Simulado
              </span>
              <span className="text-sm font-black text-white">
                R$ {totalValor.toFixed(2)}
              </span>
            </div>
            <ChevronRight className="w-4 h-4 text-white" />
          </button>
        </div>
      )}

      {/* Modal de Detalhes Completos do Produto */}
      {produtoDetalhesModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="max-w-lg w-full bg-white dark:bg-slate-900 rounded-3xl overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="relative h-64 w-full bg-slate-900">
              <img
                src={produtoDetalhesModal.imagem}
                alt={produtoDetalhesModal.nome}
                className="w-full h-full object-cover"
              />
              <button
                type="button"
                onClick={() => setProdutoDetalhesModal(null)}
                className="absolute top-3 right-3 p-2 bg-black/60 hover:bg-black/80 text-white rounded-full transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
              {produtoDetalhesModal.destaque && (
                <span className="absolute top-3 left-3 bg-red-600 text-white text-xs font-black px-3 py-1 rounded-full shadow-md">
                  ★ Destaque Especial
                </span>
              )}
            </div>

            <div className="p-6 pt-2 space-y-4">
              <div>
                <span className="text-xs font-bold text-red-600 uppercase tracking-wider block">
                  {produtoDetalhesModal.categoria}
                </span>
                <h3 className="text-lg font-black text-slate-900 dark:text-white mt-1 leading-snug">
                  {produtoDetalhesModal.nome}
                </h3>
                <div className="flex items-baseline gap-2 mt-2">
                  {produtoDetalhesModal.precoOriginal && (
                    <span className="text-xs text-slate-400 line-through">
                      R$ {produtoDetalhesModal.precoOriginal.toFixed(2)}
                    </span>
                  )}
                  <span className="text-xl font-black text-slate-900 dark:text-white">
                    R$ {produtoDetalhesModal.preco.toFixed(2)}
                  </span>
                </div>
              </div>

              <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {produtoDetalhesModal.descricao}
              </div>

              {/* Seletor de Quantidade e Adição */}
              <div className="pt-2 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3 bg-slate-100 dark:bg-slate-800 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-700">
                  <button
                    type="button"
                    onClick={() => setQtdModal((q) => Math.max(1, q - 1))}
                    className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded-xl text-slate-600 dark:text-slate-300 cursor-pointer"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="font-black text-sm text-slate-900 dark:text-white px-2">
                    {qtdModal}
                  </span>
                  <button
                    type="button"
                    onClick={() => setQtdModal((q) => q + 1)}
                    className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded-xl text-slate-600 dark:text-slate-300 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    adicionarAoCarrinho(produtoDetalhesModal, qtdModal);
                    setProdutoDetalhesModal(null);
                  }}
                  className="flex-1 py-3 px-5 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-2xl transition shadow-md flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Adicionar (R$ {(produtoDetalhesModal.preco * qtdModal).toFixed(2)})</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Lateral do Carrinho Demonstrativo */}
      {carrinhoAberto && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex justify-end">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 h-full p-4 sm:p-6 flex flex-col justify-between shadow-2xl animate-in slide-in-from-right duration-200">
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-red-600" />
                  <h3 className="text-base font-black text-slate-900 dark:text-white">
                    Carrinho Demonstrativo
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setCarrinhoAberto(false)}
                  className="p-1 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl text-amber-800 dark:text-amber-300 text-[11px] leading-relaxed">
                <strong>Simulação ao Vivo:</strong> Este carrinho demonstra a rapidez e simplicidade com que os seus clientes farão pedidos na sua loja.
              </div>

              {carrinho.length === 0 ? (
                <div className="py-16 text-center text-slate-400 text-xs space-y-2">
                  <ShoppingBag className="w-10 h-10 mx-auto text-slate-300" />
                  <p className="font-bold text-slate-700 dark:text-slate-300">Seu carrinho demonstrativo está vazio.</p>
                  <p className="text-[11px] text-slate-500">Adicione produtos na vitrine para testar.</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-1">
                  {carrinho.map((item) => (
                    <div
                      key={item.produto.id}
                      className="p-3 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 text-xs"
                    >
                      <div className="flex items-center gap-2.5">
                        <img
                          src={item.produto.imagem}
                          alt={item.produto.nome}
                          className="w-12 h-12 rounded-xl object-cover"
                        />
                        <div>
                          <p className="font-bold text-slate-900 dark:text-white line-clamp-1">
                            {item.produto.nome}
                          </p>
                          <span className="text-slate-500 text-[11px]">
                            R$ {item.produto.preco.toFixed(2)} cada
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 bg-white dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
                        <button
                          type="button"
                          onClick={() => alterarQtd(item.produto.id, -1)}
                          className="p-1 text-slate-500 hover:text-slate-800"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="font-black text-xs px-1">{item.quantidade}</span>
                        <button
                          type="button"
                          onClick={() => alterarQtd(item.produto.id, 1)}
                          className="p-1 text-slate-500 hover:text-slate-800"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {carrinho.length > 0 && (
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between text-slate-500">
                    <span>Subtotal</span>
                    <span>R$ {totalValor.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Taxa de Entrega (Simulada)</span>
                    <span className="text-emerald-600 font-bold">Grátis</span>
                  </div>
                  <div className="flex justify-between text-base font-black text-slate-900 dark:text-white pt-1.5 border-t border-slate-200 dark:border-slate-800">
                    <span>Total Estimado</span>
                    <span className="text-red-600">R$ {totalValor.toFixed(2)}</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleSimularPedido}
                  className="w-full py-3.5 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-2xl transition shadow-lg flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                >
                  <Send className="w-4 h-4" />
                  <span>Simular Envio de Pedido no WhatsApp</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal de Simulação de Agendamento */}
      {agendamentoModal && (
        <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-purple-600" />
                <h3 className="text-base font-black text-slate-900 dark:text-white">
                  Simular Agendamento de Serviço
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setAgendamentoModal(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800">
              <img
                src={agendamentoModal.imagem}
                alt={agendamentoModal.nome}
                className="w-14 h-14 rounded-xl object-cover"
              />
              <div className="text-xs">
                <h4 className="font-bold text-slate-900 dark:text-white">
                  {agendamentoModal.nome}
                </h4>
                <p className="text-purple-600 font-bold mt-0.5">
                  R$ {agendamentoModal.preco.toFixed(2)} • {agendamentoModal.duracao || 'Serviço'}
                </p>
              </div>
            </div>

            <form onSubmit={handleSimularAgendamento} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Seu Nome (Simulação):
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Maria Eduarda"
                  value={nomeCliente}
                  onChange={(e) => setNomeCliente(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-xs text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Dia e Horário Desejado:
                </label>
                <input
                  type="datetime-local"
                  required
                  value={dataHoraSimulada}
                  onChange={(e) => setDataHoraSimulada(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-xs text-slate-900 dark:text-white"
                />
              </div>

              <div className="p-3 bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800 rounded-xl text-purple-800 dark:text-purple-300 text-[11px]">
                ℹ️ Esta é uma simulação de demonstração. Não há cobrança nem envio de mensagens reais.
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setAgendamentoModal(null)}
                  className="w-1/3 py-3 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="w-2/3 py-3 bg-purple-600 hover:bg-purple-700 text-white font-black rounded-xl transition shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>Confirmar Agendamento</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

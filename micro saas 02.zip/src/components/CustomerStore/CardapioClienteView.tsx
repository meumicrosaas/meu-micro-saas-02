import { useState, useEffect } from 'react';
import {
  ShoppingBag,
  Search,
  Clock,
  MapPin,
  Flame,
  Utensils,
  Pizza,
  Beer,
  X,
  MessageCircle,
  Instagram,
  Facebook,
  Plus,
  Minus,
  Check,
  QrCode,
  ArrowRight,
  CreditCard,
  Banknote,
  Sparkles,
  Phone,
  Store,
  AlertCircle,
  ArrowLeft,
  Copy,
  Zap,
} from 'lucide-react';
import { Loja, DeliveryType, PaymentMethod, ItemPedido, Pedido, Produto, Categoria, Cliente } from '../../types';
import { AppStorage } from '../../lib/storage';
import { DataService } from '../../lib/supabase';
import { calcularDistanciaHaversine, calcularTaxaEntrega, LOCAIS_TESTE, Coordinates } from '../../lib/haversine';
import { abrirWhatsAppLoja } from '../../lib/whatsapp';
import StoreLogoAvatar from '../Common/StoreLogoAvatar';
import PwaInstallBanner from './PwaInstallBanner';
import { useDynamicPwa } from '../../lib/useDynamicPwa';
import { sanitizeSlug } from '../../lib/slug';

interface CardapioClienteViewProps {
  slug?: string;
  globalLojas?: Loja[];
  globalActiveLoja?: Loja | null;
  onBackToAdmin?: () => void;
  onNavigateToSignup?: () => void;
}

interface ItemCarrinho {
  id: string;
  produtoId: string;
  nome: string;
  precoUnitario: number;
  quantidade: number;
  observacao?: string;
  total: number;
}

export default function CardapioClienteView({
  slug = '',
  globalLojas,
  globalActiveLoja,
  onBackToAdmin,
  onNavigateToSignup,
}: CardapioClienteViewProps) {
  const [loja, setLoja] = useState<Loja | null>(null);
  const [loading, setLoading] = useState(true);
  const [lojaNaoEncontrada, setLojaNaoEncontrada] = useState(false);
  const [categorias, setCategorias] = useState<Categoria[]>([]);

  useDynamicPwa(loja);

  const [produtos, setProdutos] = useState<Produto[]>([]);
  const [categoriaAtiva, setCategoriaAtiva] = useState<string>('todas');
  const [busca, setBusca] = useState<string>('');

  const [modalInfoAberto, setModalInfoAberto] = useState(false);
  const [carrinhoAberto, setCarrinhoAberto] = useState(false);
  const [carrinho, setCarrinho] = useState<ItemCarrinho[]>([]);
  const [etapaCheckout, setEtapaCheckout] = useState<'carrinho' | 'dados' | 'confirmado'>('carrinho');

  const [clienteNome, setClienteNome] = useState('');
  const [clienteTelefone, setClienteTelefone] = useState('');
  const [clienteEncontrado, setClienteEncontrado] = useState<Cliente | null>(null);
  const [tipoEntrega, setTipoEntrega] = useState<DeliveryType>('delivery');
  const [bairroSelecionadoId, setBairroSelecionadoId] = useState<string>('');
  const [enderecoDestino, setEnderecoDestino] = useState('Av. Afonso Pena, 1500 - Centro, Campo Grande');
  const [distanciaKm, setDistanciaKm] = useState<number>(2.8);
  const [taxaEntrega, setTaxaEntrega] = useState<number>(5.0);
  const [metodoPagamento, setMetodoPagamento] = useState<PaymentMethod>('pix_online');
  const [trocoPara, setTrocoPara] = useState('');
  const [pedidoConfirmado, setPedidoConfirmado] = useState<Pedido | null>(null);
  const [copiedOrderPix, setCopiedOrderPix] = useState(false);
  const [checkoutErro, setCheckoutErro] = useState<string | null>(null);

  useEffect(() => {
    let isCancelled = false;

    // Timer de segurança absoluta: nunca deixa a tela travada no spinner por mais de 1.2s
    const safetyTimer = setTimeout(() => {
      if (!isCancelled) {
        setLoading(false);
      }
    }, 1200);

    async function carregarDados() {
      try {
        setLojaNaoEncontrada(false);
        const raw = decodeURIComponent(slug || '').toLowerCase().trim();
        const cleanSlug = raw.replace(/^\/loja\//, '').replace(/^loja\//, '').replace(/\/$/, '');
        const sanitizedSlug = sanitizeSlug(cleanSlug);

        let l: Loja | null | undefined = null;

        // 1. Tentar encontrar por slug / ID em globalActiveLoja primeiro (0ms)
        if (globalActiveLoja) {
          const s = (globalActiveLoja.slug || '').toLowerCase().trim();
          const nome = (globalActiveLoja.nome_loja || globalActiveLoja.nome || '').toLowerCase().trim();
          if (
            !cleanSlug ||
            s === cleanSlug ||
            s === sanitizedSlug ||
            sanitizeSlug(s) === sanitizedSlug ||
            sanitizeSlug(nome) === sanitizedSlug ||
            globalActiveLoja.id === cleanSlug
          ) {
            l = globalActiveLoja;
          }
        }

        // 2. Tentar encontrar em globalLojas (0ms)
        if (!l && cleanSlug && globalLojas && globalLojas.length > 0) {
          l = globalLojas.find((store) => {
            const s = (store.slug || '').toLowerCase().trim();
            const nome = (store.nome_loja || store.nome || '').toLowerCase().trim();
            return (
              s === cleanSlug ||
              s === sanitizedSlug ||
              sanitizeSlug(s) === sanitizedSlug ||
              sanitizeSlug(nome) === sanitizedSlug ||
              store.id === cleanSlug
            );
          });
        }

        // 3. Tentar encontrar no AppStorage por slug ou ID (0ms)
        if (!l && cleanSlug) {
          l = AppStorage.getLojaBySlug(cleanSlug) || AppStorage.getLojaById(cleanSlug);
        }
        if (!l && cleanSlug) {
          const localLojas = AppStorage.getLojas();
          l = localLojas.find((store) => {
            const s = (store.slug || '').toLowerCase().trim();
            const nome = (store.nome_loja || store.nome || '').toLowerCase().trim();
            return (
              s === cleanSlug ||
              s === sanitizedSlug ||
              sanitizeSlug(s) === sanitizedSlug ||
              sanitizeSlug(nome) === sanitizedSlug ||
              store.id === cleanSlug
            );
          });
        }

        // 4. Se o lojista estiver autenticado e nenhum slug específico bateu, usar a loja autenticada
        if (!l) {
          const authLojaId = AppStorage.getAuthenticatedMerchantLojaId();
          if (authLojaId) {
            l = AppStorage.getLojaById(authLojaId) || (globalLojas || []).find((s) => s.id === authLojaId);
          }
        }

        // 5. Se ainda assim não encontrou e temos um slug específico, tentar Supabase com timeout curto de 1s
        if (!l && cleanSlug) {
          try {
            const remotePromise = DataService.getLojaBySlug(cleanSlug);
            const timeoutPromise = new Promise<null>((r) => setTimeout(() => r(null), 1000));
            const remoteStore = await Promise.race([remotePromise, timeoutPromise]);
            if (remoteStore) {
              l = remoteStore;
              AppStorage.saveOrUpdateLojaCache(remoteStore);
            }
          } catch {}
        }

        // 6. Fallback inteligente para a loja ativa do sistema
        if (!l) {
          const activeId = AppStorage.getActiveLojaId();
          if (activeId) {
            l = AppStorage.getLojaById(activeId);
          }
        }
        if (!l) {
          const todas = AppStorage.getLojas();
          if (todas.length > 0) {
            l = todas[0];
          }
        }

        if (isCancelled) return;

        if (!l) {
          setLoja(null);
          setCategorias([]);
          setProdutos([]);
          setLojaNaoEncontrada(true);
          setLoading(false);
          return;
        }

        // Loja encontrada: carregar imediatamente dados locais em 0ms
        setLoja(l);
        setLojaNaoEncontrada(false);

        let currentCats = AppStorage.getCategorias(l.id);
        let currentProds = AppStorage.getProdutos(l.id);

        if (currentCats.length === 0) {
          currentCats = AppStorage.inicializarCategoriasPadrao(l.id, l.segmento);
          currentProds = AppStorage.getProdutos(l.id);
        }

        setCategorias(currentCats);
        setProdutos(currentProds);
        setLoading(false); // Liberação imediata da tela em 0ms!

        // Sincronização em segundo plano não-bloqueante (timeout de 1.5s)
        try {
          const syncPromise = Promise.all([
            DataService.getCategorias(l.id),
            DataService.getProdutos(l.id),
          ]);
          const timeoutSync = new Promise<[Categoria[], Produto[]]>((r) =>
            setTimeout(() => r([currentCats, currentProds]), 1500)
          );
          const [cats, prods] = await Promise.race([syncPromise, timeoutSync]);
          if (isCancelled) return;

          let strictCats = (cats || []).filter((c) => c.loja_id === l.id || (c as any).store_id === l.id);
          let strictProds = (prods || []).filter((p) => p.loja_id === l.id || (p as any).store_id === l.id);

          if (strictCats.length > 0) {
            setCategorias(strictCats);
          }
          if (strictProds.length > 0) {
            setProdutos(strictProds);
          }
        } catch (err) {
          console.warn('[CardapioClienteView] Sincronização remota em background fallback:', err);
        }
      } catch (err) {
        console.error('[CardapioClienteView] Erro ao carregar cardápio:', err);
        // Fallback emergencial em caso de erro inesperado
        const emergencial = globalActiveLoja || AppStorage.getLojas()[0];
        if (emergencial && !isCancelled) {
          setLoja(emergencial);
          setCategorias(AppStorage.getCategorias(emergencial.id));
          setProdutos(AppStorage.getProdutos(emergencial.id));
        }
      } finally {
        if (!isCancelled) {
          setLoading(false);
        }
      }
    }

    carregarDados();

    const handleStorageChange = () => {
      carregarDados();
    };
    window.addEventListener('app_storage_change', handleStorageChange);
    return () => {
      isCancelled = true;
      clearTimeout(safetyTimer);
      window.removeEventListener('app_storage_change', handleStorageChange);
    };
  }, [slug, globalLojas, globalActiveLoja]);

  useEffect(() => {
    const limpo = clienteTelefone.replace(/\D/g, '');
    if (limpo.length >= 9 && loja) {
      const encontrado = AppStorage.findClienteByTelefone(loja.id, limpo);
      if (encontrado) {
        setClienteEncontrado(encontrado);
        if (!clienteNome) setClienteNome(encontrado.nome);
        if (encontrado.endereco && (!enderecoDestino || enderecoDestino === 'Av. Afonso Pena, 1500 - Centro, Campo Grande')) {
          const compl = [encontrado.endereco, encontrado.numero, encontrado.complemento, encontrado.bairro]
            .filter(Boolean)
            .join(', ');
          setEnderecoDestino(compl || encontrado.endereco);
        }
      } else {
        setClienteEncontrado(null);
      }
    } else {
      setClienteEncontrado(null);
    }
  }, [clienteTelefone, loja]);

  useEffect(() => {
    if (!loja) return;
    if (tipoEntrega === 'retirada') {
      setTaxaEntrega(0);
      return;
    }

    if (loja.taxas_bairros && loja.taxas_bairros.length > 0) {
      if (bairroSelecionadoId) {
        const found = loja.taxas_bairros.find((b) => b.id === bairroSelecionadoId);
        if (found) {
          setTaxaEntrega(found.taxa);
          return;
        }
      }
      const enderecoNorm = (enderecoDestino || '')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '');
      const matchBairro = loja.taxas_bairros.find((b) => {
        const bNorm = b.bairro
          .toLowerCase()
          .normalize('NFD')
          .replace(/[\u0300-\u036f]/g, '');
        return enderecoNorm.includes(bNorm);
      });
      if (matchBairro) {
        setTaxaEntrega(matchBairro.taxa);
        return;
      }
    }

    const origem: Coordinates = {
      lat: loja.endereco_origem?.lat !== undefined ? loja.endereco_origem.lat : -20.4697,
      lng: loja.endereco_origem?.lng !== undefined ? loja.endereco_origem.lng : -54.6201,
    };
    const destinoCoord: Coordinates = LOCAIS_TESTE.bairro_proximo
      ? { lat: LOCAIS_TESTE.bairro_proximo.lat, lng: LOCAIS_TESTE.bairro_proximo.lng }
      : { lat: -20.4697, lng: -54.6201 };
    const dist = calcularDistanciaHaversine(origem, destinoCoord);
    const taxa = calcularTaxaEntrega(
      dist,
      loja.taxa_base_entrega !== undefined ? loja.taxa_base_entrega : 5.0,
      loja.valor_por_km !== undefined ? loja.valor_por_km : 1.5
    );
    setDistanciaKm(dist);
    setTaxaEntrega(taxa);
  }, [tipoEntrega, loja, bairroSelecionadoId, enderecoDestino]);

  const horarios = [
    { dia: 'Segunda-feira', horario: '18:00 às 23:30' },
    { dia: 'Terça-feira', horario: '18:00 às 23:30' },
    { dia: 'Quarta-feira', horario: '18:00 às 23:30' },
    { dia: 'Quinta-feira', horario: '18:00 às 23:45' },
    { dia: 'Sexta-feira', horario: '11:30 às 15:00 | 18:00 às 00:30' },
    { dia: 'Sábado', horario: '12:00 às 01:00' },
    { dia: 'Domingo', horario: '12:00 às 23:30' },
  ];

  const taxasBairros = loja?.taxas_bairros && loja.taxas_bairros.length > 0
    ? loja.taxas_bairros.map((tb) => ({
        bairro: tb.bairro,
        prazo: '30-45 min',
        taxa: `R$ ${tb.taxa.toFixed(2)}`,
      }))
    : [
        { bairro: 'Centro / Bairro Próximo', prazo: '25-35 min', taxa: `R$ ${(loja?.taxa_base_entrega || 5.0).toFixed(2)}` },
        { bairro: 'Região Intermediária', prazo: '30-45 min', taxa: `R$ ${((loja?.taxa_base_entrega || 5.0) + (loja?.valor_por_km || 1.5) * 3).toFixed(2)}` },
      ];

  function getCategoryIcon(nomeCat: string) {
    const n = nomeCat.toLowerCase();
    if (n.includes('combo') || n.includes('oferta')) return Flame;
    if (n.includes('burger') || n.includes('hamb')) return Utensils;
    if (n.includes('pizza')) return Pizza;
    if (n.includes('bebida') || n.includes('cerveja')) return Beer;
    return Utensils;
  }

  const produtosDisponiveis = produtos.filter(
    (p) =>
      p.disponivel !== false &&
      p.ativo !== false &&
      (p.loja_id === loja?.id || (p as any).store_id === loja?.id)
  );
  const produtosExibidos = produtosDisponiveis.filter((p) => {
    const matchCat =
      categoriaAtiva === 'todas' ||
      p.categoria_id === categoriaAtiva;
    const matchBusca =
      !busca.trim() ||
      p.nome.toLowerCase().includes(busca.toLowerCase()) ||
      (p.descricao && p.descricao.toLowerCase().includes(busca.toLowerCase()));
    return matchCat && matchBusca;
  });

  function adicionarAoCarrinho(prod: Produto) {
    const valorUnitario = prod.preco_promocional || prod.preco;
    setCarrinho((prev) => {
      const idx = prev.findIndex((item) => item.produtoId === prod.id);
      if (idx !== -1) {
        const novo = [...prev];
        novo[idx].quantidade += 1;
        novo[idx].total = novo[idx].quantidade * novo[idx].precoUnitario;
        return novo;
      }
      return [
        ...prev,
        {
          id: `item-${Date.now()}-${Math.random().toString().slice(-4)}`,
          produtoId: prod.id,
          nome: prod.nome,
          precoUnitario: valorUnitario,
          quantidade: 1,
          total: valorUnitario,
        },
      ];
    });
  }

  function alterarQuantidade(itemCarrinhoId: string, delta: number) {
    setCarrinho((prev) =>
      prev
        .map((item) => {
          if (item.id === itemCarrinhoId) {
            const novaQtd = item.quantidade + delta;
            return {
              ...item,
              quantidade: novaQtd,
              total: novaQtd * item.precoUnitario,
            };
          }
          return item;
        })
        .filter((item) => item.quantidade > 0)
    );
  }

  const subtotal = carrinho.reduce((acc, curr) => acc + curr.total, 0);
  const total = subtotal + taxaEntrega;
  const totalItens = carrinho.reduce((acc, curr) => acc + curr.quantidade, 0);

  async function finalizarPedido() {
    setCheckoutErro(null);
    if (!clienteNome.trim() || !clienteTelefone.trim()) {
      setCheckoutErro('Por favor, informe seu nome e telefone WhatsApp para contato.');
      return;
    }
    if (!loja) return;

    const lojaAtiva = loja;
    const pedidoId = `ped-${Date.now()}`;
    const codigo = `#${Math.floor(1000 + Math.random() * 9000)}`;
    const itensParaStorage: ItemPedido[] = carrinho.map((c) => ({
      id: c.id,
      pedido_id: pedidoId,
      produto_id: c.produtoId,
      produto_nome: c.nome,
      quantidade: c.quantidade,
      preco_unitario: c.precoUnitario,
      total_item: c.total,
      opcionais: [],
      observacao: c.observacao,
    }));

    const novoPedido: Pedido = {
      id: pedidoId,
      loja_id: lojaAtiva.id,
      codigo_pedido: codigo,
      cliente_nome: clienteNome,
      cliente_telefone: clienteTelefone,
      tipo_entrega: tipoEntrega,
      endereco_destino: tipoEntrega === 'delivery' ? enderecoDestino : undefined,
      endereco_completo: tipoEntrega === 'delivery' ? enderecoDestino : 'Retirada no Balcão',
      distancia_km: tipoEntrega === 'delivery' ? Number(distanciaKm.toFixed(1)) : undefined,
      taxa_entrega: taxaEntrega,
      subtotal,
      total,
      status: 'pendente',
      status_pagamento: metodoPagamento === 'pix_online' ? 'pago' : 'pendente',
      metodo_pagamento: metodoPagamento,
      forma_pagamento: metodoPagamento,
      troco_para: metodoPagamento === 'dinheiro' && trocoPara ? Number(trocoPara) : undefined,
      impresso: false,
      pix_copia_cola:
        metodoPagamento === 'pix_online'
          ? `00020126580014br.gov.bcb.pix0136${lojaAtiva.chave_pix || '67981163697'}520400005303986540${total.toFixed(2)}5802BR5925${lojaAtiva.nome_loja}6009CAMPO GRA62070503***6304`
          : undefined,
      pix_qrcode_url:
        metodoPagamento === 'pix_online'
          ? `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=PIX_PAGAMENTO_${total.toFixed(2)}`
          : undefined,
      created_at: new Date().toISOString(),
      itens: itensParaStorage,
    };

    AppStorage.saveCliente({
      loja_id: lojaAtiva.id,
      nome: clienteNome,
      telefone: clienteTelefone,
      endereco: enderecoDestino,
    });
    await DataService.saveCliente({
      loja_id: lojaAtiva.id,
      nome: clienteNome,
      telefone: clienteTelefone,
      endereco: enderecoDestino,
    });

    AppStorage.addPedido(novoPedido);
    await DataService.createPedido(novoPedido);
    setPedidoConfirmado(novoPedido);
    setEtapaCheckout('confirmado');
  }

  if (loading && !loja) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 text-white">
        <div className="w-12 h-12 border-4 border-red-500 border-t-transparent rounded-full animate-spin mb-4" />
        <p className="text-sm text-slate-300 font-bold">Carregando cardápio oficial...</p>
        <button
          type="button"
          onClick={() => {
            const fallbackStore = globalActiveLoja || AppStorage.getLojas()[0];
            if (fallbackStore) {
              setLoja(fallbackStore);
              setCategorias(AppStorage.getCategorias(fallbackStore.id));
              setProdutos(AppStorage.getProdutos(fallbackStore.id));
            }
            setLoading(false);
          }}
          className="mt-4 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 hover:text-white rounded-xl transition cursor-pointer font-semibold border border-slate-700"
        >
          Demorando para carregar? Abrir cardápio agora
        </button>
      </div>
    );
  }

  if (lojaNaoEncontrada || !loja) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 text-white">
        <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl text-center space-y-6">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-500">
            <Store className="w-10 h-10" />
          </div>
          <div className="space-y-2">
            <span className="text-[11px] font-bold tracking-widest text-red-400 uppercase px-3 py-1 bg-red-500/10 rounded-full border border-red-500/20">
              Erro 404 • Não Encontrado
            </span>
            <h1 className="text-2xl font-black tracking-tight text-white pt-2">
              Loja não encontrada
            </h1>
            <p className="text-xs text-slate-400 leading-relaxed">
              Não encontramos nenhum cardápio ou estabelecimento cadastrado com o endereço{' '}
              <strong className="text-slate-200 font-mono">/loja/{slug || 'indefinido'}</strong>.
            </p>
          </div>
          <div className="space-y-2 pt-2">
            {onNavigateToSignup && (
              <button
                type="button"
                onClick={onNavigateToSignup}
                className="w-full py-3 px-4 bg-red-600 hover:bg-red-700 text-white text-xs font-black rounded-xl transition shadow-lg flex items-center justify-center gap-2 cursor-pointer active:scale-95"
              >
                <Plus className="w-4 h-4" /> Cadastrar Minha Loja Grátis
              </button>
            )}
            {onBackToAdmin && (
              <button
                type="button"
                onClick={onBackToAdmin}
                className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl transition border border-slate-700 flex items-center justify-center gap-2 cursor-pointer active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" /> Voltar ao Início
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  const nomeLoja = loja.nome_loja || loja.nome || 'Cardápio Digital';
  const telLoja = loja.telefone_whatsapp || loja.whatsapp || '';

  return (
    <div className="min-h-screen bg-gray-100 font-sans text-gray-800 pb-20">
      {loja && <PwaInstallBanner loja={loja} />}

      <div
        className={`${
          loja?.aberto !== false ? 'bg-emerald-600' : 'bg-red-600'
        } text-white px-4 py-2 text-xs flex flex-wrap justify-between items-center gap-2`}
      >
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-white animate-pulse" />
          <span className="font-bold">
            {loja?.aberto !== false
              ? 'Loja Aberta • Faça seu pedido online!'
              : 'Loja Fechada • No momento estamos fechados.'}
          </span>
        </div>
        <div className="flex items-center gap-4 text-xs font-semibold">
          <span>📞 {telLoja}</span>
        </div>
      </div>

      <header className="bg-white border-b sticky top-0 z-30 shadow-xs">
        <div className="max-w-5xl mx-auto px-4 py-3 flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3 w-full md:w-auto">
            <StoreLogoAvatar
              nomeLoja={nomeLoja}
              logoUrl={loja?.logo_url}
              size="md"
              className="ring-2 ring-red-600 shadow-xs"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-black text-gray-900 tracking-tight">{nomeLoja}</h1>
                <span
                  className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                    loja?.aberto !== false
                      ? 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                      : 'bg-red-100 text-red-600 border border-red-200'
                  }`}
                >
                  {loja?.aberto !== false ? 'ABERTO' : 'FECHADO'}
                </span>
              </div>
              <p className="text-xs text-gray-500">Cardápio Oficial de Delivery</p>
            </div>
          </div>
          <div className="flex items-center gap-2 w-full md:w-auto">
            <div className="relative flex-1 md:w-64">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-gray-400" />
              <input
                type="text"
                value={busca}
                onChange={(e) => setBusca(e.target.value)}
                placeholder="Buscar no cardápio..."
                className="w-full pl-9 pr-3 py-1.5 bg-gray-50 border border-gray-200 rounded-xl text-xs text-gray-800 focus:outline-none focus:border-red-500"
              />
            </div>
            <button
              type="button"
              onClick={() => setModalInfoAberto(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-xs rounded-xl transition shrink-0"
            >
              <Clock className="w-4 h-4 text-red-600" />
              <span>Info & Horários</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setEtapaCheckout('carrinho');
                setCarrinhoAberto(true);
              }}
              className="relative flex items-center gap-1.5 px-3.5 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl transition shrink-0 shadow-xs"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Carrinho</span>
              {totalItens > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-yellow-400 text-black font-black text-[10px] w-5 h-5 rounded-full flex items-center justify-center shadow-xs">
                  {totalItens}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-6 space-y-6">
        {Boolean(loja?.banner_oferta?.ativo) && (
          <div className="relative rounded-3xl overflow-hidden shadow-lg bg-linear-to-r from-red-950 via-red-900 to-amber-900 text-white p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 border border-red-800/40">
            <div className="space-y-3 z-10 max-w-xl text-center md:text-left">
              <div className="inline-flex items-center gap-1.5 bg-red-600/90 text-white text-xs font-black px-3 py-1 rounded-full uppercase tracking-wider shadow-xs">
                <Sparkles className="w-3.5 h-3.5 fill-yellow-300 text-yellow-300" />
                {loja?.banner_oferta?.badge_texto || '🔥 OFERTA DO DIA'}
              </div>
              <h2 className="text-2xl sm:text-3xl font-black tracking-tight leading-none text-white">
                {loja?.banner_oferta?.titulo || 'Festival do Smash Burger'}
              </h2>
              <p className="text-xs sm:text-sm text-red-100/90 leading-relaxed">
                {loja?.banner_oferta?.descricao ||
                  'Carne 100% Angus com crostinha crocante ultra selada na chapa, queijo cheddar derretido e pão brioche amanteigado.'}
              </p>
              <div className="pt-2 flex flex-wrap gap-2 justify-center md:justify-start">
                <button
                  type="button"
                  onClick={() => {
                    const prodId = loja?.banner_oferta?.produto_id;
                    const prod = prodId
                      ? produtosDisponiveis.find((p) => p.id === prodId)
                      : produtosDisponiveis[0];
                    if (prod) {
                      adicionarAoCarrinho(prod);
                      setCarrinhoAberto(true);
                    }
                  }}
                  className="px-5 py-2.5 bg-white text-red-900 hover:bg-gray-100 font-extrabold text-xs rounded-xl transition shadow-md flex items-center gap-1.5 cursor-pointer active:scale-95"
                >
                  Pedir Oferta <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <div className="w-48 h-40 sm:w-60 sm:h-48 rounded-2xl overflow-hidden shrink-0 shadow-2xl border-2 border-white/20">
              <img
                src={
                  loja?.banner_oferta?.imagem_url ||
                  'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80'
                }
                alt="Banner"
                className="w-full h-full object-cover hover:scale-105 transition duration-500"
              />
            </div>
          </div>
        )}

        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          <button
            type="button"
            onClick={() => setCategoriaAtiva('todas')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition shadow-xs ${
              categoriaAtiva === 'todas'
                ? 'bg-red-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200'
            }`}
          >
            <span>Todos os Itens</span>
            <span
              className={`text-[10px] px-2 py-0.5 rounded-full font-black ${
                categoriaAtiva === 'todas' ? 'bg-white text-red-600' : 'bg-gray-100 text-gray-600'
              }`}
            >
              {produtosDisponiveis.length}
            </span>
          </button>
          {categorias.map((cat) => {
            const Icone = getCategoryIcon(cat.nome);
            const qtdItens = produtosDisponiveis.filter((p) => p.categoria_id === cat.id).length;
            const isSelected = categoriaAtiva === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setCategoriaAtiva(cat.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition shadow-xs ${
                  isSelected
                    ? 'bg-red-600 text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200'
                }`}
              >
                <Icone className="w-4 h-4" />
                <span>{cat.nome}</span>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-black ${
                    isSelected ? 'bg-white text-red-600' : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  {qtdItens}
                </span>
              </button>
            );
          })}
        </div>

        <section className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-extrabold text-gray-900 text-base">Cardápio Oficial</h3>
            <span className="text-xs text-gray-500 font-medium">
              Mostrando {produtosExibidos.length} produtos
            </span>
          </div>
          {produtosDisponiveis.length === 0 ? (
            <div className="bg-white p-10 sm:p-14 rounded-3xl border border-dashed border-gray-300 text-center space-y-4 max-w-lg mx-auto my-6 shadow-xs">
              <div className="w-16 h-16 bg-red-50 text-red-600 rounded-3xl flex items-center justify-center mx-auto shadow-xs">
                <Store className="w-8 h-8" />
              </div>
              <div className="space-y-1.5">
                <h4 className="text-base font-black text-gray-900">
                  Cardápio em Montagem
                </h4>
                <p className="text-xs text-gray-500 leading-relaxed">
                  O lojista está cadastrando os produtos e novidades deste cardápio oficial. Em breve os itens estarão disponíveis para pedidos online!
                </p>
              </div>
              {onBackToAdmin && (
                <button
                  type="button"
                  onClick={onBackToAdmin}
                  className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition shadow-xs inline-flex items-center gap-1.5 cursor-pointer active:scale-95"
                >
                  <span>Acessar Painel para Cadastrar Produtos</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          ) : produtosExibidos.length === 0 ? (
            <div className="bg-white p-12 rounded-3xl border border-gray-200 text-center space-y-2">
              <p className="text-gray-500 text-sm font-semibold">
                Nenhum produto encontrado nesta categoria ou termo de busca.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {produtosExibidos.map((prod) => {
                const valorFinal = prod.preco_promocional || prod.preco;
                const temDesconto = prod.preco_promocional && prod.preco_promocional < prod.preco;
                return (
                  <div
                    key={prod.id}
                    className="bg-white rounded-3xl border border-gray-200 hover:border-red-300 shadow-xs hover:shadow-md transition overflow-hidden flex flex-col justify-between"
                  >
                    <div>
                      <div className="relative w-full h-44 bg-gray-100 overflow-hidden">
                        <img
                          src={prod.imagem_url || prod.imagem}
                          alt={prod.nome}
                          className="w-full h-full object-cover hover:scale-105 transition duration-300"
                          loading="lazy"
                        />
                        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1.5 z-10">
                          {prod.destaque_oferta && (
                            <span className="bg-amber-500 text-white font-extrabold text-[9px] px-2.5 py-0.5 rounded-full uppercase tracking-wide shadow-xs flex items-center gap-1">
                              <Flame className="w-3 h-3 fill-white" /> OFERTA
                            </span>
                          )}
                          {prod.destaque_mais_pedido && (
                            <span className="bg-red-600 text-white font-extrabold text-[9px] px-2.5 py-0.5 rounded-full uppercase tracking-wide shadow-xs">
                              ⭐ MAIS PEDIDO
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="p-4 space-y-1.5">
                        <h4 className="font-extrabold text-sm text-gray-900 leading-tight">
                          {prod.nome}
                        </h4>
                        <p className="text-xs text-gray-500 leading-relaxed line-clamp-2">
                          {prod.descricao}
                        </p>
                      </div>
                    </div>
                    <div className="p-4 pt-0 flex items-center justify-between">
                      <div>
                        {temDesconto && (
                          <span className="block text-[11px] text-gray-400 line-through">
                            R$ {prod.preco.toFixed(2)}
                          </span>
                        )}
                        <span className="text-base font-black text-emerald-600">
                          R$ {valorFinal.toFixed(2)}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => adicionarAoCarrinho(prod)}
                        className="px-3.5 py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl transition shadow-xs flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" /> Adicionar
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </main>

      <footer className="mt-12 border-t border-gray-200 bg-white py-8 px-4 text-center">
        <div className="max-w-5xl mx-auto space-y-3">
          <div className="flex items-center justify-center gap-2">
            <StoreLogoAvatar nomeLoja={nomeLoja} logoUrl={loja?.logo_url} size="sm" />
            <span className="font-bold text-gray-900 text-sm">{nomeLoja}</span>
          </div>
          <p className="text-xs text-gray-500">
            Cardápio online & Delivery automatizado. Todos os direitos reservados.
          </p>
          <div className="pt-4 border-t border-gray-100">
            <a
              href={`/admin?loja=${loja?.id || ''}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[11px] text-gray-400 hover:text-gray-600 transition underline decoration-dotted cursor-pointer inline-flex items-center gap-1.5"
            >
              <span>Área do Lojista</span>
            </a>
          </div>
        </div>
      </footer>

      {modalInfoAberto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto border border-gray-100">
            <div className="flex justify-between items-center border-b pb-3">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-red-600" />
                <h3 className="font-black text-base text-gray-900">Informações & Horários</h3>
              </div>
              <button
                type="button"
                onClick={() => setModalInfoAberto(false)}
                className="p-1 rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-2">
              <h4 className="font-extrabold text-xs text-gray-900 uppercase tracking-wider">
                Horários de Funcionamento
              </h4>
              <div className="bg-gray-50 rounded-2xl p-3 divide-y divide-gray-200/60 text-xs">
                {horarios.map((h, i) => (
                  <div key={i} className="py-1.5 flex justify-between">
                    <span className="font-semibold text-gray-700">{h.dia}</span>
                    <span className="text-gray-500 font-medium">{h.horario}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <h4 className="font-extrabold text-xs text-gray-900 uppercase tracking-wider">
                Bairros Atendidos & Taxas de Entrega
              </h4>
              <div className="bg-gray-50 rounded-2xl p-3 divide-y divide-gray-200/60 text-xs">
                {taxasBairros.map((b, i) => (
                  <div key={i} className="py-2 flex justify-between items-center">
                    <div>
                      <p className="font-bold text-gray-800">{b.bairro}</p>
                      <p className="text-[11px] text-gray-500">Prazo médio: {b.prazo}</p>
                    </div>
                    <span className="font-black text-red-600 bg-red-50 px-2 py-0.5 rounded-lg border border-red-200">
                      {b.taxa}
                    </span>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-3 pt-2 border-t">
              <div className="flex items-start gap-2 text-xs text-gray-600">
                <MapPin className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                <span>
                  {loja?.endereco_origem?.endereco_texto || 'Av. Afonso Pena, 1500 - Centro, Campo Grande - MS'}
                </span>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => abrirWhatsAppLoja(telLoja, 'Olá! Gostaria de tirar uma dúvida sobre o cardápio.')}
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" /> WhatsApp
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {carrinhoAberto && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
          <div className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col justify-between overflow-hidden">
            <div className="p-4 border-b flex justify-between items-center bg-gray-50">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-red-600" />
                <h3 className="font-black text-gray-900 text-base">
                  {etapaCheckout === 'confirmado'
                    ? 'Pedido Concluído!'
                    : etapaCheckout === 'dados'
                    ? 'Dados para Entrega'
                    : 'Meu Carrinho'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setCarrinhoAberto(false)}
                className="p-1 rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto flex-1 space-y-4 text-xs">
              {etapaCheckout === 'carrinho' && (
                <>
                  {carrinho.length === 0 ? (
                    <div className="py-20 text-center space-y-3">
                      <ShoppingBag className="w-12 h-12 text-gray-300 mx-auto" />
                      <p className="text-gray-500 font-bold">Seu carrinho está vazio.</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {carrinho.map((item) => (
                        <div
                          key={item.id}
                          className="bg-gray-50 p-3 rounded-2xl border border-gray-200 flex justify-between items-center"
                        >
                          <div className="space-y-0.5 max-w-[65%]">
                            <h4 className="font-bold text-gray-900">{item.nome}</h4>
                            <span className="text-gray-500 text-[11px]">
                              R$ {item.precoUnitario.toFixed(2)} cada
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => alterarQuantidade(item.id, -1)}
                              className="w-7 h-7 rounded-lg bg-white border border-gray-300 flex items-center justify-center font-bold text-gray-700 hover:bg-gray-100 cursor-pointer"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="font-black text-xs w-4 text-center">
                              {item.quantidade}
                            </span>
                            <button
                              type="button"
                              onClick={() => alterarQuantidade(item.id, 1)}
                              className="w-7 h-7 rounded-lg bg-red-600 text-white flex items-center justify-center font-bold hover:bg-red-700 shadow-xs cursor-pointer"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      ))}
                      <div className="pt-2">
                        <span className="font-bold text-gray-800 block mb-1.5">
                          Forma de Recebimento:
                        </span>
                        <div className="grid grid-cols-2 gap-2">
                          <button
                            type="button"
                            onClick={() => setTipoEntrega('delivery')}
                            className={`p-2.5 rounded-xl border font-bold text-xs transition cursor-pointer ${
                              tipoEntrega === 'delivery'
                                ? 'bg-red-50 border-red-500 text-red-900 shadow-xs'
                                : 'bg-white border-gray-200 text-gray-600'
                            }`}
                          >
                            🛵 Delivery ({taxaEntrega > 0 ? `+ R$ ${taxaEntrega.toFixed(2)}` : 'Frete Grátis'})
                          </button>
                          <button
                            type="button"
                            onClick={() => setTipoEntrega('retirada')}
                            className={`p-2.5 rounded-xl border font-bold text-xs transition cursor-pointer ${
                              tipoEntrega === 'retirada'
                                ? 'bg-red-50 border-red-500 text-red-900 shadow-xs'
                                : 'bg-white border-gray-200 text-gray-600'
                            }`}
                          >
                            🛍️ Retirada (Grátis)
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}

              {etapaCheckout === 'dados' && (
                <div className="space-y-4">
                  <div className="bg-red-50/70 p-3.5 rounded-2xl border border-red-200 space-y-2">
                    <div className="flex items-center gap-1.5 font-bold text-red-900">
                      <Phone className="w-4 h-4" />
                      <span>WhatsApp do Cliente</span>
                    </div>
                    <input
                      type="tel"
                      required
                      value={clienteTelefone}
                      onChange={(e) => setClienteTelefone(e.target.value)}
                      placeholder="Ex: (67) 99988-7766"
                      className="w-full p-2.5 bg-white border border-red-300 rounded-xl text-xs font-semibold focus:outline-none"
                    />
                    {clienteEncontrado && (
                      <div className="bg-emerald-50 border border-emerald-300 text-emerald-800 p-2 rounded-xl text-[11px] font-semibold flex items-center gap-1.5">
                        <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>Cliente frequente: <b>{clienteEncontrado.nome}</b></span>
                      </div>
                    )}
                  </div>

                  <div className="space-y-3 bg-gray-50 p-3.5 rounded-2xl border">
                    <div>
                      <label className="block font-bold text-gray-700 mb-1">Seu Nome Completo *</label>
                      <input
                        type="text"
                        required
                        value={clienteNome}
                        onChange={(e) => setClienteNome(e.target.value)}
                        placeholder="Nome e Sobrenome"
                        className="w-full p-2 bg-white border rounded-xl text-xs"
                      />
                    </div>
                    {tipoEntrega === 'delivery' && (
                      <div className="space-y-2">
                        <div>
                          <label className="block font-bold text-gray-700 mb-1">
                            Endereço Completo de Entrega *
                          </label>
                          <input
                            type="text"
                            required
                            value={enderecoDestino}
                            onChange={(e) => setEnderecoDestino(e.target.value)}
                            placeholder="Rua, Número, Bairro, Complemento"
                            className="w-full p-2 bg-white border rounded-xl text-xs"
                          />
                        </div>
                        <div className="p-2 bg-slate-50 border border-slate-200 rounded-xl text-[11px] text-slate-600 flex items-center justify-between">
                          <span>Taxa de Entrega:</span>
                          <span className="font-extrabold text-emerald-600 font-mono text-xs">
                            R$ {taxaEntrega.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="bg-gray-50 p-3.5 rounded-2xl border space-y-2">
                    <span className="font-bold text-gray-800 block">Forma de Pagamento:</span>
                    <div className="space-y-1.5">
                      {[
                        ...(loja.mercadopago_access_token
                          ? [
                              {
                                id: 'pix_online',
                                label: 'PIX Mercado Pago (Aprovação Imediata)',
                                icon: CreditCard,
                                badge: 'Mercado Pago',
                              },
                            ]
                          : []),
                        ...(loja.abacatepay_api_key
                          ? [
                              {
                                id: 'pix_online',
                                label: 'PIX AbacatePay (Instantâneo)',
                                icon: Zap,
                                badge: 'AbacatePay',
                              },
                            ]
                          : []),
                        ...(!loja.mercadopago_access_token && !loja.abacatepay_api_key
                          ? [
                              {
                                id: 'pix_online',
                                label: 'PIX (QR Code / Copia e Cola)',
                                icon: QrCode,
                                badge: 'PIX',
                              },
                            ]
                          : []),
                        { id: 'maquininha', label: 'Cartão na Entrega (Débito/Crédito)', icon: CreditCard },
                        { id: 'dinheiro', label: 'Dinheiro', icon: Banknote },
                      ].map((m, idx) => (
                        <label
                          key={`${m.id}-${idx}`}
                          className={`flex items-center justify-between p-2.5 rounded-xl border cursor-pointer transition ${
                            metodoPagamento === m.id
                              ? 'bg-red-50 border-red-500 text-red-900 font-bold'
                              : 'bg-white border-gray-200 text-gray-700'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <input
                              type="radio"
                              name="pagamento"
                              checked={metodoPagamento === m.id}
                              onChange={() => setMetodoPagamento(m.id as PaymentMethod)}
                              className="text-red-600 focus:ring-0"
                            />
                            <m.icon className="w-4 h-4 text-red-600 shrink-0" />
                            <span className="text-xs">{m.label}</span>
                          </div>
                          {(m as any).badge && (
                            <span className="text-[10px] bg-red-100 text-red-700 font-bold px-2 py-0.5 rounded-full">
                              {(m as any).badge}
                            </span>
                          )}
                        </label>
                      ))}
                    </div>
                  </div>

                  {checkoutErro && (
                    <div className="p-3 bg-red-500/10 border border-red-500/30 text-red-600 rounded-xl text-xs font-bold flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                      <span>{checkoutErro}</span>
                    </div>
                  )}
                </div>
              )}

              {etapaCheckout === 'confirmado' && pedidoConfirmado && (
                <div className="text-center space-y-4 py-4">
                  <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-xs">
                    <Check className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="text-base font-black text-gray-900">
                      Pedido Recebido com Sucesso!
                    </h4>
                    <p className="text-xs text-gray-500">
                      Código do Pedido: <b>{pedidoConfirmado.codigo_pedido}</b>
                    </p>
                    <p className="text-xs text-emerald-600 font-bold mt-0.5">
                      Total: R$ {pedidoConfirmado.total.toFixed(2)}
                    </p>
                  </div>

                  {/* Detalhes de Pagamento PIX (se PIX foi escolhido) */}
                  {pedidoConfirmado.pix_copia_cola && (
                    <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4 text-center space-y-3">
                      <div className="flex items-center justify-center gap-1.5 text-emerald-800 font-bold text-xs">
                        <QrCode className="w-4 h-4 text-emerald-600" />
                        <span>Pague com PIX para liberar o preparo</span>
                      </div>

                      {pedidoConfirmado.pix_qrcode_url && (
                        <div className="bg-white p-2.5 rounded-xl border border-emerald-200 w-36 h-36 mx-auto shadow-xs flex items-center justify-center">
                          <img
                            src={pedidoConfirmado.pix_qrcode_url}
                            alt="QR Code PIX"
                            className="w-full h-full object-contain"
                          />
                        </div>
                      )}

                      <div className="space-y-1.5 text-left">
                        <span className="text-[11px] font-semibold text-gray-700 block">
                          PIX Copia e Cola:
                        </span>
                        <div className="flex items-center gap-2 bg-white border border-emerald-200 rounded-xl p-2 font-mono text-[10px] text-gray-800">
                          <span className="truncate flex-1 select-all">
                            {pedidoConfirmado.pix_copia_cola}
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              if (pedidoConfirmado.pix_copia_cola) {
                                navigator.clipboard.writeText(pedidoConfirmado.pix_copia_cola);
                                setCopiedOrderPix(true);
                                setTimeout(() => setCopiedOrderPix(false), 3000);
                              }
                            }}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer shrink-0"
                          >
                            {copiedOrderPix ? (
                              <>
                                <Check className="w-3.5 h-3.5" />
                                <span>Copiado!</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3.5 h-3.5" />
                                <span>Copiar</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                      <p className="text-[10px] text-gray-500 text-center">
                        Abra o app do seu banco, escolha Pagar via PIX e cole o código acima.
                      </p>
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      const msg = `Olá! Acabei de fazer o pedido *${pedidoConfirmado.codigo_pedido}* no valor de R$ ${pedidoConfirmado.total.toFixed(2)}. Nome: ${pedidoConfirmado.cliente_nome}.`;
                      abrirWhatsAppLoja(telLoja, msg);
                    }}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4" /> Enviar Pedido no WhatsApp
                  </button>
                </div>
              )}
            </div>

            {carrinho.length > 0 && etapaCheckout !== 'confirmado' && (
              <div className="p-4 border-t bg-gray-50 space-y-3">
                <div className="space-y-1 text-xs text-gray-600">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span className="font-bold">R$ {subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Taxa de Entrega</span>
                    <span className="font-bold">
                      {taxaEntrega > 0 ? `R$ ${taxaEntrega.toFixed(2)}` : 'Grátis'}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm font-black text-gray-900 pt-1 border-t">
                    <span>Total</span>
                    <span className="text-emerald-600">R$ {total.toFixed(2)}</span>
                  </div>
                </div>
                {etapaCheckout === 'carrinho' && (
                  <button
                    type="button"
                    onClick={() => setEtapaCheckout('dados')}
                    className="w-full py-3 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs rounded-xl transition flex items-center justify-center gap-2 shadow-xs cursor-pointer"
                  >
                    Continuar para Entrega <ArrowRight className="w-4 h-4" />
                  </button>
                )}
                {etapaCheckout === 'dados' && (
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setEtapaCheckout('carrinho')}
                      className="w-1/3 py-3 bg-gray-200 text-gray-700 font-bold text-xs rounded-xl cursor-pointer"
                    >
                      Voltar
                    </button>
                    <button
                      type="button"
                      onClick={finalizarPedido}
                      className="w-2/3 py-3 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs rounded-xl transition shadow-xs cursor-pointer"
                    >
                      Confirmar Pedido (R$ {total.toFixed(2)})
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

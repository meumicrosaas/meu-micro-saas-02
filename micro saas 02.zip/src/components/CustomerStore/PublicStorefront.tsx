import { useState, useEffect } from 'react';
import {
  Search,
  ShoppingBag,
  Clock,
  MapPin,
  ChevronRight,
  Plus,
  Minus,
  X,
  Check,
  QrCode,
  CreditCard,
  Banknote,
  ShieldAlert,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';
import { Loja, Categoria, Produto, OpcionalProduto, DeliveryType, PaymentMethod, ItemPedido, Pedido } from '../../types';
import { AppStorage } from '../../lib/storage';
import { calcularDistanciaHaversine, calcularTaxaEntrega, LOCAIS_TESTE, Coordinates } from '../../lib/haversine';
import { abrirWhatsAppLoja } from '../../lib/whatsapp';

interface PublicStorefrontProps {
  slug: string;
  onBackToAdmin?: () => void;
}

interface ItemCarrinho {
  produto: Produto;
  quantidade: number;
  opcionais: OpcionalProduto[];
  observacao: string;
  totalItem: number;
}

export default function PublicStorefront({ slug }: PublicStorefrontProps) {
  const [loja, setLoja] = useState<Loja | null>(null);
  const [categorias, setCategorias] = useState<Categoria[]>([]);
  const [produtos, setProdutos] = useState<Produto[]>([]);
  const [categoriaAtiva, setCategoriaAtiva] = useState<string>('todas');
  const [busca, setBusca] = useState('');

  const [produtoModal, setProdutoModal] = useState<Produto | null>(null);
  const [qtdModal, setQtdModal] = useState(1);
  const [opcionaisSelecionados, setOpcionaisSelecionados] = useState<OpcionalProduto[]>([]);
  const [obsModal, setObsModal] = useState('');

  const [carrinho, setCarrinho] = useState<ItemCarrinho[]>([]);
  const [carrinhoAberto, setCarrinhoAberto] = useState(false);
  const [tipoEntrega, setTipoEntrega] = useState<DeliveryType>('delivery');

  const [localPredefinido, setLocalPredefinido] = useState<string>('bairro_proximo');
  const [enderecoDestino, setEnderecoDestino] = useState('Av. Afonso Pena, 1500 - Centro');
  const [clienteCoord, setClienteCoord] = useState<Coordinates>(LOCAIS_TESTE.bairro_proximo);

  const [clienteNome, setClienteNome] = useState('');
  const [clienteTelefone, setClienteTelefone] = useState('');
  const [metodoPagamento, setMetodoPagamento] = useState<PaymentMethod>('pix_online');
  const [trocoPara, setTrocoPara] = useState('');
  const [etapaCheckout, setEtapaCheckout] = useState<'carrinho' | 'pagamento' | 'confirmado'>('carrinho');
  const [pedidoConfirmado, setPedidoConfirmado] = useState<Pedido | null>(null);
  const [pixCopiado, setPixCopiado] = useState(false);

  useEffect(() => {
    const l = AppStorage.getLojaBySlug(slug) || AppStorage.getLojas()[0];
    if (l) {
      setLoja(l);
      setCategorias(AppStorage.getCategorias(l.id));
      setProdutos(AppStorage.getProdutos(l.id));
    }
  }, [slug]);

  if (!loja) {
    return (
      <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center p-4">
        <div className="text-center space-y-2">
          <p className="text-xl font-bold">Loja não encontrada</p>
          <p className="text-xs text-slate-400">Verifique o link digitado (/loja/{slug}).</p>
        </div>
      </div>
    );
  }

  if (loja.status_conta === 'bloqueada') {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 text-white">
        <div className="max-w-md w-full bg-slate-900 border border-red-500/40 rounded-3xl p-8 text-center space-y-5 shadow-2xl">
          <div className="p-4 bg-red-500/10 text-red-500 rounded-full w-fit mx-auto border border-red-500/20">
            <ShieldAlert className="w-12 h-12" />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-black tracking-tight">{loja.nome_loja}</h2>
            <p className="text-base font-bold text-red-400">Esta loja está temporariamente indisponível.</p>
            <p className="text-xs text-slate-400 leading-relaxed">
              O catálogo de produtos e os pedidos estão suspensos no momento. Se você é o proprietário, acesse o painel administrativo para reativar seu serviço.
            </p>
          </div>
          <div className="pt-2">
            <a
              href="/admin"
              className="inline-flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold px-5 py-2.5 rounded-xl border border-slate-700 transition"
            >
              Sou o Lojista: Acessar Painel <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>
    );
  }

  const distanciaKm = tipoEntrega === 'delivery'
    ? calcularDistanciaHaversine(loja.endereco_origem, clienteCoord)
    : 0;
  const taxaEntrega = tipoEntrega === 'delivery'
    ? calcularTaxaEntrega(distanciaKm, loja.taxa_base_entrega, loja.valor_por_km)
    : 0;
  const subtotal = carrinho.reduce((acc, it) => acc + it.totalItem, 0);
  const total = subtotal + taxaEntrega;
  const totalItensCarrinho = carrinho.reduce((acc, it) => acc + it.quantidade, 0);

  const produtosFiltrados = produtos.filter((p) => {
    const matchCat = categoriaAtiva === 'todas' || p.categoria_id === categoriaAtiva;
    const matchBusca =
      p.nome.toLowerCase().includes(busca.toLowerCase()) ||
      p.descricao.toLowerCase().includes(busca.toLowerCase());
    return matchCat && matchBusca && p.disponivel;
  });

  function abrirModalProduto(p: Produto) {
    setProdutoModal(p);
    setQtdModal(1);
    setOpcionaisSelecionados([]);
    setObsModal('');
  }

  function handleAdicionarItemModal() {
    if (!produtoModal) return;
    const totalUnitario =
      produtoModal.preco +
      opcionaisSelecionados.reduce((acc, op) => acc + op.preco_adicional, 0);
    const novoItem: ItemCarrinho = {
      produto: produtoModal,
      quantidade: qtdModal,
      opcionais: opcionaisSelecionados,
      observacao: obsModal,
      totalItem: totalUnitario * qtdModal,
    };
    setCarrinho([...carrinho, novoItem]);
    setProdutoModal(null);
    setCarrinhoAberto(true);
  }

  function toggleOpcional(op: OpcionalProduto) {
    const exists = opcionaisSelecionados.some((o) => o.id === op.id);
    if (exists) {
      setOpcionaisSelecionados(opcionaisSelecionados.filter((o) => o.id !== op.id));
    } else {
      setOpcionaisSelecionados([...opcionaisSelecionados, op]);
    }
  }

  function handleFinalizarPedido(e: React.FormEvent) {
    e.preventDefault();
    if (carrinho.length === 0 || !loja) return;
    const itensPedido: ItemPedido[] = carrinho.map((ci, idx) => ({
      id: `item-${Date.now()}-${idx}`,
      pedido_id: '',
      produto_id: ci.produto.id,
      produto_nome: ci.produto.nome,
      quantidade: ci.quantidade,
      preco_unitario: ci.produto.preco,
      observacao: ci.observacao,
      opcionais: ci.opcionais.map((o) => ({
        nome_opcao: o.nome_opcao,
        preco_adicional: o.preco_adicional,
      })),
      total_item: ci.totalItem,
    }));
    const novoPed = AppStorage.addPedido({
      loja_id: loja.id,
      cliente_nome: clienteNome,
      cliente_telefone: clienteTelefone,
      tipo_entrega: tipoEntrega,
      endereco_destino: tipoEntrega === 'delivery' ? enderecoDestino : undefined,
      distancia_km: distanciaKm,
      taxa_entrega: taxaEntrega,
      subtotal,
      total,
      status: 'pendente',
      status_pagamento: metodoPagamento === 'pix_online' ? 'pago' : 'pendente',
      metodo_pagamento: metodoPagamento,
      troco_para: trocoPara ? parseFloat(trocoPara) : undefined,
      impresso: false,
      pix_copia_cola: '00020126580014BR.GOV.BCB.PIX0136' + Math.random().toString().slice(2, 12),
      itens: itensPedido,
    });
    setPedidoConfirmado(novoPed);
    setEtapaCheckout('confirmado');
    setCarrinho([]);
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white font-sans pb-28">
      <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-xs sticky top-0 z-30">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            {loja.logo_url ? (
              <img
                src={loja.logo_url}
                alt={loja.nome_loja}
                className="w-12 h-12 rounded-2xl object-cover border border-slate-200 dark:border-slate-700 shadow-xs"
              />
            ) : (
              <div className="w-12 h-12 rounded-2xl bg-red-600 text-white font-black text-lg flex items-center justify-center">
                {loja.nome_loja.slice(0, 2).toUpperCase()}
              </div>
            )}
            <div>
              <h1 className="font-extrabold text-base tracking-tight leading-tight">
                {loja.nome_loja}
              </h1>
              <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> Aberto Agora
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" /> 35-50 min
                </span>
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              setEtapaCheckout('carrinho');
              setCarrinhoAberto(true);
            }}
            className="relative bg-red-600 hover:bg-red-700 text-white font-bold p-2.5 rounded-2xl transition shadow-md flex items-center gap-2 text-xs cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="hidden sm:inline">R$ {total.toFixed(2)}</span>
            {totalItensCarrinho > 0 && (
              <span className="bg-white text-red-600 font-black text-[10px] w-5 h-5 rounded-full flex items-center justify-center">
                {totalItensCarrinho}
              </span>
            )}
          </button>
        </div>

        <div className="max-w-4xl mx-auto px-4 pb-3 pt-1 flex flex-col sm:flex-row gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar no cardápio..."
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              className="w-full bg-slate-100 dark:bg-slate-800 border-none rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-red-500/50"
            />
          </div>
        </div>

        <div className="max-w-4xl mx-auto px-4 overflow-x-auto flex gap-2 pb-2.5 scrollbar-none">
          <button
            type="button"
            onClick={() => setCategoriaAtiva('todas')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition cursor-pointer ${
              categoriaAtiva === 'todas'
                ? 'bg-red-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
            }`}
          >
            Todos os Itens
          </button>
          {categorias.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setCategoriaAtiva(cat.id)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                categoriaAtiva === cat.id
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              {cat.nome}
            </button>
          ))}
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {produtosFiltrados.length === 0 ? (
            <div className="col-span-2 text-center py-16 text-slate-400 text-sm">
              Nenhum item encontrado com o termo pesquisado.
            </div>
          ) : (
            produtosFiltrados.map((prod) => (
              <div
                key={prod.id}
                onClick={() => abrirModalProduto(prod)}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/80 rounded-2xl p-4 flex justify-between gap-4 cursor-pointer hover:border-red-400 dark:hover:border-red-500/50 hover:shadow-md transition group"
              >
                <div className="flex-1 space-y-1.5 flex flex-col justify-between">
                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-white text-sm group-hover:text-red-600 transition">
                      {prod.nome}
                    </h3>
                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                      {prod.descricao}
                    </p>
                  </div>
                  <div className="flex items-center gap-3 pt-2">
                    <span className="font-extrabold text-slate-900 dark:text-white text-base">
                      R$ {prod.preco.toFixed(2)}
                    </span>
                  </div>
                </div>
                {prod.imagem_url && (
                  <div className="w-24 h-24 rounded-xl overflow-hidden shrink-0 border border-slate-100 dark:border-slate-800">
                    <img
                      src={prod.imagem_url}
                      alt={prod.nome}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    />
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </main>

      {produtoModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl max-w-lg w-full max-h-[90vh] flex flex-col overflow-hidden border border-slate-200 dark:border-slate-800 shadow-2xl">
            <div className="relative">
              {produtoModal.imagem_url && (
                <img
                  src={produtoModal.imagem_url}
                  alt={produtoModal.nome}
                  className="w-full h-48 object-cover"
                />
              )}
              <button
                type="button"
                onClick={() => setProdutoModal(null)}
                className="absolute top-3 right-3 p-2 bg-black/60 hover:bg-black text-white rounded-full transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 overflow-y-auto space-y-5 flex-1 text-xs">
              <div>
                <h3 className="text-xl font-extrabold text-slate-900 dark:text-white">
                  {produtoModal.nome}
                </h3>
                <p className="text-slate-500 text-xs mt-1 leading-relaxed">
                  {produtoModal.descricao}
                </p>
                <p className="text-lg font-black text-red-600 dark:text-red-400 mt-2">
                  R$ {produtoModal.preco.toFixed(2)}
                </p>
              </div>

              {produtoModal.opcionais && produtoModal.opcionais.length > 0 && (
                <div className="space-y-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <h4 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wide">
                    Personalize seu Pedido:
                  </h4>
                  <div className="space-y-2">
                    {produtoModal.opcionais.map((op) => {
                      const isSelected = opcionaisSelecionados.some((o) => o.id === op.id);
                      return (
                        <div
                          key={op.id}
                          onClick={() => toggleOpcional(op)}
                          className={`flex justify-between items-center p-3 rounded-xl border cursor-pointer transition ${
                            isSelected
                              ? 'bg-red-50 dark:bg-red-950/40 border-red-500 text-slate-900 dark:text-white font-semibold'
                              : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          <div className="flex items-center gap-2.5">
                            <div
                              className={`w-4 h-4 rounded-md border flex items-center justify-center ${
                                isSelected ? 'bg-red-600 border-red-600 text-white' : 'border-slate-400'
                              }`}
                            >
                              {isSelected && <Check className="w-3 h-3" />}
                            </div>
                            <span>{op.nome_opcao}</span>
                          </div>
                          <span className="font-bold text-red-600 dark:text-red-400">
                            {op.preco_adicional > 0 ? `+ R$ ${op.preco_adicional.toFixed(2)}` : 'Grátis'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="space-y-1.5 pt-2 border-t border-slate-100 dark:border-slate-800">
                <label className="font-bold text-slate-900 dark:text-white">
                  Alguma observação especial?
                </label>
                <textarea
                  rows={2}
                  placeholder="Ex: Tirar cebola, ponto da carne..."
                  value={obsModal}
                  onChange={(e) => setObsModal(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-white focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <div className="p-4 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-4">
              <div className="flex items-center bg-slate-100 dark:bg-slate-800 rounded-xl p-1">
                <button
                  type="button"
                  onClick={() => setQtdModal(Math.max(1, qtdModal - 1))}
                  className="w-8 h-8 rounded-lg bg-white dark:bg-slate-700 text-slate-900 dark:text-white font-bold flex items-center justify-center cursor-pointer"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="w-8 text-center font-bold text-sm text-slate-900 dark:text-white">
                  {qtdModal}
                </span>
                <button
                  type="button"
                  onClick={() => setQtdModal(qtdModal + 1)}
                  className="w-8 h-8 rounded-lg bg-white dark:bg-slate-700 text-slate-900 dark:text-white font-bold flex items-center justify-center cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
              <button
                type="button"
                onClick={handleAdicionarItemModal}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-xl text-xs transition shadow-md flex justify-between items-center cursor-pointer"
              >
                <span>Adicionar ao Pedido</span>
                <span>
                  R${' '}
                  {(
                    (produtoModal.preco +
                      opcionaisSelecionados.reduce((acc, op) => acc + op.preco_adicional, 0)) *
                    qtdModal
                  ).toFixed(2)}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {carrinhoAberto && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 w-full max-w-md h-full flex flex-col shadow-2xl border-l border-slate-200 dark:border-slate-800">
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-red-600" />
                <h3 className="font-extrabold text-slate-900 dark:text-white text-base">
                  {etapaCheckout === 'confirmado' ? 'Pedido Confirmado!' : 'Seu Carrinho'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setCarrinhoAberto(false)}
                className="p-1 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
              {etapaCheckout === 'carrinho' && (
                <>
                  {carrinho.length === 0 ? (
                    <div className="text-center py-16 text-slate-400 space-y-2">
                      <ShoppingBag className="w-12 h-12 mx-auto text-slate-300 dark:text-slate-700" />
                      <p className="font-bold text-slate-600 dark:text-slate-300 text-sm">Seu carrinho está vazio</p>
                    </div>
                  ) : (
                    <>
                      <div className="space-y-2.5">
                        {carrinho.map((item, idx) => (
                          <div
                            key={idx}
                            className="bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800 flex justify-between items-start gap-2"
                          >
                            <div className="space-y-0.5">
                              <p className="font-bold text-slate-900 dark:text-white text-xs">
                                {item.quantidade}x {item.produto.nome}
                              </p>
                              {item.observacao && (
                                <p className="text-[11px] text-red-500 italic">
                                  Obs: {item.observacao}
                                </p>
                              )}
                              <p className="font-extrabold text-red-600 dark:text-red-400 pt-1">
                                R$ {item.totalItem.toFixed(2)}
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={() => setCarrinho(carrinho.filter((_, i) => i !== idx))}
                              className="text-slate-400 hover:text-red-500 p-1 cursor-pointer"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>

                      <div className="bg-slate-50 dark:bg-slate-950 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => setTipoEntrega('delivery')}
                            className={`flex-1 py-2 rounded-lg font-bold text-xs transition cursor-pointer ${
                              tipoEntrega === 'delivery'
                                ? 'bg-red-600 text-white'
                                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800'
                            }`}
                          >
                            🛵 Delivery
                          </button>
                          <button
                            type="button"
                            onClick={() => setTipoEntrega('retirada')}
                            className={`flex-1 py-2 rounded-lg font-bold text-xs transition cursor-pointer ${
                              tipoEntrega === 'retirada'
                                ? 'bg-red-600 text-white'
                                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800'
                            }`}
                          >
                            🛍️ Retirada
                          </button>
                        </div>
                      </div>
                    </>
                  )}
                </>
              )}

              {etapaCheckout === 'pagamento' && (
                <form onSubmit={handleFinalizarPedido} className="space-y-4">
                  <div className="bg-slate-50 dark:bg-slate-950 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2.5">
                    <h4 className="font-bold text-slate-900 dark:text-white text-xs">
                      Seus Dados para Contato
                    </h4>
                    <div>
                      <label className="text-[11px] text-slate-600 dark:text-slate-400 block mb-1">
                        Seu Nome Completo
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Ex: Maria Eduarda"
                        value={clienteNome}
                        onChange={(e) => setClienteNome(e.target.value)}
                        className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-2 text-xs text-slate-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-slate-600 dark:text-slate-400 block mb-1">
                        Seu WhatsApp
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="11999999999"
                        value={clienteTelefone}
                        onChange={(e) => setClienteTelefone(e.target.value)}
                        className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-2 text-xs text-slate-900 dark:text-white"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3.5 rounded-xl transition shadow-md flex items-center justify-center gap-2 text-sm cursor-pointer"
                  >
                    Confirmar Pedido (R$ {total.toFixed(2)}) <ArrowRight className="w-4 h-4" />
                  </button>
                </form>
              )}

              {etapaCheckout === 'confirmado' && pedidoConfirmado && (
                <div className="text-center space-y-4 py-4">
                  <div className="p-3 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-full w-fit mx-auto">
                    <Check className="w-10 h-10" />
                  </div>
                  <div>
                    <h4 className="text-xl font-black text-slate-900 dark:text-white">
                      Pedido #{pedidoConfirmado.codigo_pedido} Recebido!
                    </h4>
                  </div>
                  <button
                    type="button"
                    onClick={() => abrirWhatsAppLoja(pedidoConfirmado, loja)}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3.5 rounded-xl transition shadow-md flex items-center justify-center gap-2 text-xs cursor-pointer"
                  >
                    Enviar Resumo no WhatsApp da Loja
                  </button>
                </div>
              )}
            </div>

            {etapaCheckout === 'carrinho' && carrinho.length > 0 && (
              <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 space-y-3">
                <div className="flex justify-between text-sm font-black text-slate-900 dark:text-white pt-2 border-t border-slate-200 dark:border-slate-800">
                  <span>Total a Pagar:</span>
                  <span className="text-red-600 dark:text-red-400">R$ {total.toFixed(2)}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setEtapaCheckout('pagamento')}
                  className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3.5 rounded-xl transition text-xs shadow-md flex justify-between items-center px-4 cursor-pointer"
                >
                  <span>Avançar para Pagamento</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

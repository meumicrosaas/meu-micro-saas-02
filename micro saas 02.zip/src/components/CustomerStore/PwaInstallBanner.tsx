import { useState, useEffect } from 'react';
import { Download, X, Smartphone, Share, PlusSquare, Sparkles, CheckCircle2 } from 'lucide-react';
import { Loja } from '../../types';
import StoreLogoAvatar from '../Common/StoreLogoAvatar';

interface PwaInstallBannerProps {
  loja: Loja;
}

export default function PwaInstallBanner({ loja }: PwaInstallBannerProps) {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isDismissed, setIsDismissed] = useState<boolean>(true);
  const [isStandalone, setIsStandalone] = useState<boolean>(false);
  const [showIosGuide, setShowIosGuide] = useState<boolean>(false);

  const isIos =
    typeof navigator !== 'undefined' &&
    /iphone|ipad|ipod/.test(navigator.userAgent.toLowerCase()) &&
    !(window as any).MSStream;

  useEffect(() => {
    const standaloneMode =
      window.matchMedia('(display-mode: standalone)').matches ||
      (navigator as any).standalone === true ||
      document.referrer.includes('android-app://');

    if (standaloneMode) {
      setIsStandalone(true);
      return;
    }

    const today = new Date().toISOString().split('T')[0];
    const dismissKey = `pwa_dismissed_${loja.id}_${today}`;
    const alreadyDismissed = localStorage.getItem(dismissKey) === 'true';
    if (!alreadyDismissed) {
      setIsDismissed(false);
    }

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      if (!alreadyDismissed) {
        setIsDismissed(false);
      }
    };

    const handleAppInstalled = () => {
      setIsDismissed(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, [loja.id]);

  function handleDismiss() {
    setIsDismissed(true);
    const today = new Date().toISOString().split('T')[0];
    const dismissKey = `pwa_dismissed_${loja.id}_${today}`;
    localStorage.setItem(dismissKey, 'true');
  }

  async function handleInstallClick() {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult?.outcome === 'accepted') {
        handleDismiss();
      }
      setDeferredPrompt(null);
    } else if (isIos) {
      setShowIosGuide(true);
    } else {
      setShowIosGuide(true);
    }
  }

  if (isStandalone || isDismissed) {
    return null;
  }

  return (
    <>
      <aside aria-label="Instalar Aplicativo" className="relative bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 text-white shadow-lg border-b border-white/10 animate-in slide-in-from-top duration-300">
        <div className="max-w-5xl mx-auto px-4 py-2.5 sm:py-3 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3 w-full sm:w-auto text-left">
            <div className="relative shrink-0">
              <StoreLogoAvatar
                nomeLoja={loja.nome_loja}
                logoUrl={loja.logo_url}
                size="sm"
                className="ring-2 ring-white/40 shadow-sm"
              />
              <span className="absolute -bottom-1 -right-1 bg-white text-red-600 rounded-full p-0.5 shadow-xs">
                <Sparkles className="w-2.5 h-2.5" />
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs sm:text-sm font-black leading-tight flex items-center gap-1.5 truncate">
                <span>📱 Instale o App da {loja.nome_loja} no seu celular para pedir mais rápido!</span>
              </p>
              <p className="text-[11px] text-white/85 font-medium flex items-center gap-2 mt-0.5">
                <span>Acesso 1-clique</span>
                <span>•</span>
                <span>Não ocupa memória</span>
                <span>•</span>
                <span>Acompanhamento em tempo real</span>
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={handleInstallClick}
              className="flex-1 sm:flex-none px-4 py-2 bg-white hover:bg-red-50 text-red-600 hover:text-red-700 font-black text-xs rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>Instalar Aplicativo</span>
            </button>
            <button
              type="button"
              onClick={handleDismiss}
              className="p-2 text-white/80 hover:text-white hover:bg-white/15 rounded-xl transition cursor-pointer shrink-0"
              title="Fechar"
              aria-label="Fechar banner"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {showIosGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-sm w-full p-6 text-slate-900 dark:text-white shadow-2xl relative space-y-4">
            <button
              type="button"
              onClick={() => setShowIosGuide(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              title="Fechar"
            >
              <X className="w-4 h-4" />
            </button>
            <div className="text-center space-y-2">
              <div className="w-14 h-14 bg-red-600/10 text-red-600 rounded-2xl flex items-center justify-center mx-auto border border-red-600/20">
                <Smartphone className="w-7 h-7" />
              </div>
              <h3 className="text-base font-black">
                Como Instalar o App da {loja.nome_loja}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Siga os passos rápidos abaixo para adicionar o app à sua tela inicial:
              </p>
            </div>
            <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-3 text-xs">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-red-600 text-white font-bold flex items-center justify-center text-xs shrink-0 mt-0.5">
                  1
                </div>
                <div className="space-y-1">
                  <span className="font-bold text-slate-800 dark:text-slate-200">
                    Toque no botão Compartilhar
                  </span>
                  <p className="text-slate-500 text-[11px] flex items-center gap-1">
                    No navegador, toque no ícone{' '}
                    <Share className="w-3.5 h-3.5 text-blue-500 inline" />.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-red-600 text-white font-bold flex items-center justify-center text-xs shrink-0 mt-0.5">
                  2
                </div>
                <div className="space-y-1">
                  <span className="font-bold text-slate-800 dark:text-slate-200">
                    Selecione &quot;Adicionar à Tela de Início&quot;
                  </span>
                  <p className="text-slate-500 text-[11px] flex items-center gap-1">
                    Role a lista e clique em{' '}
                    <PlusSquare className="w-3.5 h-3.5 text-emerald-500 inline" /> &quot;Adicionar à Tela de Início&quot;.
                  </p>
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                setShowIosGuide(false);
                handleDismiss();
              }}
              className="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition shadow-md flex items-center justify-center gap-2 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Entendi, vou adicionar</span>
            </button>
          </div>
        </div>
      )}
    </>
  );
}

import { useState } from 'react';
import { Pedido, ItemPedido, PrinterWidth, PrinterFontSize } from '../types';
import { Printer, Check, X } from 'lucide-react';
import { AppStorage } from '../lib/storage';

interface ThermalReceiptProps {
  pedido: Pedido;
  itens?: ItemPedido[];
  nomeLoja: string;
  defaultLargura?: PrinterWidth;
  defaultFonte?: PrinterFontSize;
  defaultVias?: number;
  autoOpen?: boolean;
}

export default function ThermalReceipt({
  pedido,
  itens,
  nomeLoja,
  defaultLargura = '80mm',
  defaultFonte = 'normal',
  defaultVias = 1,
  autoOpen = false,
}: ThermalReceiptProps) {
  const [modalAberto, setModalAberto] = useState(autoOpen);
  const [larguraTermica, setLarguraTermica] = useState<PrinterWidth>(defaultLargura);
  const [tamanhoFonte, setTamanhoFonte] = useState<PrinterFontSize>(defaultFonte);
  const [vias, setVias] = useState<number>(defaultVias);
  const [impresso, setImpresso] = useState(pedido.impresso);

  const listaItens = itens || pedido.itens || [];

  function handleImprimir() {
    setImpresso(true);
    AppStorage.updatePedidoImpresso(pedido.id, true);
    try {
      window.print();
    } catch {}
  }

  const rotulosVias = [
    '1ª VIA - COZINHA / PREPARO',
    '2ª VIA - CLIENTE / ENTREGA',
    '3ª VIA - CAIXA / CONTROLE',
  ];

  return (
    <>
      <button
        type="button"
        onClick={() => setModalAberto(true)}
        className="inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition cursor-pointer"
      >
        <Printer className="w-3.5 h-3.5 text-slate-500" />
        <span>Comanda</span>
        {impresso && <Check className="w-3 h-3 text-emerald-600 dark:text-emerald-400 ml-0.5" />}
      </button>

      {modalAberto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-xl w-full border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex flex-wrap justify-between items-center gap-3 bg-slate-50 dark:bg-slate-800/50">
              <div className="flex items-center gap-2">
                <Printer className="w-5 h-5 text-red-600" />
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                    Impressão Térmica de Comanda
                  </h3>
                  <span className="text-[10px] text-slate-500">
                    Pedido {pedido.codigo_pedido || pedido.id}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex bg-slate-200 dark:bg-slate-700 p-0.5 rounded-lg text-xs font-semibold">
                  <button
                    type="button"
                    onClick={() => setLarguraTermica('80mm')}
                    className={`px-2 py-1 rounded-md transition cursor-pointer ${
                      larguraTermica === '80mm'
                        ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    80mm
                  </button>
                  <button
                    type="button"
                    onClick={() => setLarguraTermica('58mm')}
                    className={`px-2 py-1 rounded-md transition cursor-pointer ${
                      larguraTermica === '58mm'
                        ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    58mm
                  </button>
                </div>
                <button
                  type="button"
                  onClick={() => setModalAberto(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 overflow-y-auto flex-1 bg-slate-100 dark:bg-slate-950 flex flex-col items-center gap-6">
              {Array.from({ length: vias }).map((_, indexVia) => (
                <div
                  key={indexVia}
                  className={`bg-white text-black p-4 font-mono shadow-md border border-slate-300 transition-all ${
                    larguraTermica === '80mm' ? 'w-[320px]' : 'w-[240px]'
                  } ${
                    tamanhoFonte === 'pequena'
                      ? 'text-[10px] leading-tight'
                      : tamanhoFonte === 'grande'
                      ? 'text-sm leading-snug'
                      : 'text-xs leading-normal'
                  }`}
                  style={{ fontFamily: "'Courier New', Courier, monospace" }}
                >
                  <div className="text-center pb-2 border-b border-dashed border-black">
                    <p className="font-bold text-sm tracking-wider uppercase">{nomeLoja}</p>
                    <p className="text-[10px] text-gray-700">*** CUPOM NÃO FISCAL ***</p>
                    <div className="mt-1 bg-black text-white font-bold py-0.5 text-[10px] uppercase">
                      {rotulosVias[indexVia] || `${indexVia + 1}ª VIA`}
                    </div>
                  </div>
                  <div className="py-2 border-b border-dashed border-black">
                    <div className="flex justify-between font-bold text-sm">
                      <span>PEDIDO:</span>
                      <span>{pedido.codigo_pedido || `#${pedido.id.slice(0, 6)}`}</span>
                    </div>
                    <p className="mt-1">
                      <span className="font-bold">CLIENTE:</span> {pedido.cliente_nome}
                    </p>
                    <p>
                      <span className="font-bold">TEL:</span> {pedido.cliente_telefone}
                    </p>
                    <div className="mt-1 p-1 bg-gray-100 border border-black text-center font-bold">
                      {pedido.tipo_entrega === 'delivery' ? '🛵 DELIVERY' : '🛍️ RETIRADA NO BALCÃO'}
                    </div>
                  </div>
                  <div className="py-2 border-b border-dashed border-black space-y-2">
                    {listaItens.map((item, idx) => (
                      <div key={idx} className="flex justify-between">
                        <span className="font-bold">
                          {item.quantidade}x {item.produto_nome}
                        </span>
                        <span>R$ {Number(item.total_item).toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                  <div className="py-2 border-b border-dashed border-black space-y-1">
                    <div className="flex justify-between font-bold text-sm pt-1 border-t border-dotted border-black">
                      <span>TOTAL:</span>
                      <span>R$ {Number(pedido.total).toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-4 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setModalAberto(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition cursor-pointer"
              >
                Fechar
              </button>
              <button
                type="button"
                onClick={handleImprimir}
                className="px-4 py-2 text-xs font-bold bg-red-600 hover:bg-red-700 text-white rounded-lg transition flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                Imprimir Comanda
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

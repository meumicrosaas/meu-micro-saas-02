import { useState, useEffect } from 'react';
import { Loja, SaasAssinatura, SaasPlanSettings } from '../../types';
import { AppStorage } from '../../lib/storage';
import DataService from '../../lib/supabase';
import {
  Lock,
  QrCode,
  CheckCircle2,
  Copy,
  Check,
  ShieldCheck,
  Sparkles,
  ExternalLink,
  Landmark,
  CreditCard,
  Zap,
} from 'lucide-react';

interface AssinaturaPendenteProps {
  lojaId?: string;
  onDesbloqueado: () => void;
  onVoltarParaSuperAdmin: () => void;
}

export default function AssinaturaPendente({
  lojaId,
  onDesbloqueado,
}: AssinaturaPendenteProps) {
  const [loja, setLoja] = useState<Loja | null>(null);
  const [assinatura, setAssinatura] = useState<SaasAssinatura | null>(null);
  const [planSettings, setPlanSettings] = useState<SaasPlanSettings>(AppStorage.getSaasPlanSettings());
  const [gatewayEscolhido, setGatewayEscolhido] = useState<'mercadopago' | 'abacatepay' | 'pix'>('mercadopago');
  const [copiadoPix, setCopiadoPix] = useState(false);
  const [copiadoChave, setCopiadoChave] = useState(false);
  const [processando, setProcessando] = useState(false);
  const [sucesso, setSucesso] = useState(false);

  useEffect(() => {
    carregarDados();
    async function carregarSettings() {
      const s = await DataService.getSaasPlanSettings();
      setPlanSettings(s);
    }
    carregarSettings();
  }, [lojaId]);

  function carregarDados() {
    const todas = AppStorage.getLojas();
    const l = lojaId ? AppStorage.getLojaById(lojaId) : todas.find((x) => x.status_conta === 'bloqueada') || todas[0];
    if (l) {
      setLoja(l);
      setAssinatura(AppStorage.getAssinaturaByLoja(l.id) || null);
    }
  }

  if (!loja) {
    return <div className="p-8 text-center text-slate-500">Loja não encontrada.</div>;
  }

  const valor = assinatura?.valor || 169.99;
  const chavePixConfigurada = planSettings.pix_chave || 'financeiro@seusaas.com';
  const titularConfigurado = planSettings.pix_titular || 'Delivery SaaS Tecnologia';
  const bancoConfigurado = planSettings.pix_banco || 'Banco Inter S.A.';
  const tipoChaveConfigurado = (planSettings.pix_tipo_chave || 'cnpj').toUpperCase();
  const codigoPix = `00020126580014BR.GOV.BCB.PIX0136${chavePixConfigurada.replace(/[^a-zA-Z0-9]/g, '')}5204000053039865405${valor.toFixed(2)}5802BR5913${titularConfigurado.slice(0, 25)}6009Sao Paulo62070503***6304`;

  function handleCopiarPix() {
    navigator.clipboard.writeText(codigoPix);
    setCopiadoPix(true);
    setTimeout(() => setCopiadoPix(false), 3000);
  }

  function handleCopiarChave() {
    if (!chavePixConfigurada) return;
    navigator.clipboard.writeText(chavePixConfigurada);
    setCopiadoChave(true);
    setTimeout(() => setCopiadoChave(false), 3000);
  }

  async function handleConfirmarPagamento(gateway: 'mercadopago' | 'abacatepay' | 'pix') {
    if (!loja) return;
    setProcessando(true);
    const comprovanteId = `${gateway.toUpperCase()}-${Date.now().toString().slice(-8)}`;

    try {
      await DataService.renovarAssinaturaLoja(loja.id, gateway, comprovanteId, valor);
      setSucesso(true);
      carregarDados();
      setTimeout(() => {
        onDesbloqueado();
      }, 1500);
    } catch (e) {
      console.error('Erro na renovação:', e);
      AppStorage.processarWebhookPagamentoSaas(loja.id, gateway === 'pix' ? 'mercadopago' : gateway, comprovanteId);
      setSucesso(true);
      setTimeout(() => {
        onDesbloqueado();
      }, 1500);
    } finally {
      setProcessando(false);
    }
  }

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 text-white font-sans">
      <div className="max-w-xl w-full bg-slate-900 border border-red-500/40 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl text-center">
        <div className="p-4 bg-red-500/10 text-red-500 rounded-full w-fit mx-auto border border-red-500/20">
          <Lock className="w-10 h-10" />
        </div>
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-red-400 bg-red-500/10 px-3 py-1 rounded-full border border-red-500/20">
            Acesso Temporariamente Suspenso
          </span>
          <h2 className="text-2xl font-black tracking-tight text-white mt-3">
            Renovação de Assinatura ({loja.nome_loja})
          </h2>
          <p className="text-xs text-slate-400 mt-2 leading-relaxed">
            Seu período de teste ou mensalidade expirou. Realize o pagamento pelo seu gateway preferido para reativar seu cardápio e liberar o painel imediatamente.
          </p>
        </div>

        {sucesso ? (
          <div className="p-5 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl text-emerald-400 space-y-2 animate-bounce">
            <CheckCircle2 className="w-10 h-10 mx-auto" />
            <p className="font-bold text-base">Pagamento Confirmado com Sucesso!</p>
            <p className="text-xs text-emerald-300">
              Sua loja foi reativada por +30 dias. Redirecionando para o painel...
            </p>
          </div>
        ) : (
          <>
            {/* Escolha do Gateway */}
            <div className="space-y-2 text-left">
              <label className="text-xs font-bold text-slate-300 block">
                Selecione a forma de pagamento:
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setGatewayEscolhido('mercadopago')}
                  className={`p-3 rounded-xl border text-center transition cursor-pointer flex flex-col items-center gap-1 ${
                    gatewayEscolhido === 'mercadopago'
                      ? 'border-blue-500 bg-blue-500/20 text-blue-300 font-bold'
                      : 'border-slate-800 bg-slate-950 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  <CreditCard className="w-5 h-5 text-blue-400" />
                  <span className="text-xs">Mercado Pago</span>
                  <span className="text-[9px] text-blue-300 font-semibold">PIX Automático</span>
                </button>

                <button
                  type="button"
                  onClick={() => setGatewayEscolhido('abacatepay')}
                  className={`p-3 rounded-xl border text-center transition cursor-pointer flex flex-col items-center gap-1 ${
                    gatewayEscolhido === 'abacatepay'
                      ? 'border-green-500 bg-green-500/20 text-green-300 font-bold'
                      : 'border-slate-800 bg-slate-950 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  <Zap className="w-5 h-5 text-green-400" />
                  <span className="text-xs">AbacatePay</span>
                  <span className="text-[9px] text-green-300 font-semibold">Instantâneo</span>
                </button>

                <button
                  type="button"
                  onClick={() => setGatewayEscolhido('pix')}
                  className={`p-3 rounded-xl border text-center transition cursor-pointer flex flex-col items-center gap-1 ${
                    gatewayEscolhido === 'pix'
                      ? 'border-emerald-500 bg-emerald-500/20 text-emerald-300 font-bold'
                      : 'border-slate-800 bg-slate-950 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  <QrCode className="w-5 h-5 text-emerald-400" />
                  <span className="text-xs">Chave PIX</span>
                  <span className="text-[9px] text-emerald-300 font-semibold">Copia e Cola</span>
                </button>
              </div>
            </div>

            <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-4">
              <div>
                <span className="text-xs text-slate-500 font-medium">Valor da Mensalidade:</span>
                <p className="text-3xl font-black text-emerald-400">R$ {valor.toFixed(2)}</p>
                <span className="text-[11px] text-slate-400">Plano Mensal com renovação a cada 30 dias</span>
              </div>

              {gatewayEscolhido === 'mercadopago' && (
                <div className="bg-blue-950/30 border border-blue-500/30 rounded-2xl p-4 text-left space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-blue-300 flex items-center gap-1.5">
                      <CreditCard className="w-4 h-4 text-blue-400" />
                      Checkout Transparente Mercado Pago
                    </span>
                    <span className="text-[10px] bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded-full font-semibold">
                      Baixa Imediata
                    </span>
                  </div>
                  <p className="text-xs text-slate-300">
                    Ao pagar via PIX Dinâmico do Mercado Pago, a confirmação do pagamento é detectada automaticamente via webhook e o painel é desbloqueado no mesmo instante.
                  </p>
                </div>
              )}

              {gatewayEscolhido === 'abacatepay' && (
                <div className="bg-green-950/30 border border-green-500/30 rounded-2xl p-4 text-left space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-green-300 flex items-center gap-1.5">
                      <Zap className="w-4 h-4 text-green-400" />
                      PIX Instantâneo AbacatePay
                    </span>
                    <span className="text-[10px] bg-green-500/20 text-green-300 px-2 py-0.5 rounded-full font-semibold">
                      Sem Burocracia
                    </span>
                  </div>
                  <p className="text-xs text-slate-300">
                    O AbacatePay processa o pagamento via PIX sem intermediários e envia o sinal de confirmação que reativa sua loja imediatamente.
                  </p>
                </div>
              )}

              {/* Informações Bancárias */}
              <div className="bg-slate-900 border border-slate-800/90 rounded-2xl p-4 text-left space-y-2.5">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
                  <Landmark className="w-4 h-4 text-emerald-400" />
                  <span className="text-[11px] font-extrabold text-slate-200 uppercase tracking-wider">
                    Dados de Recebimento Oficial do SaaS
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">
                    Beneficiário / Titular:
                  </span>
                  <p className="text-sm font-bold text-white">
                    {titularConfigurado}
                  </p>
                </div>
                {bancoConfigurado && (
                  <div>
                    <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">
                      Banco:
                    </span>
                    <p className="text-xs font-semibold text-slate-300">
                      {bancoConfigurado}
                    </p>
                  </div>
                )}
                <div>
                  <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">
                    Chave PIX ({tipoChaveConfigurado}):
                  </span>
                  <div className="flex items-center justify-between gap-2 mt-1 bg-slate-950 border border-slate-800 rounded-xl p-2.5">
                    <span className="font-mono text-xs font-black text-emerald-400 truncate select-all">
                      {chavePixConfigurada}
                    </span>
                    <button
                      type="button"
                      onClick={handleCopiarChave}
                      className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer shadow-xs"
                      title="Copiar Chave PIX"
                    >
                      {copiadoChave ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-white" />
                          <span>Copiado!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copiar Chave</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>

              {/* QR Code */}
              <div className="w-44 h-44 bg-white p-3 rounded-2xl mx-auto flex items-center justify-center shadow-lg">
                <QrCode className="w-36 h-36 text-slate-900" />
              </div>

              <div className="space-y-1.5 text-left">
                <label className="text-[11px] font-semibold text-slate-400 block">
                  PIX Copia e Cola:
                </label>
                <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl p-2 font-mono text-[10px] text-slate-300 overflow-hidden">
                  <span className="truncate flex-1">{codigoPix}</span>
                  <button
                    type="button"
                    onClick={handleCopiarPix}
                    className="p-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition shrink-0 cursor-pointer"
                  >
                    {copiadoPix ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <button
                type="button"
                disabled={processando}
                onClick={() => handleConfirmarPagamento(gatewayEscolhido)}
                className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold py-3.5 rounded-xl transition shadow-lg flex items-center justify-center gap-2 text-xs cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>
                  {processando
                    ? 'Verificando pagamento...'
                    : `Confirmar Pagamento via ${
                        gatewayEscolhido === 'mercadopago'
                          ? 'Mercado Pago'
                          : gatewayEscolhido === 'abacatepay'
                          ? 'AbacatePay'
                          : 'PIX'
                      } e Liberar Acesso`}
                </span>
              </button>

              <div className="flex justify-between items-center text-xs text-slate-400 pt-2">
                <a
                  href={`https://wa.me/55${loja.telefone_whatsapp.replace(/\D/g, '')}?text=Olá,%20acabei%20de%20efetuar%20o%20pagamento%20da%20mensalidade`}
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-white transition flex items-center gap-1 text-[11px]"
                >
                  <ExternalLink className="w-3 h-3" /> Falar com Suporte
                </a>
              </div>
            </div>
          </>
        )}

        <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-500 flex items-center justify-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-500" />
          <span>Liberação Instantânea via Webhook e Gateway Automático</span>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { Store } from 'lucide-react';

interface StoreLogoAvatarProps {
  nomeLoja: string;
  logoUrl?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  className?: string;
  corPrimaria?: string;
}

export default function StoreLogoAvatar({
  nomeLoja,
  logoUrl,
  size = 'md',
  className = '',
  corPrimaria,
}: StoreLogoAvatarProps) {
  const [imageFailed, setImageFailed] = useState(false);

  const nomeLimpo = (nomeLoja || '').trim();
  const isNumericOnly = /^\d+$/.test(nomeLimpo);
  const apenasLetras = nomeLimpo.replace(/[^a-zA-Z ]/g, '').trim();

  let iniciais = '';
  if (!isNumericOnly && apenasLetras.length > 0) {
    const palavras = nomeLimpo.split(/\s+/).filter(Boolean);
    iniciais =
      palavras.length >= 2
        ? `${palavras[0][0]}${palavras[1][0]}`.toUpperCase()
        : (apenasLetras.slice(0, 2) || 'LJ').toUpperCase();
  }

  const sizeClasses = {
    xs: 'w-6 h-6 text-[10px] rounded-lg',
    sm: 'w-8 h-8 text-xs rounded-xl',
    md: 'w-12 h-12 text-sm rounded-2xl',
    lg: 'w-16 h-16 text-lg rounded-2xl',
    xl: 'w-20 h-20 text-xl rounded-3xl',
    '2xl': 'w-24 h-24 text-2xl rounded-3xl',
  }[size];

  if (logoUrl && logoUrl.trim() !== '' && !imageFailed) {
    return (
      <div
        className={`relative shrink-0 overflow-hidden bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-xs flex items-center justify-center ${sizeClasses} ${className}`}
      >
        <img
          src={logoUrl}
          alt={`Logomarca da ${nomeLoja}`}
          referrerPolicy="no-referrer"
          onError={() => setImageFailed(true)}
          className="w-full h-full object-cover object-center transition-all duration-200"
        />
      </div>
    );
  }

  return (
    <div
      style={corPrimaria ? { backgroundColor: corPrimaria } : undefined}
      className={`relative shrink-0 font-black tracking-wider text-white shadow-sm flex items-center justify-center select-none border border-white/20 bg-gradient-to-br from-red-600 to-rose-700 ${sizeClasses} ${className}`}
      title={nomeLoja}
    >
      {iniciais && !/^\d+$/.test(iniciais) ? (
        <span>{iniciais}</span>
      ) : (
        <Store className="w-1/2 h-1/2 text-white" />
      )}
    </div>
  );
}

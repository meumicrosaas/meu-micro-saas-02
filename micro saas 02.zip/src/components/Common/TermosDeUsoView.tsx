import { ArrowLeft, ShieldCheck, FileText, Lock, CheckCircle2, Building, Scale, Clock } from 'lucide-react';

interface TermosDeUsoViewProps {
  onBack: () => void;
}

export default function TermosDeUsoView({ onBack }: TermosDeUsoViewProps) {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 text-xs font-bold transition cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Voltar</span>
          </button>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 space-y-4">
          <div className="inline-flex p-3 bg-red-600/10 text-red-500 rounded-2xl border border-red-500/20">
            <Scale className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Termos de Uso e Política de Privacidade
            </h1>
            <p className="text-xs sm:text-sm text-slate-400">
              Plataforma ARMONIX STORE • Última atualização: 2026
            </p>
          </div>
          <div className="flex flex-wrap gap-2 pt-2">
            <span className="text-[11px] bg-red-500/10 text-red-400 border border-red-500/20 px-3 py-1 rounded-full font-bold">
              Em Conformidade com a LGPD (Lei nº 13.709/2018)
            </span>
            <span className="text-[11px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-3 py-1 rounded-full font-bold">
              Isolamento Multi-tenant Seguro
            </span>
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 space-y-8 text-xs sm:text-sm text-slate-300 leading-relaxed">
          <section className="space-y-3">
            <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2 border-b border-slate-800 pb-2">
              <Building className="w-5 h-5 text-red-500" />
              <span>1. Objeto e Natureza da Plataforma</span>
            </h2>
            <p>
              A <strong>ARMONIX STORE</strong> é uma plataforma tecnológica no modelo Software como Serviço (SaaS)
              multi-tenant que disponibiliza ferramentas para estabelecimentos comerciais de alimentação, restaurantes,
              pizzarias, lanchonetes e similares criarem seu próprio cardápio digital (PWA), receberem pedidos online e
              gerenciarem suas operações de entrega com cálculo automatizado de frete e integração de pagamentos via Pix.
            </p>
            <p>
              A ARMONIX STORE <strong>não é um restaurante, não prepara alimentos e não realiza a entrega física dos pedidos</strong>.
              Cada lojista cadastrado atua como comerciante independente e autônomo, sendo integralmente responsável pela qualidade,
              higiene, precificação, preparo e entrega dos itens comercializados.
            </p>
          </section>
          <section className="space-y-3">
            <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2 border-b border-slate-800 pb-2">
              <ShieldCheck className="w-5 h-5 text-red-500" />
              <span>2. Cadastro, Acesso e Isolamento de Dados</span>
            </h2>
            <p>
              Para utilizar a plataforma, o Lojista declara ter capacidade civil e empresarial plena, fornecendo dados
              verídicos, incluindo Nome do Estabelecimento, WhatsApp de atendimento, E-mail e Senha de acesso.
            </p>
            <ul className="list-disc pl-5 space-y-2">
              <li>
                <strong>Isolamento Multi-tenant:</strong> Os dados de cada loja (produtos, pedidos, clientes e faturamento)
                são isolados logicamente através de identificadores únicos (Tenant ID).
              </li>
              <li>
                <strong>Segurança das Credenciais:</strong> O lojista é único responsável pela guarda e sigilo de sua senha
                de acesso.
              </li>
            </ul>
          </section>
          <section className="space-y-3">
            <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2 border-b border-slate-800 pb-2">
              <Clock className="w-5 h-5 text-red-500" />
              <span>3. Planos, Mensalidades, Renovação e Inadimplência</span>
            </h2>
            <p>
              A ARMONIX STORE concede a cada novo lojista cadastrado um período de cortesia inicial de teste gratuito,
              sem necessidade de cadastro de cartão de crédito antecipado.
            </p>
          </section>
          <section className="space-y-3">
            <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2 border-b border-slate-800 pb-2">
              <Lock className="w-5 h-5 text-red-500" />
              <span>4. Política de Privacidade e Proteção de Dados (LGPD)</span>
            </h2>
            <p>
              Em estrita conformidade com a Lei Geral de Proteção de Dados (Lei nº 13.709/2018), a ARMONIX STORE adota práticas
              rigorosas de governança de dados.
            </p>
          </section>
          <section className="space-y-3">
            <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2 border-b border-slate-800 pb-2">
              <FileText className="w-5 h-5 text-red-500" />
              <span>5. Suporte Técnico</span>
            </h2>
            <p>
              O suporte técnico é prestado através dos canais oficiais da plataforma para esclarecimento de dúvidas sobre o
              funcionamento do sistema.
            </p>
          </section>
        </div>
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-6 bg-slate-900 border border-slate-800 rounded-3xl">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            <span>Documento oficial de termos e privacidade da plataforma ARMONIX STORE.</span>
          </div>
          <button
            type="button"
            onClick={onBack}
            className="w-full sm:w-auto px-6 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition shadow-md cursor-pointer"
          >
            Entendido, Voltar à Plataforma
          </button>
        </div>
      </div>
    </div>
  );
}

import { useState, useRef, useEffect } from 'react';
import { UploadCloud, Link as LinkIcon, Trash2, CheckCircle2, AlertCircle } from 'lucide-react';
import StoreLogoAvatar from './StoreLogoAvatar';

interface StoreLogoUploaderProps {
  nomeLoja: string;
  logoUrl?: string;
  onChange: (novaLogoUrl: string) => void;
  className?: string;
}

export default function StoreLogoUploader({
  nomeLoja,
  logoUrl = '',
  onChange,
  className = '',
}: StoreLogoUploaderProps) {
  const [urlInput, setUrlInput] = useState(logoUrl);
  const [dragActive, setDragActive] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setUrlInput(logoUrl || '');
  }, [logoUrl]);

  function processFile(file: File) {
    setUploadError(null);
    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml'];
    if (!validTypes.includes(file.type)) {
      setUploadError('Formato inválido. Por favor, utilize JPG, PNG ou WEBP.');
      return;
    }
    if (file.size > 3 * 1024 * 1024) {
      setUploadError('A imagem deve ter no máximo 3MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      if (dataUrl) {
        setUrlInput(dataUrl);
        onChange(dataUrl);
        setSuccessMsg('Logo carregada com sucesso!');
        setTimeout(() => setSuccessMsg(null), 3000);
      }
    };
    reader.onerror = () => {
      setUploadError('Falha ao processar a imagem do arquivo.');
    };
    reader.readAsDataURL(file);
  }

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  }

  function handleDragOver(e: React.DragEvent) {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(true);
  }

  function handleDragLeave(e: React.DragEvent) {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  }

  function handleApplyUrl() {
    if (!urlInput.trim()) {
      onChange('');
      return;
    }
    onChange(urlInput.trim());
    setSuccessMsg('Logo por URL aplicada com sucesso!');
    setTimeout(() => setSuccessMsg(null), 3000);
  }

  function handleRemoveLogo() {
    setUrlInput('');
    onChange('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    setSuccessMsg('Logo removida. O avatar com iniciais será utilizado.');
    setTimeout(() => setSuccessMsg(null), 3000);
  }

  return (
    <div className={`space-y-4 ${className}`}>
      {uploadError && (
        <div className="p-3 bg-red-500/10 border border-red-500/30 text-red-500 text-xs rounded-xl flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{uploadError}</span>
        </div>
      )}
      {successMsg && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 text-xs rounded-xl flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}
      <div className="flex flex-col sm:flex-row items-center gap-5 p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
        <div className="flex flex-col items-center gap-2 shrink-0">
          <StoreLogoAvatar
            nomeLoja={nomeLoja || 'Sua Loja'}
            logoUrl={logoUrl}
            size="xl"
            className="ring-4 ring-red-500/20 shadow-md"
          />
          <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
            {logoUrl ? 'Pré-visualização' : 'Avatar com Iniciais'}
          </span>
          {logoUrl && (
            <button
              type="button"
              onClick={handleRemoveLogo}
              className="text-[11px] text-red-500 hover:text-red-600 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <Trash2 className="w-3 h-3" /> Remover Logo
            </button>
          )}
        </div>
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`flex-1 w-full border-2 border-dashed rounded-2xl p-5 text-center cursor-pointer transition flex flex-col items-center justify-center gap-2 ${
            dragActive
              ? 'border-red-500 bg-red-50/50 dark:bg-red-950/20'
              : 'border-slate-300 dark:border-slate-700 hover:border-red-400 hover:bg-slate-100/50 dark:hover:bg-slate-800/50'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/png, image/jpeg, image/webp, image/gif, image/svg+xml"
            onChange={handleFileChange}
            className="hidden"
          />
          <div className="w-10 h-10 rounded-full bg-red-500/10 text-red-500 flex items-center justify-center">
            <UploadCloud className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
              Clique para selecionar ou arraste sua imagem aqui
            </p>
            <p className="text-[11px] text-slate-400">
              Formatos recomendados: PNG, JPG ou WEBP (até 3MB)
            </p>
          </div>
        </div>
      </div>
      <div className="space-y-1.5">
        <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
          <LinkIcon className="w-3.5 h-3.5 text-slate-400" />
          <span>Ou utilize o link direto da imagem (URL)</span>
        </label>
        <div className="flex gap-2">
          <input
            type="url"
            placeholder="https://exemplo.com/minha-logo.png"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            className="flex-1 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-red-500"
          />
          <button
            type="button"
            onClick={handleApplyUrl}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition shrink-0 cursor-pointer"
          >
            Aplicar URL
          </button>
        </div>
      </div>
    </div>
  );
}

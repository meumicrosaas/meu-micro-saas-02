import { useState } from 'react';
import { Loja } from '../../types';
import { AppStorage } from '../../lib/storage';
import { DataService } from '../../lib/supabase';
import {
  CreditCard,
  QrCode,
  ShieldCheck,
  Check,
  KeyRound,
  Eye,
  EyeOff,
  Zap,
  Lock,
} from 'lucide-react';

interface PaymentGatewaySettingsProps {
  loja: Loja;
  onUpdate: () => void;
}

export default function PaymentGatewaySettings({ loja, onUpdate }: PaymentGatewaySettingsProps) {
  const [chavePix, setChavePix] = useState(loja.chave_pix || '');
  const [mpToken, setMpToken] = useState(loja.mercadopago_access_token || '');
  const [mpPublicKey, setMpPublicKey] = useState(
    (loja as any).mercadopago_public_key || ''
  );
  const [abacateKey, setAbacateKey] = useState(loja.abacatepay_api_key || '');
  const [showMpToken, setShowMpToken] = useState(false);
  const [showAbacateKey, setShowAbacateKey] = useState(false);
  const [salvando, setSalvando] = useState(false);
  const [salvo, setSalvo] = useState(false);

  async function handleSalvar(e: React.FormEvent) {
    e.preventDefault();
    setSalvando(true);
    const updates = {
      chave_pix: chavePix.trim(),
      mercadopago_access_token: mpToken.trim(),
      mercadopago_public_key: mpPublicKey.trim(),
      abacatepay_api_key: abacateKey.trim(),
    };

    AppStorage.updateLoja(loja.id, updates);
    try {
      await DataService.updateLoja(loja.id, updates);
    } catch (err) {
      console.warn('Erro ao sincronizar chaves de pagamento no Supabase:', err);
    }

    setSalvando(false);
    setSalvo(true);
    setTimeout(() => setSalvo(false), 3500);
    onUpdate();
  }

  const mpAtivo = Boolean(mpToken.trim());
  const abacateAtivo = Boolean(abacateKey.trim());
  const pixAtivo = Boolean(chavePix.trim());

  return (
    <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-xl">
            <CreditCard className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 dark:text-white text-base">
              Gateways de Pagamento da Loja (Checkout Direto)
            </h3>
            <p className="text-xs text-slate-500">
              Configure Mercado Pago ou AbacatePay para receber diretamente dos seus clientes no cardápio online.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span
            className={`text-[10px] px-2.5 py-1 rounded-full font-bold flex items-center gap-1 ${
              mpAtivo || abacateAtivo || pixAtivo
                ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                : 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20'
            }`}
          >
            {mpAtivo || abacateAtivo || pixAtivo ? (
              <>
                <Check className="w-3 h-3" /> Gateways Prontos
              </>
            ) : (
              'Configuração Pendente'
            )}
          </span>
        </div>
      </div>

      <form onSubmit={handleSalvar} className="space-y-5 text-xs">
        {/* Chave PIX Manual da Loja */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <QrCode className="w-4 h-4 text-emerald-500" />
              <label className="font-bold text-slate-800 dark:text-slate-200">
                Chave PIX da Loja (Para exibição no Checkout do Cardápio)
              </label>
            </div>
            {pixAtivo && (
              <span className="text-[10px] bg-emerald-500/10 text-emerald-600 font-semibold px-2 py-0.5 rounded">
                Ativa
              </span>
            )}
          </div>
          <input
            type="text"
            placeholder="Ex: CNPJ, E-mail, Celular com DDD ou Chave Aleatória"
            value={chavePix}
            onChange={(e) => setChavePix(e.target.value)}
            className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white focus:outline-none"
          />
          <p className="text-[11px] text-slate-500">
            Quando o cliente escolhe PIX manual, sua chave e o código Copia e Cola serão exibidos na tela final.
          </p>
        </div>

        {/* Mercado Pago */}
        <div className="p-4 bg-blue-50/50 dark:bg-blue-950/20 rounded-xl border border-blue-200 dark:border-blue-900/40 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-blue-500" />
              <label className="font-bold text-blue-900 dark:text-blue-300">
                Mercado Pago (PIX com Baixa Automática)
              </label>
            </div>
            <span className="text-[10px] bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 font-bold px-2 py-0.5 rounded">
              {mpAtivo ? 'Conectado' : 'Recomendado'}
            </span>
          </div>

          <div className="space-y-1">
            <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 block">
              Access Token (Produção)
            </span>
            <div className="relative">
              <input
                type={showMpToken ? 'text' : 'password'}
                placeholder="APP_USR-..."
                value={mpToken}
                onChange={(e) => setMpToken(e.target.value)}
                className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 pr-10 text-slate-900 dark:text-white font-mono text-xs"
              />
              <button
                type="button"
                onClick={() => setShowMpToken(!showMpToken)}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
              >
                {showMpToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="space-y-1">
            <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 block">
              Public Key (Opcional)
            </span>
            <input
              type="text"
              placeholder="APP_USR-..."
              value={mpPublicKey}
              onChange={(e) => setMpPublicKey(e.target.value)}
              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white font-mono text-xs"
            />
          </div>
          <p className="text-[11px] text-slate-500">
            Obtenha em: <strong>Mercado Pago Developers → Suas Aplicações → Credenciais de Produção</strong>.
          </p>
        </div>

        {/* AbacatePay */}
        <div className="p-4 bg-green-50/50 dark:bg-green-950/20 rounded-xl border border-green-200 dark:border-green-900/40 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-green-500" />
              <label className="font-bold text-green-900 dark:text-green-300">
                AbacatePay (PIX Instantâneo sem Burocracia)
              </label>
            </div>
            <span className="text-[10px] bg-green-100 dark:bg-green-950/60 text-green-700 dark:text-green-300 font-bold px-2 py-0.5 rounded">
              {abacateAtivo ? 'Conectado' : 'Instantâneo'}
            </span>
          </div>

          <div className="space-y-1">
            <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 block">
              API Key (Chave Secreta)
            </span>
            <div className="relative">
              <input
                type={showAbacateKey ? 'text' : 'password'}
                placeholder="aba_sec_..."
                value={abacateKey}
                onChange={(e) => setAbacateKey(e.target.value)}
                className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 pr-10 text-slate-900 dark:text-white font-mono text-xs"
              />
              <button
                type="button"
                onClick={() => setShowAbacateKey(!showAbacateKey)}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
              >
                {showAbacateKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
          <p className="text-[11px] text-slate-500">
            Obtenha no painel do <strong>AbacatePay → Integrações / API Keys</strong>.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row justify-between items-center gap-3 pt-2">
          <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-emerald-500" />
            <span>As credenciais são salvas com criptografia e isolamento por estabelecimento.</span>
          </div>

          <div className="flex items-center gap-3">
            {salvo && (
              <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1 text-xs">
                <Check className="w-4 h-4" /> Credenciais salvas com sucesso!
              </span>
            )}
            <button
              type="submit"
              disabled={salvando}
              className="bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-bold px-6 py-2.5 rounded-xl transition text-xs shadow-xs cursor-pointer"
            >
              {salvando ? 'Salvando...' : 'Salvar Chaves de Pagamento'}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}

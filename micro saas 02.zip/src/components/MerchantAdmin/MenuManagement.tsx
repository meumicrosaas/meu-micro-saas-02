import { useState, useEffect } from 'react';
import {
  Plus,
  Trash2,
  Check,
  Edit2,
  Flame,
  Search,
  X,
} from 'lucide-react';
import { AppStorage } from '../../lib/storage';
import { DataService } from '../../lib/supabase';
import { compressAndConvertToWebP, CompressionResult } from '../../lib/imageCompressor';
import { Loja, Categoria, Produto, OpcionalProduto } from '../../types';
import BannerOfertaControl from './BannerOfertaControl';

interface MenuManagementProps {
  loja: Loja;
}

export default function MenuManagement({ loja }: MenuManagementProps) {
  const [categorias, setCategorias] = useState<Categoria[]>([]);
  const [produtos, setProdutos] = useState<Produto[]>([]);
  const [filtroCategoria, setFiltroCategoria] = useState<string>('todas');
  const [busca, setBusca] = useState<string>('');

  const [novaCatNome, setNovaCatNome] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editandoProdutoId, setEditandoProdutoId] = useState<string | null>(null);
  const [nome, setNome] = useState('');
  const [preco, setPreco] = useState('');
  const [precoPromocional, setPrecoPromocional] = useState('');
  const [categoriaId, setCategoriaId] = useState('');
  const [descricao, setDescricao] = useState('');
  const [imagemPreview, setImagemPreview] = useState<string>('');
  const [destaqueOferta, setDestaqueOferta] = useState(false);
  const [destaqueMaisPedido, setDestaqueMaisPedido] = useState(false);
  const [disponivel, setDisponivel] = useState(true);
  const [isCompressing, setIsCompressing] = useState(false);
  const [produtoParaExcluir, setProdutoParaExcluir] = useState<string | null>(null);
  const [modalLimparAberto, setModalLimparAberto] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  async function handleLimparCardapio() {
    await DataService.limparCardapioLoja(loja.id);
    carregarMenu();
    setModalLimparAberto(false);
    showToast('Cardápio limpo com sucesso! Agora você pode criar seus itens exclusivos.');
  }

  useEffect(() => {
    carregarMenu();
    const handleStorageChange = () => {
      carregarMenu();
    };
    window.addEventListener('app_storage_change', handleStorageChange);
    return () => window.removeEventListener('app_storage_change', handleStorageChange);
  }, [loja.id]);

  function showToast(msg: string) {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  }

  function carregarMenu() {
    const cats = AppStorage.getCategorias(loja.id);
    const prods = AppStorage.getProdutos(loja.id);
    setCategorias(cats);
    setProdutos(prods);
    if (cats.length > 0 && !categoriaId) {
      setCategoriaId(cats[0].id);
    }
  }

  function handleAddCategoria(e: React.FormEvent) {
    e.preventDefault();
    if (!novaCatNome.trim()) return;
    const cat = AppStorage.addCategoria(loja.id, novaCatNome.trim());
    DataService.addCategoria(loja.id, novaCatNome.trim());
    setNovaCatNome('');
    carregarMenu();
    setCategoriaId(cat.id);
    showToast(`Categoria "${cat.nome}" criada com sucesso!`);
  }

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setIsCompressing(true);
      const result = await compressAndConvertToWebP(file, 800, 0.82);
      setImagemPreview(result.dataUrl);
    } catch {
      showToast('Erro ao processar imagem.');
    } finally {
      setIsCompressing(false);
    }
  }

  function abrirModalCriacao() {
    setEditandoProdutoId(null);
    setNome('');
    setPreco('');
    setPrecoPromocional('');
    setDescricao('');
    setImagemPreview('');
    setDestaqueOferta(false);
    setDestaqueMaisPedido(false);
    setDisponivel(true);
    if (categorias.length > 0) setCategoriaId(categorias[0].id);
    setIsModalOpen(true);
  }

  function abrirModalEdicao(prod: Produto) {
    setEditandoProdutoId(prod.id);
    setNome(prod.nome);
    setPreco(prod.preco.toString());
    setPrecoPromocional(prod.preco_promocional ? prod.preco_promocional.toString() : '');
    setCategoriaId(prod.categoria_id);
    setDescricao(prod.descricao || '');
    setImagemPreview(prod.imagem_url || prod.imagem || '');
    setDestaqueOferta(Boolean(prod.destaque_oferta));
    setDestaqueMaisPedido(Boolean(prod.destaque_mais_pedido));
    setDisponivel(prod.disponivel);
    setIsModalOpen(true);
  }

  async function handleSalvarProduto(e: React.FormEvent) {
    e.preventDefault();
    const precoNum = parseFloat(preco);
    if (isNaN(precoNum) || precoNum <= 0) {
      showToast('Informe um preço válido em R$.');
      return;
    }
    const promoNum = precoPromocional.trim() ? parseFloat(precoPromocional) : undefined;
    let targetCatId = categoriaId || categorias[0]?.id;
    if (!targetCatId) {
      const novaCat = AppStorage.addCategoria(loja.id, 'Cardápio Principal');
      setCategorias((prev) => [...prev, novaCat]);
      targetCatId = novaCat.id;
    }

    const payload = {
      loja_id: loja.id,
      categoria_id: targetCatId,
      nome: nome.trim(),
      descricao: descricao.trim(),
      preco: precoNum,
      preco_promocional: promoNum && promoNum > 0 ? promoNum : undefined,
      preco_original: promoNum && promoNum > 0 ? `R$ ${precoNum.toFixed(2).replace('.', ',')}` : undefined,
      imagem_url:
        imagemPreview ||
        'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80',
      imagem:
        imagemPreview ||
        'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80',
      destaque_oferta: destaqueOferta,
      destaque_mais_pedido: destaqueMaisPedido,
      disponivel: disponivel,
      ativo: disponivel,
      opcionais: [],
    };

    if (editandoProdutoId) {
      AppStorage.updateProduto(editandoProdutoId, payload);
      await DataService.saveProduto({ ...payload, id: editandoProdutoId });
      showToast(`Produto "${payload.nome}" atualizado!`);
    } else {
      const created = AppStorage.addProduto(payload);
      await DataService.saveProduto(created);
      showToast(`Produto "${payload.nome}" adicionado!`);
    }
    setIsModalOpen(false);
    carregarMenu();
  }

  async function handleToggleDisponivel(prod: Produto) {
    const novoStatus = !prod.disponivel;
    AppStorage.updateProduto(prod.id, { disponivel: novoStatus, ativo: novoStatus });
    await DataService.saveProduto({ ...prod, disponivel: novoStatus, ativo: novoStatus });
    carregarMenu();
    showToast(`Item "${prod.nome}" ${novoStatus ? 'ativado' : 'pausado'}.`);
  }

  async function handleConfirmarExclusao() {
    if (produtoParaExcluir) {
      AppStorage.deleteProduto(produtoParaExcluir);
      await DataService.deleteProduto(loja.id, produtoParaExcluir);
      setProdutoParaExcluir(null);
      carregarMenu();
      showToast('Produto removido!');
    }
  }

  const produtosFiltrados = produtos.filter((p) => {
    const matchCat = filtroCategoria === 'todas' || p.categoria_id === filtroCategoria;
    const matchBusca =
      !busca.trim() ||
      p.nome.toLowerCase().includes(busca.toLowerCase()) ||
      p.descricao.toLowerCase().includes(busca.toLowerCase());
    return matchCat && matchBusca;
  });

  return (
    <div className="space-y-6">
      {toastMsg && (
        <div className="fixed top-5 right-5 z-50 bg-emerald-600 text-white font-bold px-4 py-2.5 rounded-xl shadow-lg text-xs flex items-center gap-2 animate-bounce">
          <Check className="w-4 h-4" />
          <span>{toastMsg}</span>
        </div>
      )}

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
              Gestão do Cardápio
            </h2>
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-red-100 dark:bg-red-950/50 text-red-600 dark:text-red-400">
              {produtos.length} produtos
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Qualquer alteração feita aqui reflete no Cardápio do Cliente.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {produtos.length > 0 && (
            <button
              type="button"
              onClick={() => setModalLimparAberto(true)}
              className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold transition cursor-pointer"
              title="Apagar todos os itens de demonstração para começar com cardápio limpo"
            >
              <Trash2 className="w-3.5 h-3.5 text-slate-500" />
              <span>Limpar Cardápio</span>
            </button>
          )}
          <button
            type="button"
            onClick={abrirModalCriacao}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Novo Produto</span>
          </button>
        </div>
      </div>

      <BannerOfertaControl loja={loja} produtos={produtos} onBannerUpdated={carregarMenu} />

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl space-y-3">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
            Categorias do Cardápio:
          </span>
          <form onSubmit={handleAddCategoria} className="flex gap-2 w-full sm:w-auto">
            <input
              type="text"
              placeholder="Nova categoria..."
              value={novaCatNome}
              onChange={(e) => setNovaCatNome(e.target.value)}
              className="text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-red-500 flex-1 sm:w-56"
            />
            <button
              type="submit"
              className="px-3 py-2 bg-slate-800 dark:bg-slate-700 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition cursor-pointer"
            >
              Criar
            </button>
          </form>
        </div>

        <div className="flex flex-wrap gap-2 pt-1">
          <button
            type="button"
            onClick={() => setFiltroCategoria('todas')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              filtroCategoria === 'todas'
                ? 'bg-red-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            Todas ({produtos.length})
          </button>
          {categorias.map((cat) => {
            const count = produtos.filter((p) => p.categoria_id === cat.id).length;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setFiltroCategoria(cat.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  filtroCategoria === cat.id
                    ? 'bg-red-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                {cat.nome} ({count})
              </button>
            );
          })}
        </div>
      </div>

      <div className="relative">
        <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
        <input
          type="text"
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          placeholder="Buscar produto por nome ou ingrediente..."
          className="w-full pl-9 pr-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:border-red-500 shadow-xs"
        />
      </div>

      {produtos.length === 0 ? (
        <div className="p-10 sm:p-14 text-center bg-white dark:bg-slate-900 rounded-3xl border border-dashed border-slate-300 dark:border-slate-800 space-y-4 max-w-lg mx-auto shadow-xs my-4">
          <div className="w-14 h-14 bg-red-50 dark:bg-red-950/40 text-red-600 rounded-2xl flex items-center justify-center mx-auto">
            <Plus className="w-7 h-7" />
          </div>
          <div className="space-y-1">
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
              Seu cardápio está limpo e pronto!
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Você pode cadastrar suas próprias categorias e adicionar seus produtos oficiais com fotos, valores e adicionais.
            </p>
          </div>
          <div className="pt-2 flex flex-col sm:flex-row gap-2 justify-center">
            <button
              type="button"
              onClick={abrirModalCriacao}
              className="px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>Cadastrar Primeiro Produto</span>
            </button>
          </div>
        </div>
      ) : produtosFiltrados.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
          <p className="text-slate-400 text-sm">Nenhum produto encontrado nesta categoria ou busca.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {produtosFiltrados.map((prod) => (
            <div
              key={prod.id}
              className={`bg-white dark:bg-slate-900 border rounded-2xl p-4 flex flex-col justify-between transition relative overflow-hidden ${
                !prod.disponivel
                  ? 'border-dashed border-slate-300 dark:border-slate-700 opacity-60'
                  : 'border-slate-200 dark:border-slate-800 shadow-xs'
              }`}
            >
              <div className="space-y-3">
                <div className="w-full h-36 rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 relative">
                  <img
                    src={prod.imagem_url || prod.imagem}
                    alt={prod.nome}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900 dark:text-white leading-tight">
                    {prod.nome}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                    {prod.descricao}
                  </p>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 mt-3 flex items-center justify-between">
                <div>
                  {prod.preco_promocional ? (
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-xs text-slate-400 line-through">
                        R$ {prod.preco.toFixed(2)}
                      </span>
                      <span className="text-base font-black text-emerald-600 dark:text-emerald-400">
                        R$ {prod.preco_promocional.toFixed(2)}
                      </span>
                    </div>
                  ) : (
                    <span className="text-base font-black text-slate-900 dark:text-white">
                      R$ {prod.preco.toFixed(2)}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleToggleDisponivel(prod)}
                    className={`px-2 py-1 rounded-lg text-[10px] font-bold border transition cursor-pointer ${
                      prod.disponivel
                        ? 'border-emerald-500/30 text-emerald-600 bg-emerald-500/10'
                        : 'border-amber-500/30 text-amber-600 bg-amber-500/10'
                    }`}
                  >
                    {prod.disponivel ? 'Ativo' : 'Pausado'}
                  </button>
                  <button
                    type="button"
                    onClick={() => abrirModalEdicao(prod)}
                    className="p-1.5 text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition cursor-pointer"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setProdutoParaExcluir(prod.id)}
                    className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-lg transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-extrabold text-slate-900 dark:text-white text-base">
                {editandoProdutoId ? 'Editar Produto' : 'Cadastrar Novo Produto'}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSalvarProduto} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Nome do Produto *
                </label>
                <input
                  type="text"
                  required
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  placeholder="Ex: Gran Picanha Artesanal 180g"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-red-500"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Categoria *
                  </label>
                  <select
                    value={categoriaId}
                    onChange={(e) => setCategoriaId(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none"
                  >
                    {categorias.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.nome}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Preço (R$) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={preco}
                    onChange={(e) => setPreco(e.target.value)}
                    placeholder="38.90"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Preço Promocional (Opcional)
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={precoPromocional}
                  onChange={(e) => setPrecoPromocional(e.target.value)}
                  placeholder="34.90"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Descrição
                </label>
                <textarea
                  rows={2}
                  value={descricao}
                  onChange={(e) => setDescricao(e.target.value)}
                  placeholder="Ingredientes..."
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Foto do Produto
                </label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="w-full text-xs text-slate-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-red-50 file:text-red-600 hover:file:bg-red-100 cursor-pointer"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-slate-500 hover:text-slate-700 text-xs font-bold cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isCompressing}
                  className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                >
                  Salvar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {produtoParaExcluir && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-sm w-full p-5 space-y-4 shadow-xl text-center">
            <Trash2 className="w-10 h-10 text-red-600 mx-auto" />
            <h3 className="font-bold text-slate-900 dark:text-white text-base">
              Excluir produto do cardápio?
            </h3>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setProdutoParaExcluir(null)}
                className="w-1/2 py-2 text-xs font-bold bg-slate-100 dark:bg-slate-800 rounded-xl cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmarExclusao}
                className="w-1/2 py-2 text-xs font-bold bg-red-600 hover:bg-red-700 text-white rounded-xl cursor-pointer"
              >
                Excluir
              </button>
            </div>
          </div>
        </div>
      )}

      {modalLimparAberto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-sm w-full p-6 space-y-4 shadow-2xl text-center">
            <div className="w-12 h-12 bg-red-100 dark:bg-red-950/40 text-red-600 rounded-2xl flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="font-extrabold text-slate-900 dark:text-white text-base">
                Limpar Cardápio da Loja?
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Esta ação apagará todos os produtos e categorias desta loja para você começar do zero. Essa ação não pode ser desfeita.
              </p>
            </div>
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setModalLimparAberto(false)}
                className="w-1/2 py-2.5 text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl cursor-pointer hover:bg-slate-200"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleLimparCardapio}
                className="w-1/2 py-2.5 text-xs font-bold bg-red-600 hover:bg-red-700 text-white rounded-xl cursor-pointer shadow-md"
              >
                Confirmar e Limpar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import { useState, useEffect } from 'react';
import {
  Sparkles,
  Eye,
  Check,
  ToggleLeft,
  ToggleRight,
  ArrowRight,
  RefreshCw,
  ShoppingBag,
  Info,
  Image as ImageIcon,
} from 'lucide-react';
import { Loja, Produto, BannerOfertaConfig } from '../../types';
import { AppStorage } from '../../lib/storage';
import { DataService } from '../../lib/supabase';

interface BannerSugestao {
  titulo: string;
  descricao: string;
  badge: string;
  imagem: string;
}

const BANNER_SUGESTOES_POR_SEGMENTO: Record<string, { label: string; icon: string; sugestoes: BannerSugestao[]; imagens: { nome: string; url: string }[] }> = {
  hamburgueria: {
    label: 'Hamburgueria & Lanches',
    icon: '🍔',
    sugestoes: [
      {
        titulo: 'Festival do Smash Burger • 20% OFF',
        descricao: 'Carne 100% Angus com crostinha crocante ultra selada na chapa, queijo cheddar derretido e pão brioche amanteigado.',
        badge: '🔥 20% OFF HOJE',
        imagem: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&auto=format&fit=crop&q=80',
      },
      {
        titulo: 'Combo Casal Smash + Batata Rústica + Refri',
        descricao: 'Dois burgers artesanais completos, porção grande de batata frita e dois refrigerantes.',
        badge: '🍔 COMBO ESPECIAL',
        imagem: 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=800&auto=format&fit=crop&q=80',
      },
      {
        titulo: 'Burger Bacon Supremo Artesanal',
        descricao: 'Muito bacon crocante caramelizado, queijo gouda, cebola crispy e maionese defumada.',
        badge: '⭐ MAIS PEDIDO',
        imagem: 'https://images.unsplash.com/photo-1550547660-d9450f859349?w=800&auto=format&fit=crop&q=80',
      },
    ],
    imagens: [
      { nome: 'Smash Angus', url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&auto=format&fit=crop&q=80' },
      { nome: 'Cheddar Bacon', url: 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=800&auto=format&fit=crop&q=80' },
      { nome: 'Batata Frita', url: 'https://images.unsplash.com/photo-1576107232684-1279f3908594?w=800&auto=format&fit=crop&q=80' },
      { nome: 'Burger Duplo', url: 'https://images.unsplash.com/photo-1550547660-d9450f859349?w=800&auto=format&fit=crop&q=80' },
    ],
  },
  pizzaria: {
    label: 'Pizzaria',
    icon: '🍕',
    sugestoes: [
      {
        titulo: 'Noite da Pizza • Borda Recheada Grátis',
        descricao: 'Peça qualquer pizza grande ou gigante e ganhe borda de catupiry original ou cheddar grátis hoje!',
        badge: '🍕 BORDA GRÁTIS',
        imagem: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=800&auto=format&fit=crop&q=80',
      },
      {
        titulo: 'Combo 2 Pizzas Grandes + Guaraná 2L',
        descricao: 'Duas pizzas tradicionais com massa de fermentação lenta de 48h assadas no forno a lenha.',
        badge: '🚀 SUPER COMBO',
        imagem: 'https://images.unsplash.com/photo-1573821663912-569905455b1c?w=800&auto=format&fit=crop&q=80',
      },
      {
        titulo: 'Pizza Quatro Queijos Nobres Crocante',
        descricao: 'Muçarela, catupiry original, provolone defumado e lascas crocantes de parmesão.',
        badge: '🔥 OFERTA DO DIA',
        imagem: 'https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?w=800&auto=format&fit=crop&q=80',
      },
    ],
    imagens: [
      { nome: 'Forno a Lenha', url: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=800&auto=format&fit=crop&q=80' },
      { nome: 'Queijo Derretido', url: 'https://images.unsplash.com/photo-1573821663912-569905455b1c?w=800&auto=format&fit=crop&q=80' },
      { nome: 'Pizza Fatiada', url: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&auto=format&fit=crop&q=80' },
      { nome: 'Calabresa Artesanal', url: 'https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?w=800&auto=format&fit=crop&q=80' },
    ],
  },
  sushi: {
    label: 'Sushi & Japonesa',
    icon: '🍱',
    sugestoes: [
      {
        titulo: 'Festival Japonês • Combo 30 Peças 25% OFF',
        descricao: 'Salmão fresco de corte nobre, uramakis especiais, sashimis maçaricados e hots crocantes com tarê.',
        badge: '🍱 25% OFF HOJE',
        imagem: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=800&auto=format&fit=crop&q=80',
      },
      {
        titulo: 'Temaki Especial em Dobro',
        descricao: 'Dois temakis com recheio caprichado de salmão em cubos frescos, cream cheese e cebolinha.',
        badge: '🥢 TEMAKI EM DOBRO',
        imagem: 'https://images.unsplash.com/photo-1617196034796-73dfa7b1fd56?w=800&auto=format&fit=crop&q=80',
      },
      {
        titulo: 'Hot Roll Crocante Especial 12 Peças',
        descricao: 'Enrolado frito na hora com farinha panko, salmão, cream cheese e finalizado com molho tarê.',
        badge: '⭐ MAIS PEDIDO',
        imagem: 'https://images.unsplash.com/photo-1611143669185-af224c5e3252?w=800&auto=format&fit=crop&q=80',
      },
    ],
    imagens: [
      { nome: 'Barca Salmão', url: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=800&auto=format&fit=crop&q=80' },
      { nome: 'Temaki Fresco', url: 'https://images.unsplash.com/photo-1617196034796-73dfa7b1fd56?w=800&auto=format&fit=crop&q=80' },
      { nome: 'Hot Roll', url: 'https://images.unsplash.com/photo-1611143669185-af224c5e3252?w=800&auto=format&fit=crop&q=80' },
      { nome: 'Sashimi Nobre', url: 'https://images.unsplash.com/photo-1553621042-f6e147245754?w=800&auto=format&fit=crop&q=80' },
    ],
  },
  acaiteria: {
    label: 'Açaiteria & Sorvetes',
    icon: '🍧',
    sugestoes: [
      {
        titulo: 'Açaí Turbinado 500ml com Nutella & Ninho',
        descricao: 'Açaí cremoso batido na hora com xarope de guaraná, morangos, banana, leite Ninho e Nutella.',
        badge: '🍧 AÇAÍ DO DIA',
        imagem: 'https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?w=800&auto=format&fit=crop&q=80',
      },
      {
        titulo: 'Barca Suprema de Açaí 1 Litro',
        descricao: 'Ideal para compartilhar com a família ou amigos. Acompanha 5 adicionais grátis.',
        badge: '🍓 BARCA SUPREMA',
        imagem: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=800&auto=format&fit=crop&q=80',
      },
    ],
    imagens: [
      { nome: 'Copo Turbinado', url: 'https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?w=800&auto=format&fit=crop&q=80' },
      { nome: 'Taça de Açaí', url: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=800&auto=format&fit=crop&q=80' },
      { nome: 'Frutas Frescas', url: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?w=800&auto=format&fit=crop&q=80' },
    ],
  },
  restaurante: {
    label: 'Restaurante & Marmitex',
    icon: '🍛',
    sugestoes: [
      {
        titulo: 'Marmitex Executivo do Dia com Bebida Grátis',
        descricao: 'Arroz soltinho, feijão temperado, bife acebolado grelhado na brasa, fritas e salada fresca.',
        badge: '🍛 ALMOÇO DO DIA',
        imagem: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80',
      },
      {
        titulo: 'Feijoada Completa para Duas Pessoas',
        descricao: 'Acompanha arroz branco, couve refogada, farofa temperada, vinagrete e torresmo crocante.',
        badge: '⭐ SUCESSO DE VENDAS',
        imagem: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=800&auto=format&fit=crop&q=80',
      },
    ],
    imagens: [
      { nome: 'Prato Executivo', url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80' },
      { nome: 'Grelhado', url: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=800&auto=format&fit=crop&q=80' },
    ],
  },
  bebidas: {
    label: 'Bebidas & Distribuidora',
    icon: '🍺',
    sugestoes: [
      {
        titulo: 'Cervejas Trincando de Geladas • Leve Mais e Pague Menos',
        descricao: 'Packs e fardos servidos super gelados no ponto ideal para seu churrasco e evento.',
        badge: '🍺 SUPER GELADA',
        imagem: 'https://images.unsplash.com/photo-1608270546124-7eb3e6ef6d7f?w=800&auto=format&fit=crop&q=80',
      },
      {
        titulo: 'Combo Destilado + 4 Energéticos + Gelo Grátis',
        descricao: 'Garrafa selada com latas de energético e saco de gelo filtrado incluso.',
        badge: '🚀 COMBO DA NOITE',
        imagem: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?w=800&auto=format&fit=crop&q=80',
      },
    ],
    imagens: [
      { nome: 'Cerveja Gelada', url: 'https://images.unsplash.com/photo-1608270546124-7eb3e6ef6d7f?w=800&auto=format&fit=crop&q=80' },
      { nome: 'Drinks & Gin', url: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?w=800&auto=format&fit=crop&q=80' },
    ],
  },
  doceria: {
    label: 'Doceria & Bolos',
    icon: '🎂',
    sugestoes: [
      {
        titulo: 'Fatia de Bolo Vulcão Ninho & Morango',
        descricao: 'Massa super fofa e úmida com cascata de brigadeiro gourmet e morangos selecionados.',
        badge: '🎂 DOCE DO DIA',
        imagem: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800&auto=format&fit=crop&q=80',
      },
    ],
    imagens: [
      { nome: 'Bolo Vulcão', url: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800&auto=format&fit=crop&q=80' },
    ],
  },
  farmacia: {
    label: 'Farmácia & Cosméticos',
    icon: '💊',
    sugestoes: [
      {
        titulo: 'Semana da Saúde & Cuidados Pessoais',
        descricao: 'Descontos especiais em vitaminas, protetor solar, hidratação e produtos de primeiros socorros.',
        badge: '💊 SAÚDE & CUIDADO',
        imagem: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=800&auto=format&fit=crop&q=80',
      },
    ],
    imagens: [
      { nome: 'Cuidados & Higiene', url: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=800&auto=format&fit=crop&q=80' },
    ],
  },
  mercado: {
    label: 'Mercado & Hortifruti',
    icon: '🛒',
    sugestoes: [
      {
        titulo: 'Quarta e Quinta do Hortifruti Fresco',
        descricao: 'Frutas, legumes e verduras selecionados com preço de feira entregues direto na sua casa.',
        badge: '🛒 FRESCO DO DIA',
        imagem: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&auto=format&fit=crop&q=80',
      },
    ],
    imagens: [
      { nome: 'Hortifruti', url: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&auto=format&fit=crop&q=80' },
    ],
  },
  moda: {
    label: 'Moda & Roupas',
    icon: '👕',
    sugestoes: [
      {
        titulo: 'Nova Coleção com 15% OFF na Primeira Compra',
        descricao: 'Peças exclusivas com tecidos premium, corte moderno e conforto para o seu dia a dia.',
        badge: '👗 NOVIDADES',
        imagem: 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=800&auto=format&fit=crop&q=80',
      },
    ],
    imagens: [
      { nome: 'Roupas & Estilo', url: 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=800&auto=format&fit=crop&q=80' },
    ],
  },
  petshop: {
    label: 'Pet Shop & Rações',
    icon: '🐶',
    sugestoes: [
      {
        titulo: 'Festival Pet • Rações Premium com 15% OFF',
        descricao: 'Nutrição completa e balanceada para cães e gatos, petiscos saborosos e entrega rápida na sua porta.',
        badge: '🐶 15% OFF PET',
        imagem: 'https://images.unsplash.com/photo-1548767797-d8c844163c4c?w=800&auto=format&fit=crop&q=80',
      },
      {
        titulo: 'Combo Petiscos & Brinquedos Interativos',
        descricao: 'Kits especiais para agradar seu pet com petiscos saudáveis e brinquedos para gastar energia.',
        badge: '⭐ COMBO PET',
        imagem: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=800&auto=format&fit=crop&q=80',
      },
    ],
    imagens: [
      { nome: 'Cão Feliz', url: 'https://images.unsplash.com/photo-1548767797-d8c844163c4c?w=800&auto=format&fit=crop&q=80' },
      { nome: 'Pet & Carinho', url: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=800&auto=format&fit=crop&q=80' },
    ],
  },
  manicure: {
    label: 'Salão, Manicure & Estética',
    icon: '💅',
    sugestoes: [
      {
        titulo: 'Esmaltação em Gel & Spa dos Pés • Oferta Especial',
        descricao: 'Unhas impecáveis por semanas, cuticulagem perfeita, esmaltes importados e atendimento de primeira.',
        badge: '💅 PROMOÇÃO BEAUTY',
        imagem: 'https://images.unsplash.com/photo-1604654894610-df63bc536371?w=800&auto=format&fit=crop&q=80',
      },
      {
        titulo: 'Kit Beleza Completo • Manicure + Pedicure',
        descricao: 'Agende seu horário ou adquira os melhores produtos para cuidados das unhas e pele.',
        badge: '✨ COMBO BELEZA',
        imagem: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800&auto=format&fit=crop&q=80',
      },
    ],
    imagens: [
      { nome: 'Unhas Decoradas', url: 'https://images.unsplash.com/photo-1604654894610-df63bc536371?w=800&auto=format&fit=crop&q=80' },
      { nome: 'Spa & Cuidados', url: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800&auto=format&fit=crop&q=80' },
    ],
  },
  outro: {
    label: 'Geral & Outros Negócios',
    icon: '🏪',
    sugestoes: [
      {
        titulo: 'Super Oferta do Dia • Descontos Exclusivos Online',
        descricao: 'Aproveite preços especiais para pedidos feitos diretamente no nosso cardápio digital hoje.',
        badge: '🔥 OFERTA DO DIA',
        imagem: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=800&auto=format&fit=crop&q=80',
      },
    ],
    imagens: [
      { nome: 'Loja Moderna', url: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=800&auto=format&fit=crop&q=80' },
    ],
  },
};

interface BannerOfertaControlProps {
  loja: Loja;
  produtos: Produto[];
  onBannerUpdated?: () => void;
}

export default function BannerOfertaControl({
  loja,
  produtos,
  onBannerUpdated,
}: BannerOfertaControlProps) {
  const initialBanner = loja.banner_oferta;
  const segmentoInicial = (loja.segmento || 'hamburgueria').toLowerCase();
  const segChaveValida = BANNER_SUGESTOES_POR_SEGMENTO[segmentoInicial]
    ? segmentoInicial
    : Object.keys(BANNER_SUGESTOES_POR_SEGMENTO).find((k) => segmentoInicial.includes(k)) || 'hamburgueria';

  const sugestaoPadrao = BANNER_SUGESTOES_POR_SEGMENTO[segChaveValida]?.sugestoes[0] ||
    BANNER_SUGESTOES_POR_SEGMENTO['hamburgueria'].sugestoes[0];

  const [segmentoAtivo, setSegmentoAtivo] = useState<string>(segChaveValida);
  const [ativo, setAtivo] = useState<boolean>(initialBanner?.ativo ?? true);
  const [produtoId, setProdutoId] = useState<string>(
    initialBanner?.produto_id ?? (produtos[0]?.id || '')
  );
  const [titulo, setTitulo] = useState<string>(
    initialBanner?.titulo || sugestaoPadrao.titulo
  );
  const [descricao, setDescricao] = useState<string>(
    initialBanner?.descricao || sugestaoPadrao.descricao
  );
  const [badgeTexto, setBadgeTexto] = useState<string>(
    initialBanner?.badge_texto || sugestaoPadrao.badge
  );
  const [imagemUrl, setImagemUrl] = useState<string>(
    initialBanner?.imagem_url || sugestaoPadrao.imagem
  );
  const [isSaving, setIsSaving] = useState(false);
  const [showSavedFeedback, setShowSavedFeedback] = useState(false);

  useEffect(() => {
    if (loja.banner_oferta) {
      setAtivo(loja.banner_oferta.ativo);
      if (loja.banner_oferta.produto_id) setProdutoId(loja.banner_oferta.produto_id);
      if (loja.banner_oferta.titulo) setTitulo(loja.banner_oferta.titulo);
      if (loja.banner_oferta.descricao) setDescricao(loja.banner_oferta.descricao);
      if (loja.banner_oferta.badge_texto) setBadgeTexto(loja.banner_oferta.badge_texto);
      if (loja.banner_oferta.imagem_url) setImagemUrl(loja.banner_oferta.imagem_url);
    } else {
      // Auto-preenche com as sugestões sob medida da loja
      const segLoja = (loja.segmento || 'hamburgueria').toLowerCase();
      const segMatch = BANNER_SUGESTOES_POR_SEGMENTO[segLoja]
        ? segLoja
        : Object.keys(BANNER_SUGESTOES_POR_SEGMENTO).find((k) => segLoja.includes(k)) || 'hamburgueria';
      const sug = BANNER_SUGESTOES_POR_SEGMENTO[segMatch]?.sugestoes[0];
      if (sug) {
        setTitulo(sug.titulo);
        setDescricao(sug.descricao);
        setBadgeTexto(sug.badge);
        setImagemUrl(sug.imagem);
      }
    }
    if (loja.segmento) {
      const segMatch = BANNER_SUGESTOES_POR_SEGMENTO[loja.segmento.toLowerCase()]
        ? loja.segmento.toLowerCase()
        : Object.keys(BANNER_SUGESTOES_POR_SEGMENTO).find((k) => loja.segmento!.toLowerCase().includes(k));
      if (segMatch) {
        setSegmentoAtivo(segMatch);
      }
    }
  }, [loja.banner_oferta, loja.segmento]);

  function aplicarSugestao(sugestao: BannerSugestao) {
    setTitulo(sugestao.titulo);
    setDescricao(sugestao.descricao);
    setBadgeTexto(sugestao.badge);
    setImagemUrl(sugestao.imagem);
    setAtivo(true);
  }

  function preencherComProduto(id: string) {
    const prod = produtos.find((p) => p.id === id);
    if (!prod) return;
    setProdutoId(prod.id);
    if (prod.nome) setTitulo(prod.nome);
    if (prod.descricao) setDescricao(prod.descricao);
    const fotoProduto = prod.imagem || prod.imagem_url || '';
    if (fotoProduto) {
      setImagemUrl(fotoProduto);
    }
    if (prod.preco_promocional && prod.preco > prod.preco_promocional) {
      const desconto = Math.round(
        ((prod.preco - prod.preco_promocional) / prod.preco) * 100
      );
      setBadgeTexto(`${desconto}% OFF - Oferta Especial`);
    } else {
      setBadgeTexto('⭐ Destaque Especial');
    }
  }

  async function handleToggleAtivo() {
    const novoStatus = !ativo;
    setAtivo(novoStatus);
    await salvarAlteracoes({ ativo: novoStatus });
  }

  async function salvarAlteracoes(overrides?: Partial<BannerOfertaConfig>) {
    setIsSaving(true);
    try {
      const config: BannerOfertaConfig = {
        ativo: overrides?.ativo !== undefined ? overrides.ativo : ativo,
        produto_id: overrides?.produto_id !== undefined ? overrides.produto_id : produtoId,
        titulo: (overrides?.titulo !== undefined ? overrides.titulo : titulo).trim(),
        descricao: (overrides?.descricao !== undefined ? overrides.descricao : descricao).trim(),
        badge_texto: (overrides?.badge_texto !== undefined ? overrides.badge_texto : badgeTexto).trim(),
        imagem_url: (overrides?.imagem_url !== undefined ? overrides.imagem_url : imagemUrl).trim(),
      };
      AppStorage.updateLojaBanner(loja.id, config);
      await DataService.updateLojaBanner(loja.id, config);
      setShowSavedFeedback(true);
      setTimeout(() => setShowSavedFeedback(false), 3000);
      if (onBannerUpdated) onBannerUpdated();
    } catch (e) {
      console.error('Erro ao salvar banner:', e);
    } finally {
      setIsSaving(false);
    }
  }

  const produtoSelecionado = produtos.find((p) => p.id === produtoId);

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs">
      <div className="p-5 border-b border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-800/30 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0 border border-amber-500/20">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white tracking-tight">
                Banner de Destaque / Oferta do Dia
              </h3>
              <span
                className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider transition ${
                  ativo
                    ? 'bg-emerald-100 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800'
                    : 'bg-slate-200 text-slate-600 border border-slate-300 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700'
                }`}
              >
                {ativo ? 'Visível no Cardápio' : 'Banner Oculto'}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Personalize o banner no topo do cardápio para impulsionar conversões e destacar itens do dia.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3 w-full md:w-auto justify-end">
          <button
            type="button"
            onClick={handleToggleAtivo}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer border ${
              ativo
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800'
                : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700'
            }`}
          >
            {ativo ? (
              <>
                <ToggleRight className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                <span>Banner Ativo</span>
              </>
            ) : (
              <>
                <ToggleLeft className="w-5 h-5 text-slate-400" />
                <span>Banner Desativado</span>
              </>
            )}
          </button>
        </div>
      </div>

      <div className="p-5 grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 space-y-4">
          {/* Seletor de Segmento & Sugestões Prontas em 1 Clique */}
          <div className="p-3.5 bg-gradient-to-r from-red-500/10 via-amber-500/10 to-transparent border border-red-500/20 rounded-2xl space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 text-xs font-black text-slate-800 dark:text-slate-100">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>Sugestões Prontas para a sua Loja:</span>
              </div>
              <span className="text-[10px] text-slate-500 dark:text-slate-400">
                Clique para auto-preencher título, texto e imagem
              </span>
            </div>

            {/* Chips de Troca Rápida de Nicho */}
            <div className="flex flex-wrap gap-1.5">
              {Object.entries(BANNER_SUGESTOES_POR_SEGMENTO).map(([key, data]) => {
                const isSelected = segmentoAtivo === key;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setSegmentoAtivo(key)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition flex items-center gap-1 cursor-pointer ${
                      isSelected
                        ? 'bg-red-600 text-white shadow-xs'
                        : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <span>{data.icon}</span>
                    <span>{data.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Cards de Modelos de Oferta do Segmento Selecionado */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              {(BANNER_SUGESTOES_POR_SEGMENTO[segmentoAtivo]?.sugestoes || []).map((sug, sIdx) => (
                <button
                  key={sIdx}
                  type="button"
                  onClick={() => aplicarSugestao(sug)}
                  className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700/80 bg-white/80 dark:bg-slate-800/80 hover:border-red-500 hover:bg-red-50/50 dark:hover:bg-red-950/20 text-left transition flex items-start gap-2.5 group cursor-pointer shadow-xs"
                >
                  <img
                    src={sug.imagem}
                    alt={sug.titulo}
                    className="w-12 h-12 rounded-lg object-cover shrink-0 border border-slate-200 dark:border-slate-700 group-hover:scale-105 transition"
                  />
                  <div className="min-w-0 flex-1 space-y-0.5">
                    <span className="inline-block text-[9px] font-extrabold px-1.5 py-0.2 rounded-sm bg-red-100 dark:bg-red-950 text-red-600 dark:text-red-400">
                      {sug.badge}
                    </span>
                    <p className="text-[11px] font-bold text-slate-900 dark:text-white truncate">
                      {sug.titulo}
                    </p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-1 leading-tight">
                      {sug.descricao}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Produto do Cardápio Vinculado:
            </label>
            <div className="flex gap-2">
              <select
                value={produtoId}
                onChange={(e) => {
                  setProdutoId(e.target.value);
                  preencherComProduto(e.target.value);
                }}
                className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2.5 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-red-500"
              >
                <option value="">-- Selecione um produto para vincular --</option>
                {produtos.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.nome} • R$ {p.preco.toFixed(2)}
                  </option>
                ))}
              </select>
              {produtoSelecionado && (
                <button
                  type="button"
                  onClick={() => preencherComProduto(produtoId)}
                  className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 shrink-0 transition cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  Auto-preencher
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Título da Oferta:
              </label>
              <input
                type="text"
                value={titulo}
                onChange={(e) => setTitulo(e.target.value)}
                placeholder="Ex: Festival do Smash Burger"
                className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-red-500 font-semibold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Texto da Etiqueta (Badge):
              </label>
              <input
                type="text"
                value={badgeTexto}
                onChange={(e) => setBadgeTexto(e.target.value)}
                placeholder="Ex: 🔥 OFERTA DO DIA"
                className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-red-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Descrição Promocional:
            </label>
            <textarea
              rows={3}
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
              placeholder="Descreva a oferta especial..."
              className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-red-500 leading-relaxed resize-none"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              URL da Foto / Imagem do Banner:
            </label>
            <input
              type="url"
              value={imagemUrl}
              onChange={(e) => setImagemUrl(e.target.value)}
              placeholder="https://images.unsplash.com/..."
              className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-red-500 font-mono text-[11px]"
            />

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
              {(BANNER_SUGESTOES_POR_SEGMENTO[segmentoAtivo]?.imagens || []).map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setImagemUrl(preset.url)}
                  className={`flex items-center gap-2 p-1.5 rounded-xl border text-left text-[11px] transition cursor-pointer ${
                    imagemUrl === preset.url
                      ? 'border-red-500 bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 font-bold'
                      : 'border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-800/60'
                  }`}
                >
                  <img
                    src={preset.url}
                    alt={preset.nome}
                    className="w-7 h-7 rounded-lg object-cover shrink-0"
                  />
                  <span className="truncate">{preset.nome}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="pt-2 flex items-center gap-3">
            <button
              type="button"
              disabled={isSaving}
              onClick={() => salvarAlteracoes()}
              className="px-5 py-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white rounded-xl text-xs font-extrabold transition shadow-xs flex items-center gap-2 cursor-pointer"
            >
              {isSaving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              <span>Salvar e Atualizar Cardápio</span>
            </button>
            {showSavedFeedback && (
              <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <Check className="w-3.5 h-3.5" /> Atualizado em tempo real!
              </span>
            )}
          </div>
        </div>

        <div className="lg:col-span-5 flex flex-col justify-between space-y-3">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5 text-amber-500" />
                Prévia ao Vivo no Cardápio:
              </span>
            </div>
            <div
              className={`relative rounded-2xl overflow-hidden shadow-md bg-gradient-to-r from-red-950 via-red-900 to-amber-900 text-white p-4 flex flex-col justify-between gap-4 border border-red-800/40 transition duration-300 ${
                !ativo ? 'opacity-40 grayscale-[40%]' : ''
              }`}
            >
              <div className="space-y-2">
                <div className="inline-flex items-center gap-1 bg-red-600/90 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider shadow-xs">
                  <Sparkles className="w-3 h-3 fill-yellow-300 text-yellow-300" />
                  {badgeTexto || '🔥 OFERTA DO DIA'}
                </div>
                <h4 className="text-base font-black tracking-tight leading-tight text-white line-clamp-2">
                  {titulo || 'Festival do Smash Burger'}
                </h4>
                <p className="text-[11px] text-red-100/90 leading-relaxed line-clamp-3">
                  {descricao || 'Carne 100% Angus com crostinha crocante ultra selada na chapa...'}
                </p>
              </div>
              <div className="flex items-center justify-between gap-3 pt-1 border-t border-red-800/40">
                <div className="flex items-center gap-1 text-[11px] font-bold text-white bg-white/20 px-3 py-1.5 rounded-lg">
                  Pedir Oferta <ArrowRight className="w-3 h-3" />
                </div>
                <div className="w-16 h-14 rounded-lg overflow-hidden shrink-0 border border-white/30 shadow-xs">
                  <img
                    src={imagemUrl || 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80'}
                    alt="Preview"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

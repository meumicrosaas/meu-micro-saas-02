import { useState, useEffect } from 'react';
import { Loja, Produto, DeliveryType, PaymentMethod, ItemPedido, Cliente } from '../../types';
import { AppStorage } from '../../lib/storage';
import { DataService } from '../../lib/supabase';
import { ShoppingCart, CheckCircle, User, Phone, Check, ArrowRight } from 'lucide-react';

interface PosExpressOrderProps {
  loja: Loja;
  onOrderCreated: () => void;
}

export default function PosExpressOrder({ loja, onOrderCreated }: PosExpressOrderProps) {
  const [produtos, setProdutos] = useState<Produto[]>([]);
  const [clienteNome, setClienteNome] = useState('');
  const [clienteTelefone, setClienteTelefone] = useState('');
  const [clienteEncontrado, setClienteEncontrado] = useState<Cliente | null>(null);
  const [tipoEntrega, setTipoEntrega] = useState<DeliveryType>('delivery');
  const [enderecoDestino, setEnderecoDestino] = useState('');
  const [taxaEntrega, setTaxaEntrega] = useState(loja.taxa_base_entrega.toString());
  const [metodoPagamento, setMetodoPagamento] = useState<PaymentMethod>('dinheiro');
  const [trocoPara, setTrocoPara] = useState('');

  const [carrinhoItens, setCarrinhoItens] = useState<
    { produto: Produto; quantidade: number; observacao: string }[]
  >([]);
  const [sucesso, setSucesso] = useState(false);
  const [erro, setErro] = useState('');

  useEffect(() => {
    carregarProdutos();
    const handleStorage = () => carregarProdutos();
    window.addEventListener('app_storage_change', handleStorage);
    return () => window.removeEventListener('app_storage_change', handleStorage);
  }, [loja.id]);

  function carregarProdutos() {
    setProdutos(AppStorage.getProdutos(loja.id).filter((p) => p.disponivel !== false));
  }

  useEffect(() => {
    const limpo = clienteTelefone.replace(/\D/g, '');
    if (limpo.length >= 8) {
      const cliente = AppStorage.findClienteByTelefone(loja.id, limpo);
      if (cliente) {
        setClienteEncontrado(cliente);
        if (!clienteNome) setClienteNome(cliente.nome);
        if (!enderecoDestino && cliente.endereco) {
          const compl = [cliente.endereco, cliente.numero, cliente.complemento, cliente.bairro]
            .filter(Boolean)
            .join(', ');
          setEnderecoDestino(compl || cliente.endereco);
        }
      } else {
        setClienteEncontrado(null);
      }
    } else {
      setClienteEncontrado(null);
    }
  }, [clienteTelefone, loja.id]);

  function adicionarItem(produto: Produto) {
    const idx = carrinhoItens.findIndex((i) => i.produto.id === produto.id);
    if (idx !== -1) {
      const novos = [...carrinhoItens];
      novos[idx].quantidade += 1;
      setCarrinhoItens(novos);
    } else {
      setCarrinhoItens([...carrinhoItens, { produto, quantidade: 1, observacao: '' }]);
    }
  }

  function alterarQuantidade(index: number, delta: number) {
    const novos = [...carrinhoItens];
    novos[index].quantidade += delta;
    if (novos[index].quantidade <= 0) {
      setCarrinhoItens(novos.filter((_, i) => i !== index));
    } else {
      setCarrinhoItens(novos);
    }
  }

  const subtotal = carrinhoItens.reduce(
    (acc, curr) => acc + (curr.produto.preco_promocional || curr.produto.preco) * curr.quantidade,
    0
  );
  const taxaEntregaNum = tipoEntrega === 'delivery' ? parseFloat(taxaEntrega) || 0 : 0;
  const total = subtotal + taxaEntregaNum;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErro('');
    if (carrinhoItens.length === 0) {
      setErro('Selecione ao menos um produto para lançar o pedido.');
      return;
    }
    if (!clienteNome.trim() || !clienteTelefone.trim()) {
      setErro('Preencha o nome e o WhatsApp do cliente.');
      return;
    }

    const pedidoId = `ped-pdv-${Date.now()}`;
    const itensConvertidos: ItemPedido[] = carrinhoItens.map((ci, idx) => {
      const unitario = ci.produto.preco_promocional || ci.produto.preco;
      return {
        id: `item-${Date.now()}-${idx}`,
        pedido_id: pedidoId,
        produto_id: ci.produto.id,
        produto_nome: ci.produto.nome,
        quantidade: ci.quantidade,
        preco_unitario: unitario,
        observacao: ci.observacao,
        opcionais: [],
        total_item: unitario * ci.quantidade,
      };
    });

    const novoPedido = {
      id: pedidoId,
      loja_id: loja.id,
      codigo_pedido: `#PDV-${Math.floor(100 + Math.random() * 900)}`,
      cliente_nome: clienteNome,
      cliente_telefone: clienteTelefone,
      tipo_entrega: tipoEntrega,
      endereco_destino: tipoEntrega === 'delivery' ? enderecoDestino : undefined,
      endereco_completo: tipoEntrega === 'delivery' ? enderecoDestino : 'Balcão / Retirada',
      distancia_km: tipoEntrega === 'delivery' ? 2.5 : 0,
      taxa_entrega: taxaEntregaNum,
      subtotal,
      total,
      status: 'em_preparo' as const,
      status_pagamento: 'pago' as const,
      metodo_pagamento: metodoPagamento,
      forma_pagamento: metodoPagamento,
      troco_para: trocoPara ? parseFloat(trocoPara) : undefined,
      impresso: false,
      itens: itensConvertidos,
      created_at: new Date().toISOString(),
    };

    AppStorage.saveCliente({
      loja_id: loja.id,
      nome: clienteNome,
      telefone: clienteTelefone,
      endereco: enderecoDestino,
    });
    await DataService.saveCliente({
      loja_id: loja.id,
      nome: clienteNome,
      telefone: clienteTelefone,
      endereco: enderecoDestino,
    });

    AppStorage.addPedido(novoPedido);
    await DataService.createPedido(novoPedido);
    setSucesso(true);
    setCarrinhoItens([]);
    setClienteNome('');
    setClienteTelefone('');
    setClienteEncontrado(null);
    setEnderecoDestino('');
    setTrocoPara('');
    onOrderCreated();
    setTimeout(() => setSucesso(false), 4000);
  }

  return (
    <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
      <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-4">
        <div>
          <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-red-600" />
            Lançamento Manual de Pedidos (PDV / Balcão / WhatsApp)
          </h3>
          <p className="text-xs text-slate-500">
            Digite o telefone para buscar o cliente automaticamente no banco de dados.
          </p>
        </div>
      </div>

      {sucesso && (
        <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-semibold flex items-center gap-2">
          <CheckCircle className="w-5 h-5" />
          <span>Pedido lançado com sucesso no sistema!</span>
        </div>
      )}

      {erro && (
        <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-600 dark:text-red-400 text-xs font-semibold flex items-center justify-between">
          <span>{erro}</span>
          <button
            type="button"
            onClick={() => setErro('')}
            className="text-red-400 hover:text-red-600 font-bold ml-2"
          >
            ✕
          </button>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-50 dark:bg-slate-800/40 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-red-600" />
              Telefone WhatsApp do Cliente *
            </label>
            <input
              type="text"
              required
              value={clienteTelefone}
              onChange={(e) => setClienteTelefone(e.target.value)}
              placeholder="DDD + Número (ex: 67999887766)"
              className="w-full text-xs px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-red-500"
            />
            {clienteEncontrado && (
              <div className="mt-1.5 p-2 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 rounded-lg text-[11px] text-emerald-800 dark:text-emerald-300 font-bold flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5" />
                <span>Cliente cadastrado: {clienteEncontrado.nome}</span>
              </div>
            )}
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-red-600" />
              Nome do Cliente *
            </label>
            <input
              type="text"
              required
              value={clienteNome}
              onChange={(e) => setClienteNome(e.target.value)}
              placeholder="Nome do cliente"
              className="w-full text-xs px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-red-500"
            />
          </div>
          <div className="md:col-span-2">
            <div className="flex gap-4 mb-2">
              <label className="flex items-center gap-1.5 text-xs font-bold cursor-pointer">
                <input
                  type="radio"
                  name="tipoEntrega"
                  checked={tipoEntrega === 'delivery'}
                  onChange={() => setTipoEntrega('delivery')}
                  className="text-red-600 focus:ring-0"
                />
                🛵 Entrega / Delivery
              </label>
              <label className="flex items-center gap-1.5 text-xs font-bold cursor-pointer">
                <input
                  type="radio"
                  name="tipoEntrega"
                  checked={tipoEntrega === 'retirada'}
                  onChange={() => setTipoEntrega('retirada')}
                  className="text-red-600 focus:ring-0"
                />
                🛍️ Retirada no Balcão
              </label>
            </div>
            {tipoEntrega === 'delivery' && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="md:col-span-2">
                  <input
                    type="text"
                    required
                    value={enderecoDestino}
                    onChange={(e) => setEnderecoDestino(e.target.value)}
                    placeholder="Endereço de entrega completo (Rua, Número, Bairro)"
                    className="w-full text-xs px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-red-500"
                  />
                </div>
                <div>
                  <input
                    type="number"
                    step="0.1"
                    value={taxaEntrega}
                    onChange={(e) => setTaxaEntrega(e.target.value)}
                    placeholder="Taxa (R$)"
                    className="w-full text-xs px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none"
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
            Adicionar Produtos ao Pedido:
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 max-h-56 overflow-y-auto p-1">
            {produtos.map((p) => {
              const valor = p.preco_promocional || p.preco;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => adicionarItem(p)}
                  className="text-left p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-red-500 transition text-xs flex flex-col justify-between cursor-pointer"
                >
                  <span className="font-bold text-slate-900 dark:text-white line-clamp-1">
                    {p.nome}
                  </span>
                  <div className="flex justify-between items-center mt-2">
                    <span className="font-black text-emerald-600">R$ {valor.toFixed(2)}</span>
                    <span className="bg-red-50 dark:bg-red-950 text-red-600 px-1.5 py-0.5 rounded-md text-[10px] font-bold">
                      + Add
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {carrinhoItens.length > 0 && (
          <div className="border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-3 bg-white dark:bg-slate-900">
            <h4 className="font-bold text-xs text-slate-800 dark:text-slate-200">
              Itens do Pedido ({carrinhoItens.length})
            </h4>
            <div className="space-y-2">
              {carrinhoItens.map((item, idx) => {
                const valorUnitario = item.produto.preco_promocional || item.produto.preco;
                return (
                  <div
                    key={idx}
                    className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 p-2.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl text-xs"
                  >
                    <div>
                      <span className="font-bold text-slate-900 dark:text-white">
                        {item.produto.nome}
                      </span>
                      <span className="text-slate-500 ml-2">R$ {valorUnitario.toFixed(2)} un.</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => alterarQuantidade(idx, -1)}
                          className="w-6 h-6 rounded bg-slate-200 dark:bg-slate-700 flex items-center justify-center font-bold cursor-pointer"
                        >
                          -
                        </button>
                        <span className="w-5 text-center font-bold">{item.quantidade}</span>
                        <button
                          type="button"
                          onClick={() => alterarQuantidade(idx, 1)}
                          className="w-6 h-6 rounded bg-red-600 text-white flex items-center justify-center font-bold cursor-pointer"
                        >
                          +
                        </button>
                      </div>
                      <span className="font-bold text-slate-900 dark:text-white min-w-16 text-right">
                        R$ {(valorUnitario * item.quantidade).toFixed(2)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row justify-between sm:items-center gap-4">
              <div className="flex items-center gap-3">
                <span className="text-xs font-bold">Forma de Pagamento:</span>
                <select
                  value={metodoPagamento}
                  onChange={(e) => setMetodoPagamento(e.target.value as PaymentMethod)}
                  className="text-xs px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                >
                  <option value="dinheiro">Dinheiro</option>
                  <option value="pix_online">PIX</option>
                  <option value="maquininha">Cartão / Maquininha</option>
                </select>
              </div>
              <div className="text-right">
                <p className="text-base font-black text-slate-900 dark:text-white">
                  Total do Pedido: <span className="text-red-600">R$ {total.toFixed(2)}</span>
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={carrinhoItens.length === 0}
            className="px-6 py-3 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-xs transition flex items-center gap-2 cursor-pointer"
          >
            Lançar Pedido no Sistema <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </form>
    </div>
  );
}

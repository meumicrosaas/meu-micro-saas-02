import { useState, useEffect } from 'react';
import {
  ShoppingBag,
  AlertTriangle,
  ExternalLink,
  RefreshCw,
  Clock,
  TrendingUp,
  Receipt,
  UtensilsCrossed,
  Navigation,
  CreditCard,
  PlusCircle,
  QrCode,
  PackageCheck,
  Printer,
  Zap,
  Percent,
  LogOut,
  Image as ImageIcon,
  Store,
  Copy,
  Check,
  Landmark,
  Smartphone,
  Truck,
  Lock,
} from 'lucide-react';
import { AppStorage } from '../../lib/storage';
import { DataService } from '../../lib/supabase';
import { Loja, SaasAssinatura, Pedido, OrderStatus, AvisoGlobal, SaasPlanSettings } from '../../types';
import ThermalReceipt from '../ThermalReceipt';
import MenuManagement from './MenuManagement';
import DeliveryCalculatorSettings from './DeliveryCalculatorSettings';
import PosExpressOrder from './PosExpressOrder';
import PaymentGatewaySettings from './PaymentGatewaySettings';
import PrinterSettings from './PrinterSettings';
import StoreLogoAvatar from '../Common/StoreLogoAvatar';
import StoreLogoUploader from '../Common/StoreLogoUploader';
import MerchantLoginView from './MerchantLoginView';
import PwaStorePreview from './PwaStorePreview';
import { sanitizeSlug } from '../../lib/slug';

interface MerchantDashboardProps {
  currentLojaId?: string;
  onNavigateToPublicStore: (slug: string) => void;
  onNavigateToAssinaturaPendente: () => void;
  onNavigateToSignup?: () => void;
  onNavigateToSuperAdmin?: () => void;
  onNavigateTermos?: () => void;
}

export default function MerchantDashboard({
  currentLojaId,
  onNavigateToPublicStore,
  onNavigateToAssinaturaPendente,
  onNavigateToSignup,
  onNavigateToSuperAdmin,
  onNavigateTermos,
}: MerchantDashboardProps) {
  const [selectedLojaId, setSelectedLojaId] = useState<string>(currentLojaId || '');
  const [loja, setLoja] = useState<Loja | null>(null);
  const [assinatura, setAssinatura] = useState<SaasAssinatura | null>(null);
  const [pedidos, setPedidos] = useState<Pedido[]>([]);
  const [, setAuthVersion] = useState(0);
  const [activeTab, setActiveTab] = useState<
    'pedidos' | 'cardapio' | 'pdv' | 'impressora' | 'frete' | 'pagamentos' | 'identidade' | 'pwa'
  >('pedidos');
  const [modalRenovacao, setModalRenovacao] = useState(false);
  const [autoPrintPedidoId, setAutoPrintPedidoId] = useState<string | null>(null);

  const [avisos] = useState<AvisoGlobal[]>(AppStorage.getAvisosGlobais());
  const [dismissedAvisos, setDismissedAvisos] = useState<string[]>([]);
  const [planSettings] = useState<SaasPlanSettings>(AppStorage.getSaasPlanSettings());
  const [chaveCopiada, setChaveCopiada] = useState(false);
  const [linkCopiado, setLinkCopiado] = useState(false);

  useEffect(() => {
    const todasLojas = AppStorage.getLojas();
    const activeStoredId = AppStorage.getActiveLojaId();
    const targetId = currentLojaId || activeStoredId || todasLojas[0]?.id || '';
    setSelectedLojaId(targetId);
    if (targetId && targetId !== activeStoredId) {
      AppStorage.setActiveLojaId(targetId);
    }
  }, [currentLojaId]);

  useEffect(() => {
    if (selectedLojaId) {
      carregarLoja(selectedLojaId);
    }
  }, [selectedLojaId]);

  function carregarLoja(id: string) {
    const l = AppStorage.getLojaById(id);
    const ass = AppStorage.getAssinaturaByLoja(id);
    const peds = AppStorage.getPedidos(id);
    setLoja(l || null);
    setAssinatura(ass || null);
    setPedidos(peds);
    if (l?.status_conta === 'bloqueada') {
      onNavigateToAssinaturaPendente();
    }
  }

  async function handleAtualizarStatusPedido(pedidoId: string, status: OrderStatus) {
    AppStorage.updatePedidoStatus(pedidoId, status);
    await DataService.updatePedidoStatus(pedidoId, status);
    if (status === 'em_preparo' && loja?.impressora_auto_imprimir) {
      setAutoPrintPedidoId(pedidoId);
      try {
        setTimeout(() => window.print(), 300);
      } catch {}
    }
    if (loja) {
      setPedidos(AppStorage.getPedidos(loja.id));
    }
  }

  useEffect(() => {
    const handleAuthChange = () => setAuthVersion((v) => v + 1);
    window.addEventListener('merchant_auth_change', handleAuthChange);
    return () => window.removeEventListener('merchant_auth_change', handleAuthChange);
  }, []);

  if (!loja) {
    return <div className="p-8 text-center text-slate-500">Nenhuma loja selecionada.</div>;
  }

  const isMerchantAuth = AppStorage.getAuthenticatedMerchantLojaId() === loja.id;
  const slugDestino = (loja.slug || sanitizeSlug(loja.nome_loja || loja.nome || '') || loja.id).trim();

  if (!isMerchantAuth) {
    return (
      <MerchantLoginView
        loja={loja}
        onLoginSuccess={(lojaLogada) => {
          if (lojaLogada) {
            setSelectedLojaId(lojaLogada.id);
            carregarLoja(lojaLogada.id);
          }
          setAuthVersion((v) => v + 1);
        }}
        onNavigateToSignup={onNavigateToSignup || (() => {})}
        onNavigateToSuperAdmin={onNavigateToSuperAdmin}
        onNavigateTermos={onNavigateTermos}
      />
    );
  }

  let diasParaVencer: number | null = null;
  let vencida = false;
  if (assinatura) {
    const diffMs = new Date(assinatura.data_vencimento).getTime() - Date.now();
    diasParaVencer = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
    vencida = diasParaVencer < 0;
  }

  // Se a loja estiver bloqueada ou com assinatura vencida, bloqueia totalmente o painel até pagar
  if (loja.status_conta === 'bloqueada' || vencida || assinatura?.status === 'bloqueada') {
    return (
      <div className="max-w-xl mx-auto my-12 p-8 bg-slate-900 border border-red-500/30 rounded-3xl text-center space-y-6 shadow-2xl text-white">
        <div className="w-16 h-16 bg-red-500/10 text-red-500 rounded-full flex items-center justify-center mx-auto border border-red-500/20">
          <Lock className="w-8 h-8" />
        </div>
        <div>
          <span className="text-xs uppercase tracking-wider font-bold text-red-400 bg-red-500/10 px-3 py-1 rounded-full border border-red-500/20">
            Período de Uso Expirado
          </span>
          <h2 className="text-2xl font-black mt-3">Acesso ao Painel Suspenso</h2>
          <p className="text-xs text-slate-400 mt-2 leading-relaxed">
            O período de teste ou a mensalidade da sua loja <strong>{loja.nome_loja}</strong> está vencida.
            Efetue o pagamento via <strong>Mercado Pago</strong>, <strong>AbacatePay</strong> ou <strong>PIX</strong> para liberar o acesso automaticamente.
          </p>
        </div>
        <div className="pt-2 space-y-3">
          <button
            type="button"
            onClick={onNavigateToAssinaturaPendente}
            className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl text-xs transition shadow-lg cursor-pointer flex items-center justify-center gap-2"
          >
            <CreditCard className="w-4 h-4" />
            <span>Pagar Mensalidade e Desbloquear Acesso Imediatamente</span>
          </button>
          <button
            type="button"
            onClick={() => {
              AppStorage.logoutMerchant();
              setAuthVersion((v) => v + 1);
            }}
            className="text-xs text-slate-400 hover:text-white transition cursor-pointer"
          >
            Sair desta conta
          </button>
        </div>
      </div>
    );
  }

  const vendasHoje = pedidos.reduce((acc, p) => acc + (p.status !== 'cancelado' ? p.total : 0), 0);
  const pedidosAbertos = pedidos.filter((p) => p.status === 'pendente' || p.status === 'em_preparo').length;
  const ticketMedio = pedidos.length > 0 ? vendasHoje / (pedidos.length || 1) : 0;

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {diasParaVencer !== null && diasParaVencer <= 5 && diasParaVencer >= 0 && (
        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-900 dark:text-amber-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />
            <div className="text-xs">
              <span className="font-bold">Aviso de Renovação do SaaS: </span>
              <span>
                Sua assinatura vence em <strong>{diasParaVencer} {diasParaVencer === 1 ? 'dia' : 'dias'}</strong>. Antecipe o pagamento para manter seu cardápio online sem interrupções.
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onNavigateToAssinaturaPendente}
            className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl transition shrink-0 cursor-pointer shadow-xs"
          >
            Renovar Agora
          </button>
        </div>
      )}

      <header className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-2xl shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="relative group shrink-0">
            <StoreLogoAvatar
              nomeLoja={loja.nome_loja}
              logoUrl={loja.logo_url}
              size="lg"
              className="ring-2 ring-slate-200 dark:ring-slate-700 shadow-xs cursor-pointer"
            />
            <button
              type="button"
              onClick={() => setActiveTab('identidade')}
              className="absolute -bottom-1 -right-1 p-1.5 bg-red-600 hover:bg-red-700 text-white rounded-full shadow-md cursor-pointer transition transform group-hover:scale-110"
              title="Personalizar Logo"
            >
              <ImageIcon className="w-3 h-3" />
            </button>
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                {loja.nome_loja}
              </h1>
              <span
                className={`text-xs px-2.5 py-0.5 rounded-full font-bold flex items-center gap-1 ${
                  loja.status_conta === 'ativa'
                    ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                    : 'bg-red-500/10 text-red-600 dark:text-red-400 border border-red-500/20'
                }`}
              >
                {loja.status_conta === 'ativa' ? 'LOJA ATIVA' : 'BLOQUEADA'}
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-3 text-xs">
              <button
                type="button"
                onClick={() => {
                  const url = `${window.location.origin}/loja/${encodeURIComponent(slugDestino)}`;
                  window.open(url, '_blank', 'noopener,noreferrer');
                }}
                className="text-red-600 dark:text-red-400 hover:underline flex items-center gap-1 font-semibold cursor-pointer text-left"
                title="Abrir cardápio público oficial em nova guia"
              >
                Ver Cardápio Público (/loja/{slugDestino}) <ExternalLink className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => {
                  const url = `${window.location.origin}/loja/${encodeURIComponent(slugDestino)}`;
                  navigator.clipboard.writeText(url);
                  setLinkCopiado(true);
                  setTimeout(() => setLinkCopiado(false), 2500);
                }}
                className="text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1 cursor-pointer font-medium"
                title="Copiar link do cardápio para enviar no WhatsApp"
              >
                {linkCopiado ? (
                  <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" /> Link Copiado!
                  </span>
                ) : (
                  <span className="flex items-center gap-1">
                    <Copy className="w-3.5 h-3.5" /> Copiar Link
                  </span>
                )}
              </button>
              <span className="text-slate-300 dark:text-slate-700">|</span>
              <span className="text-slate-500">WhatsApp: {loja.telefone_whatsapp}</span>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => {
              const url = `${window.location.origin}/loja/${encodeURIComponent(slugDestino)}`;
              window.open(url, '_blank', 'noopener,noreferrer');
            }}
            className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-red-600 hover:bg-red-700 text-white transition flex items-center gap-1.5 shadow-sm cursor-pointer active:scale-95"
            title="Abrir cardápio público da sua loja em nova guia"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Ver Cardápio Público</span>
          </button>
          <button
            type="button"
            onClick={() => {
              const novoStatus = !loja.aberto;
              AppStorage.updateLoja(loja.id, { aberto: novoStatus });
              setLoja({ ...loja, aberto: novoStatus });
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
              loja.aberto !== false
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-800'
                : 'bg-red-50 text-red-700 border-red-200 hover:bg-red-100 dark:bg-red-950/50 dark:text-red-300 dark:border-red-800'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                loja.aberto !== false ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'
              }`}
            />
            {loja.aberto !== false ? 'Recebendo Pedidos (Aberto)' : 'Loja Pausada (Fechada)'}
          </button>
          <button
            type="button"
            onClick={() => {
              AppStorage.logoutMerchant();
              setAuthVersion((v) => v + 1);
            }}
            className="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 border border-slate-200 dark:border-slate-800 transition flex items-center gap-1.5 cursor-pointer"
            title="Encerrar Sessão"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sair</span>
          </button>
        </div>
      </header>

      {avisos
        .filter((a) => a.ativo && !dismissedAvisos.includes(a.id))
        .map((aviso) => (
          <div
            key={aviso.id}
            className="p-4 rounded-2xl flex items-start justify-between gap-3 border shadow-xs bg-blue-500/10 border-blue-500/30 text-blue-900 dark:text-blue-200"
          >
            <div>
              <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">
                {aviso.titulo}
              </h4>
              <p className="text-xs opacity-95">{aviso.mensagem}</p>
            </div>
            <button
              type="button"
              onClick={() => setDismissedAvisos([...dismissedAvisos, aviso.id])}
              className="text-slate-400 hover:text-slate-700 dark:hover:text-white cursor-pointer"
            >
              ✕
            </button>
          </div>
        ))}

      <nav className="flex flex-wrap gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
        {[
          { id: 'pedidos', label: 'Pedidos em Tempo Real', icon: Receipt },
          { id: 'cardapio', label: 'Gestão do Cardápio', icon: UtensilsCrossed },
          { id: 'pdv', label: 'Lançar Pedido (PDV/Balcão)', icon: PlusCircle },
          { id: 'impressora', label: 'Impressora Térmica (80mm/58mm)', icon: Printer },
          { id: 'frete', label: 'Cálculo de Frete (Haversine)', icon: Navigation },
          { id: 'pagamentos', label: 'Gateways & Chave Pix', icon: CreditCard },
          { id: 'identidade', label: 'Logo & Marca', icon: ImageIcon },
          { id: 'pwa', label: 'App Mobile (PWA)', icon: Smartphone },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {activeTab === 'pedidos' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs">
              <span className="text-xs font-semibold text-slate-500 uppercase">
                Vendas Hoje
              </span>
              <p className="text-2xl font-black text-slate-900 dark:text-white mt-1">
                R$ {vendasHoje.toFixed(2)}
              </p>
              <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold mt-1 inline-flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5" /> {pedidos.length} pedidos hoje
              </span>
            </div>
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs">
              <span className="text-xs font-semibold text-slate-500 uppercase">
                Pedidos em Aberto
              </span>
              <p className="text-2xl font-black text-amber-500 mt-1">{pedidosAbertos}</p>
              <span className="text-[11px] text-slate-500 mt-1 inline-flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" /> Pendentes ou em preparo
              </span>
            </div>
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs">
              <span className="text-xs font-semibold text-slate-500 uppercase">Ticket Médio</span>
              <p className="text-2xl font-black text-slate-900 dark:text-white mt-1">
                R$ {ticketMedio.toFixed(2)}
              </p>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-2xl shadow-xs space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-base">
                  Fluxo de Pedidos em Tempo Real ({pedidos.length})
                </h3>
              </div>
              <button
                type="button"
                onClick={() => carregarLoja(loja.id)}
                className="text-xs bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" /> Atualizar
              </button>
            </div>
            <div className="space-y-3">
              {pedidos.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-sm">
                  <ShoppingBag className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
                  Nenhum pedido recebido ainda.
                </div>
              ) : (
                pedidos.map((ped) => (
                  <div
                    key={ped.id}
                    className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/40 space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-slate-200/60 dark:border-slate-800 pb-2.5">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-slate-900 dark:text-white text-sm">
                            {ped.codigo_pedido}
                          </span>
                          <span className="font-bold text-slate-800 dark:text-slate-200 text-sm">
                            {ped.cliente_nome}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          {ped.cliente_telefone} |{' '}
                          {ped.tipo_entrega === 'delivery'
                            ? `🛵 Delivery (${ped.endereco_destino || ped.endereco_completo})`
                            : '🛍️ Retirada'}
                        </p>
                      </div>
                      <ThermalReceipt
                        pedido={ped}
                        nomeLoja={loja.nome_loja}
                        defaultLargura={loja.impressora_largura || '80mm'}
                        defaultFonte={loja.impressora_fonte || 'normal'}
                        defaultVias={loja.impressora_vias || 1}
                        autoOpen={autoPrintPedidoId === ped.id}
                      />
                    </div>
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pt-2 text-xs">
                      <span className="font-extrabold text-red-600 dark:text-red-400 text-sm">
                        Total: R$ {Number(ped.total).toFixed(2)}
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {ped.status === 'pendente' && (
                          <button
                            type="button"
                            onClick={() => handleAtualizarStatusPedido(ped.id, 'em_preparo')}
                            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-2.5 py-1 rounded-lg text-[11px] transition flex items-center gap-1 cursor-pointer"
                          >
                            <Zap className="w-3 h-3 text-yellow-300" /> Aceitar (Em Preparo)
                          </button>
                        )}
                        {ped.status === 'em_preparo' && (
                          <button
                            type="button"
                            onClick={() => handleAtualizarStatusPedido(ped.id, 'saiu_entrega')}
                            className="bg-purple-600 hover:bg-purple-700 text-white font-semibold px-2.5 py-1 rounded-lg text-[11px] transition flex items-center gap-1 cursor-pointer"
                          >
                            <Truck className="w-3 h-3" /> Saiu p/ Entrega
                          </button>
                        )}
                        {(ped.status === 'em_preparo' || ped.status === 'saiu_entrega') && (
                          <button
                            type="button"
                            onClick={() => handleAtualizarStatusPedido(ped.id, 'finalizado')}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-2.5 py-1 rounded-lg text-[11px] transition flex items-center gap-1 cursor-pointer"
                          >
                            <PackageCheck className="w-3 h-3" /> Finalizar
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'cardapio' && <MenuManagement loja={loja} />}
      {activeTab === 'pdv' && (
        <PosExpressOrder loja={loja} onOrderCreated={() => carregarLoja(loja.id)} />
      )}
      {activeTab === 'impressora' && (
        <PrinterSettings loja={loja} onUpdate={() => carregarLoja(loja.id)} />
      )}
      {activeTab === 'frete' && (
        <DeliveryCalculatorSettings loja={loja} onUpdate={() => carregarLoja(loja.id)} />
      )}
      {activeTab === 'pagamentos' && (
        <PaymentGatewaySettings loja={loja} onUpdate={() => carregarLoja(loja.id)} />
      )}
      {activeTab === 'identidade' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-6">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
            <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Store className="w-5 h-5 text-red-600" />
              <span>Identidade Visual & Logomarca da Loja</span>
            </h2>
          </div>
          <StoreLogoUploader
            nomeLoja={loja.nome_loja}
            logoUrl={loja.logo_url}
            onChange={(novaLogo) => {
              AppStorage.updateLoja(loja.id, { logo_url: novaLogo });
              setLoja({ ...loja, logo_url: novaLogo });
            }}
          />
        </div>
      )}
      {activeTab === 'pwa' && (
        <PwaStorePreview loja={loja} onNavigateToPublicStore={onNavigateToPublicStore} />
      )}
    </div>
  );
}

import { useState } from 'react';
import { Lock, Mail, ArrowRight, ArrowLeft, ShieldAlert, Store, Loader2 } from 'lucide-react';
import { Loja } from '../../types';
import { AppStorage } from '../../lib/storage';
import { DataService } from '../../lib/supabase';
import StoreLogoAvatar from '../Common/StoreLogoAvatar';
import SuperAdminLoginModal from '../SuperAdmin/SuperAdminLoginModal';
import StoreShowcaseSection from '../CustomerStore/StoreShowcaseSection';

interface MerchantLoginViewProps {
  loja: Loja;
  onLoginSuccess: (lojaLogada?: Loja) => void;
  onNavigateToSignup: () => void;
  onNavigateToSuperAdmin?: () => void;
  onNavigateTermos?: () => void;
}

export default function MerchantLoginView({
  loja,
  onLoginSuccess,
  onNavigateToSignup,
  onNavigateToSuperAdmin,
  onNavigateTermos,
}: MerchantLoginViewProps) {
  const [identificador, setIdentificador] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');
  const [carregando, setCarregando] = useState(false);
  const [modalSuperAdminAberto, setModalSuperAdminAberto] = useState(false);
  const [branding] = useState(() => AppStorage.getSaasBranding());

  const nomeLojaOriginal = (loja.nome_loja || loja.nome || '').trim();
  const isNomeNumericoOuTeste = /^\d+$/.test(nomeLojaOriginal) || !nomeLojaOriginal;
  const nomeExibicao = isNomeNumericoOuTeste ? 'Armonix Store' : nomeLojaOriginal;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErro('');
    const cleanId = identificador.trim().toLowerCase();
    const cleanPass = senha.trim();

    if (!cleanId || !cleanPass) {
      setErro('Por favor, informe seu e-mail ou WhatsApp e senha de acesso.');
      return;
    }

    setCarregando(true);
    try {
      const res = await DataService.authenticateMerchant(cleanId, cleanPass, loja.id);
      if (res.success) {
        onLoginSuccess(res.loja);
      } else {
        setErro(res.erro || 'E-mail, telefone ou senha incorretos.');
      }
    } catch (err: any) {
      setErro(err.message || 'Erro ao realizar login.');
    } finally {
      setCarregando(false);
    }
  }

  return (
    <div className="min-h-[85vh] flex flex-col justify-center items-center p-4">
      <div className="max-w-md w-full space-y-6">
        <div className="text-center space-y-3">
          <div className="flex justify-center">
            {loja.logo_url && loja.logo_url.trim() !== '' ? (
              <StoreLogoAvatar
                nomeLoja={nomeExibicao}
                logoUrl={loja.logo_url}
                size="xl"
                className="shadow-lg ring-4 ring-white dark:ring-slate-800"
              />
            ) : (
              <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-red-600 via-rose-600 to-amber-600 flex items-center justify-center text-white shadow-xl ring-4 ring-white dark:ring-slate-800">
                <Store className="w-10 h-10" />
              </div>
            )}
          </div>
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-[11px] font-bold uppercase tracking-wider mb-2 shadow-xs">
              {branding.logo_url ? (
                <img
                  src={branding.logo_url}
                  alt="ARMONIX STORE"
                  className="w-4 h-4 rounded-md object-contain"
                />
              ) : (
                <Store className="w-3.5 h-3.5 text-red-600" />
              )}
              <span>{branding.nome_marca || 'ARMONIX STORE'}</span>
            </div>
            <h1 className="text-2xl font-black tracking-tight text-slate-900 dark:text-white">
              Painel do Lojista
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto leading-relaxed">
              Acesse sua conta em qualquer dispositivo (Celular, Computador ou Tablet) com seu <strong>E-mail</strong> ou <strong>WhatsApp</strong> cadastrado.
            </p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-5">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800 text-xs font-bold text-slate-600 dark:text-slate-300">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-red-600" />
              <span>Entrar no Painel</span>
            </div>
            <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800">
              Acesso em Qualquer Aparelho
            </span>
          </div>
          {erro && (
            <div className="p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/50 text-red-600 dark:text-red-400 text-xs rounded-xl flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span className="font-semibold">{erro}</span>
            </div>
          )}
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                E-mail ou WhatsApp do Lojista
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  placeholder="Ex: contato@sualoja.com ou 11999999999"
                  value={identificador}
                  onChange={(e) => setIdentificador(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl p-3 pr-9 text-slate-900 dark:text-white focus:outline-none focus:border-red-500"
                />
                <Mail className="w-4 h-4 text-slate-400 absolute right-3 top-3.5" />
              </div>
            </div>
            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                Senha de Acesso
              </label>
              <div className="relative">
                <input
                  type="password"
                  required
                  placeholder="Sua senha cadastrada"
                  value={senha}
                  onChange={(e) => setSenha(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-xl p-3 pr-9 text-slate-900 dark:text-white focus:outline-none focus:border-red-500"
                />
                <Lock className="w-4 h-4 text-slate-400 absolute right-3 top-3.5" />
              </div>
            </div>
            <button
              type="submit"
              disabled={carregando}
              className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3.5 rounded-xl transition shadow-md flex items-center justify-center gap-2 text-xs disabled:opacity-50 cursor-pointer"
            >
              {carregando ? 'Verificando...' : 'Acessar Painel do Lojista'}
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs border-t border-slate-100 dark:border-slate-800">
            <span className="text-[11px] text-slate-400 dark:text-slate-500">
              Não tem uma conta ainda?
            </span>
            <button
              type="button"
              onClick={onNavigateToSignup}
              className="text-red-600 dark:text-red-400 font-bold hover:underline cursor-pointer"
            >
              Cadastrar Nova Loja Grátis
            </button>
          </div>
        </div>

        <div className="text-center pt-2 space-y-2">
          {onNavigateToSuperAdmin && (
            <div>
              <button
                type="button"
                onClick={() => setModalSuperAdminAberto(true)}
                className="text-[11px] text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition cursor-pointer"
              >
                Acesso Proprietário do SaaS (Super Admin)
              </button>
            </div>
          )}
          {onNavigateTermos && (
            <div>
              <button
                type="button"
                onClick={onNavigateTermos}
                className="text-[11px] text-slate-500 hover:text-slate-700 dark:hover:text-slate-400 underline transition cursor-pointer"
              >
                Termos de Uso e Política de Privacidade
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Demonstração de Lojas Prontas (Conveniência, Pet Shop, Lanchonetes, Manicures, Cosméticos e Variedades) */}
      <div className="w-full max-w-6xl mt-10">
        <StoreShowcaseSection onNavigateToSignup={onNavigateToSignup} />
      </div>

      <SuperAdminLoginModal
        isOpen={modalSuperAdminAberto}
        onClose={() => setModalSuperAdminAberto(false)}
        onNavigateTermos={onNavigateTermos}
        onSuccess={() => {
          setModalSuperAdminAberto(false);
          if (onNavigateToSuperAdmin) {
            onNavigateToSuperAdmin();
          }
        }}
      />
    </div>
  );
}

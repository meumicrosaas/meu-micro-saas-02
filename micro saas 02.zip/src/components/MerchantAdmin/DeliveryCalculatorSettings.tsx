import { useState, useEffect } from 'react';
import { Loja, TaxaBairro } from '../../types';
import { AppStorage } from '../../lib/storage';
import {
  calcularDistanciaHaversine,
  calcularTaxaEntrega,
  buscarCoordenadasEndereco,
  LOCAIS_TESTE,
  Coordinates,
} from '../../lib/haversine';
import {
  MapPin,
  Navigation,
  Calculator,
  Check,
  Compass,
  Plus,
  Trash2,
  Search,
  Sparkles,
  Building2,
  DollarSign,
} from 'lucide-react';

interface DeliveryCalculatorSettingsProps {
  loja: Loja;
  onUpdate: () => void;
}

export default function DeliveryCalculatorSettings({
  loja,
  onUpdate,
}: DeliveryCalculatorSettingsProps) {
  const [taxaBase, setTaxaBase] = useState(
    loja.taxa_base_entrega !== undefined ? loja.taxa_base_entrega.toString() : '5.00'
  );
  const [valorPorKm, setValorPorKm] = useState(
    loja.valor_por_km !== undefined ? loja.valor_por_km.toString() : '1.50'
  );
  const [cidade, setCidade] = useState(loja.cidade || 'Campo Grande, MS');
  const [enderecoTexto, setEnderecoTexto] = useState(
    loja.endereco_origem?.endereco_texto || 'Av. Afonso Pena, 1500 - Centro'
  );
  const [lat, setLat] = useState(
    loja.endereco_origem?.lat !== undefined ? loja.endereco_origem.lat.toString() : '-20.4697'
  );
  const [lng, setLng] = useState(
    loja.endereco_origem?.lng !== undefined ? loja.endereco_origem.lng.toString() : '-54.6201'
  );
  const [buscandoCoords, setBuscandoCoords] = useState(false);
  const [coordMsg, setCoordMsg] = useState<string | null>(null);

  const [taxasBairros, setTaxasBairros] = useState<TaxaBairro[]>(
    loja.taxas_bairros || [
      { id: 'b-1', bairro: 'Centro', taxa: 5.0 },
      { id: 'b-2', bairro: 'Jardim dos Estados', taxa: 7.0 },
      { id: 'b-3', bairro: 'Chácara Cachoeira', taxa: 8.5 },
      { id: 'b-4', bairro: 'Tiradentes', taxa: 10.0 },
    ]
  );
  const [novoBairroNome, setNovoBairroNome] = useState('');
  const [novoBairroTaxa, setNovoBairroTaxa] = useState('');
  const [salvo, setSalvo] = useState(false);

  const [modoSimulador, setModoSimulador] = useState<'km' | 'bairro'>('km');
  const [simLocal, setSimLocal] = useState<string>('bairro_medio');
  const [simLat, setSimLat] = useState(LOCAIS_TESTE.bairro_medio?.lat.toString() || '-20.4850');
  const [simLng, setSimLng] = useState(LOCAIS_TESTE.bairro_medio?.lng.toString() || '-54.6400');
  const [simBairroId, setSimBairroId] = useState<string>(
    taxasBairros[0]?.id || ''
  );

  useEffect(() => {
    setTaxaBase(loja.taxa_base_entrega !== undefined ? loja.taxa_base_entrega.toString() : '5.00');
    setValorPorKm(loja.valor_por_km !== undefined ? loja.valor_por_km.toString() : '1.50');
    setCidade(loja.cidade || 'Campo Grande, MS');
    setEnderecoTexto(loja.endereco_origem?.endereco_texto || 'Av. Afonso Pena, 1500 - Centro');
    setLat(loja.endereco_origem?.lat !== undefined ? loja.endereco_origem.lat.toString() : '-20.4697');
    setLng(loja.endereco_origem?.lng !== undefined ? loja.endereco_origem.lng.toString() : '-54.6201');
    if (loja.taxas_bairros) setTaxasBairros(loja.taxas_bairros);
  }, [loja.id]);

  async function handleBuscarCoordenadasAuto() {
    if (!enderecoTexto.trim() && !cidade.trim()) {
      setCoordMsg('⚠️ Informe o endereço e cidade da loja para localizar as coordenadas.');
      setTimeout(() => setCoordMsg(null), 4000);
      return;
    }
    setBuscandoCoords(true);
    setCoordMsg(null);
    try {
      const coords = await buscarCoordenadasEndereco(enderecoTexto, cidade);
      if (coords) {
        setLat(coords.lat.toString());
        setLng(coords.lng.toString());
        setCoordMsg(`✅ Coordenadas atualizadas para ${cidade}: ${coords.lat.toFixed(4)}, ${coords.lng.toFixed(4)}`);
        setTimeout(() => setCoordMsg(null), 4000);
      }
    } catch {
      setCoordMsg('Não foi possível geolocalizar online, mantendo coordenadas padrão.');
      setTimeout(() => setCoordMsg(null), 4000);
    } finally {
      setBuscandoCoords(false);
    }
  }

  function handleAdicionarBairro(e: React.FormEvent) {
    e.preventDefault();
    if (!novoBairroNome.trim()) return;
    const taxaNum = parseFloat(novoBairroTaxa);
    if (isNaN(taxaNum) || taxaNum < 0) {
      setCoordMsg('⚠️ Informe um valor de taxa válido em R$');
      setTimeout(() => setCoordMsg(null), 3000);
      return;
    }
    const novoItem: TaxaBairro = {
      id: `bairro-${Date.now()}-${Math.random().toString().slice(-4)}`,
      bairro: novoBairroNome.trim(),
      taxa: Math.round(taxaNum * 100) / 100,
    };
    const atualizados = [...taxasBairros, novoItem];
    setTaxasBairros(atualizados);
    setNovoBairroNome('');
    setNovoBairroTaxa('');
    if (!simBairroId) setSimBairroId(novoItem.id);
  }

  function handleRemoverBairro(id: string) {
    const filtrados = taxasBairros.filter((b) => b.id !== id);
    setTaxasBairros(filtrados);
    if (simBairroId === id && filtrados.length > 0) {
      setSimBairroId(filtrados[0].id);
    }
  }

  function handleSalvar(e: React.FormEvent) {
    e.preventDefault();
    const latNum = parseFloat(lat) || -20.4697;
    const lngNum = parseFloat(lng) || -54.6201;
    const baseNum = parseFloat(taxaBase) >= 0 ? parseFloat(taxaBase) : 5.0;
    const kmNum = parseFloat(valorPorKm) >= 0 ? parseFloat(valorPorKm) : 1.5;

    AppStorage.updateLoja(loja.id, {
      taxa_base_entrega: baseNum,
      valor_por_km: kmNum,
      cidade: cidade.trim() || 'Campo Grande, MS',
      endereco_origem: {
        lat: latNum,
        lng: lngNum,
        endereco_texto: enderecoTexto.trim(),
      },
      taxas_bairros: taxasBairros,
    });
    setSalvo(true);
    setTimeout(() => setSalvo(false), 3500);
    onUpdate();
  }

  const origemCoord: Coordinates = {
    lat: parseFloat(lat) || -20.4697,
    lng: parseFloat(lng) || -54.6201,
  };
  const destinoCoord: Coordinates = {
    lat: parseFloat(simLat) || -20.485,
    lng: parseFloat(simLng) || -54.64,
  };
  const distanciaCalculada = calcularDistanciaHaversine(origemCoord, destinoCoord);
  const taxaCalculadaKm = calcularTaxaEntrega(
    distanciaCalculada,
    parseFloat(taxaBase) || 5.0,
    parseFloat(valorPorKm) || 1.5
  );
  const bairroSimulado = taxasBairros.find((b) => b.id === simBairroId);

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
        <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 text-[11px] font-bold uppercase tracking-wider mb-2">
            <Navigation className="w-3.5 h-3.5" />
            <span>Módulo de Logística & Entregas</span>
          </div>
          <h2 className="text-xl font-black text-slate-900 dark:text-white">
            Configuração de Frete, Coordenadas e Bairros
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Configure o endereço de partida da sua loja, defina a taxa base com valor por KM rodado e cadastre taxas fixas por bairro.
          </p>
        </div>

        <form onSubmit={handleSalvar} className="space-y-6 text-xs">
          <div className="bg-slate-50 dark:bg-slate-950/60 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                <MapPin className="w-4 h-4 text-red-600 shrink-0" />
                <span>Endereço e Coordenadas da Loja (Origem)</span>
              </h3>
              <button
                type="button"
                onClick={handleBuscarCoordenadasAuto}
                disabled={buscandoCoords}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-700 disabled:bg-slate-400 text-white font-bold text-[11px] rounded-xl transition cursor-pointer shadow-xs"
              >
                {buscandoCoords ? (
                  <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Search className="w-3.5 h-3.5" />
                )}
                <span>Buscar Coordenadas Auto</span>
              </button>
            </div>
            {coordMsg && (
              <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs rounded-xl font-medium">
                {coordMsg}
              </div>
            )}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-2">
                <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Endereço da Loja *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Av. Afonso Pena, 1500 - Centro"
                  value={enderecoTexto}
                  onChange={(e) => setEnderecoTexto(e.target.value)}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Cidade e UF *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Campo Grande, MS"
                  value={cidade}
                  onChange={(e) => setCidade(e.target.value)}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Latitude
                </label>
                <input
                  type="text"
                  value={lat}
                  onChange={(e) => setLat(e.target.value)}
                  placeholder="-20.4697"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white font-mono"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Longitude
                </label>
                <input
                  type="text"
                  value={lng}
                  onChange={(e) => setLng(e.target.value)}
                  placeholder="-54.6201"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white font-mono"
                />
              </div>
            </div>
          </div>

          <div className="bg-slate-50 dark:bg-slate-950/60 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 space-y-4">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Taxas de Cálculo por Quilômetro</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Taxa Base de Saída (R$) *
                </label>
                <input
                  type="number"
                  step="0.50"
                  min="0"
                  required
                  value={taxaBase}
                  onChange={(e) => setTaxaBase(e.target.value)}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white font-mono text-sm"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Valor Adicional por KM Rodado (R$) *
                </label>
                <input
                  type="number"
                  step="0.10"
                  min="0"
                  required
                  value={valorPorKm}
                  onChange={(e) => setValorPorKm(e.target.value)}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white font-mono text-sm"
                />
              </div>
            </div>
          </div>

          <div className="bg-slate-50 dark:bg-slate-950/60 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 space-y-4">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
              <Building2 className="w-4 h-4 text-purple-600 shrink-0" />
              <span>Taxas Fixas por Bairro ({taxasBairros.length})</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
              <div className="sm:col-span-6">
                <input
                  type="text"
                  placeholder="Nome do Bairro"
                  value={novoBairroNome}
                  onChange={(e) => setNovoBairroNome(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg p-2 text-xs text-slate-900 dark:text-white"
                />
              </div>
              <div className="sm:col-span-3">
                <input
                  type="number"
                  step="0.50"
                  min="0"
                  placeholder="Taxa em R$"
                  value={novoBairroTaxa}
                  onChange={(e) => setNovoBairroTaxa(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg p-2 text-xs text-slate-900 dark:text-white font-mono"
                />
              </div>
              <div className="sm:col-span-3">
                <button
                  type="button"
                  onClick={handleAdicionarBairro}
                  className="w-full h-full py-2 px-3 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Adicionar</span>
                </button>
              </div>
            </div>

            <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
              {taxasBairros.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl"
                >
                  <span className="font-bold text-slate-900 dark:text-white text-xs">
                    {item.bairro}
                  </span>
                  <div className="flex items-center gap-3">
                    <span className="font-extrabold text-emerald-600 dark:text-emerald-400 font-mono text-xs">
                      R$ {item.taxa.toFixed(2)}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleRemoverBairro(item.id)}
                      className="text-slate-400 hover:text-red-600 p-1 cursor-pointer"
                      title="Remover Bairro"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <div>
              {salvo && (
                <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1.5 text-xs">
                  <Check className="w-4 h-4" /> Configurações salvas com sucesso!
                </span>
              )}
            </div>
            <button
              type="submit"
              className="bg-red-600 hover:bg-red-700 text-white font-extrabold px-6 py-2.5 rounded-xl transition text-xs shadow-md cursor-pointer active:scale-95 flex items-center gap-2"
            >
              <Check className="w-4 h-4" />
              <span>Salvar Parâmetros de Frete</span>
            </button>
          </div>
        </form>
      </div>

      <div className="bg-slate-900 text-white p-6 rounded-3xl border border-slate-800 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-red-600/20 text-red-400 rounded-xl">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm">Simulador de Frete ao Vivo</h4>
              <p className="text-xs text-slate-400">
                Teste em tempo real como o valor será calculado no checkout.
              </p>
            </div>
          </div>
          <div className="flex items-center bg-slate-800 p-1 rounded-xl text-xs font-bold">
            <button
              type="button"
              onClick={() => setModoSimulador('km')}
              className={`px-3 py-1 rounded-lg transition cursor-pointer ${
                modoSimulador === 'km' ? 'bg-red-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Por KM (Haversine)
            </button>
            <button
              type="button"
              onClick={() => setModoSimulador('bairro')}
              className={`px-3 py-1 rounded-lg transition cursor-pointer ${
                modoSimulador === 'bairro' ? 'bg-red-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Por Bairro
            </button>
          </div>
        </div>

        {modoSimulador === 'km' ? (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Local de Teste</label>
                <select
                  value={simLocal}
                  onChange={(e) => {
                    const k = e.target.value;
                    setSimLocal(k);
                    if (LOCAIS_TESTE[k]) {
                      setSimLat(LOCAIS_TESTE[k].lat.toString());
                      setSimLng(LOCAIS_TESTE[k].lng.toString());
                    }
                  }}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white"
                >
                  {Object.entries(LOCAIS_TESTE).map(([key, item]) => (
                    <option key={key} value={key}>
                      {item.nome}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex justify-between items-center">
              <div>
                <p className="text-xs text-slate-400">Distância Calculada:</p>
                <p className="text-xl font-extrabold text-white">{distanciaCalculada} km</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-slate-400">Taxa de Entrega:</p>
                <p className="text-2xl font-black text-emerald-400">R$ {taxaCalculadaKm.toFixed(2)}</p>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex justify-between items-center">
              <p className="text-lg font-extrabold text-white">
                {bairroSimulado ? bairroSimulado.bairro : 'Nenhum bairro selecionado'}
              </p>
              <p className="text-2xl font-black text-purple-400">
                R$ {bairroSimulado ? bairroSimulado.taxa.toFixed(2) : '0.00'}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

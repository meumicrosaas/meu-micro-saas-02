import { useState } from 'react';
import {
  Smartphone,
  ExternalLink,
  Copy,
  Check,
  Zap,
  Download,
  Share2,
  CheckCircle2,
} from 'lucide-react';
import { Loja } from '../../types';
import StoreLogoAvatar from '../Common/StoreLogoAvatar';

interface PwaStorePreviewProps {
  loja: Loja;
  onNavigateToPublicStore?: (slug: string) => void;
}

export default function PwaStorePreview({ loja, onNavigateToPublicStore }: PwaStorePreviewProps) {
  const [copiado, setCopiado] = useState(false);
  const urlLoja =
    typeof window !== 'undefined'
      ? `${window.location.origin}/loja/${loja.slug}`
      : `https://armonix.store/loja/${loja.slug}`;

  function handleCopiarLink() {
    navigator.clipboard.writeText(urlLoja);
    setCopiado(true);
    setTimeout(() => setCopiado(false), 3000);
  }

  const shortName =
    loja.nome_loja.length > 12 ? loja.nome_loja.slice(0, 11) + '…' : loja.nome_loja;

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xs space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-red-600/10 text-red-600 dark:bg-red-500/20 dark:text-red-400">
              <Smartphone className="w-5 h-5" />
            </span>
            <h3 className="text-lg font-black text-slate-900 dark:text-white">
              Aplicativo Mobile PWA da sua Loja
            </h3>
            <span className="bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-[10px] font-extrabold px-2.5 py-0.5 rounded-full border border-emerald-500/30 uppercase tracking-wider">
              Ativo & Instalável
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-2xl">
            Seus clientes podem instalar o cardápio da sua loja diretamente no celular como um
            aplicativo oficial, com ícone na tela inicial e sem precisar de Play Store ou App Store.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleCopiarLink}
            className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
          >
            {copiado ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
            <span>{copiado ? 'Link Copiado!' : 'Copiar Link do App'}</span>
          </button>
          <a
            href={`/loja/${loja.slug}`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-sm cursor-pointer"
            title="Abrir cardápio público ao vivo em nova guia"
          >
            <ExternalLink className="w-4 h-4" />
            <span>Ver Cardápio ao Vivo</span>
          </a>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <div className="lg:col-span-6 flex flex-col items-center">
          <div className="w-[300px] sm:w-[320px] bg-slate-950 rounded-[44px] p-3.5 shadow-2xl border-4 border-slate-800 ring-1 ring-white/10 relative">
            <div className="w-24 h-4 bg-slate-900 rounded-full mx-auto mb-3 flex items-center justify-center">
              <div className="w-3 h-3 rounded-full bg-slate-950/80 mr-2" />
              <div className="w-2 h-2 rounded-full bg-blue-900/60" />
            </div>
            <div className="bg-slate-900 rounded-[32px] overflow-hidden border border-slate-800/80 flex flex-col h-[480px] select-none text-left">
              <div className="p-4 bg-gradient-to-b from-slate-900 to-slate-950 border-b border-slate-800">
                <span className="text-[10px] font-bold text-slate-400 block mb-2 uppercase">
                  Ícone na Tela Inicial do Celular:
                </span>
                <div className="flex items-center gap-3 bg-slate-950/80 p-3 rounded-2xl border border-slate-800">
                  <StoreLogoAvatar
                    nomeLoja={loja.nome_loja}
                    logoUrl={loja.logo_url}
                    size="md"
                    className="rounded-2xl shadow-md ring-2 ring-red-500/40"
                  />
                  <div className="min-w-0">
                    <p className="text-xs font-extrabold text-white truncate">{shortName}</p>
                    <p className="text-[10px] text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Aplicativo Pronto
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex-1 bg-gray-50 dark:bg-slate-950 p-3 space-y-2 overflow-y-auto">
                <div className="bg-gradient-to-r from-red-600 to-amber-600 text-white p-2 rounded-xl text-[10px] shadow-sm flex items-center justify-between gap-1">
                  <div className="flex items-center gap-1.5 truncate">
                    <Download className="w-3.5 h-3.5 shrink-0" />
                    <span className="font-bold truncate">Instale o App da {shortName}</span>
                  </div>
                  <span className="bg-white text-red-600 px-2 py-0.5 rounded-lg font-black text-[9px] shrink-0">
                    Instalar
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-6 space-y-4">
          <div className="bg-slate-50 dark:bg-slate-950 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
            <h4 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-500" />
              <span>Vantagens do PWA da sua loja</span>
            </h4>
            <ul className="text-xs text-slate-600 dark:text-slate-400 space-y-2.5">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <span>
                  <strong>Sem taxas da Apple ou Google:</strong> Sem 30% de comissão nem taxas anuais de desenvolvedor.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <span>
                  <strong>Instalação imediata:</strong> O cliente clica em &quot;Instalar&quot; e o ícone surge na tela inicial.
                </span>
              </li>
            </ul>
          </div>
          <div className="bg-gradient-to-br from-red-600/5 via-slate-50 to-amber-500/5 dark:from-red-950/20 dark:via-slate-900 dark:to-amber-950/20 p-5 rounded-2xl border border-red-500/20 space-y-3">
            <h4 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Share2 className="w-4 h-4 text-red-500" />
              <span>Link Direto do Cardápio</span>
            </h4>
            <div className="bg-white dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-mono text-slate-700 dark:text-slate-300">
              {urlLoja}
            </div>
            <button
              type="button"
              onClick={handleCopiarLink}
              className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <Copy className="w-4 h-4" />
              <span>{copiado ? 'Copiado!' : 'Copiar Link'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

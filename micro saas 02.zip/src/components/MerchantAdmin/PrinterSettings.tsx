import { useState, useEffect } from 'react';
import { Printer, Check, Zap, FileText } from 'lucide-react';
import { Loja, PrinterWidth, PrinterFontSize } from '../../types';
import { AppStorage } from '../../lib/storage';
import { DataService } from '../../lib/supabase';

interface PrinterSettingsProps {
  loja: Loja;
  onUpdate?: () => void;
}

export default function PrinterSettings({ loja, onUpdate }: PrinterSettingsProps) {
  const [largura, setLargura] = useState<PrinterWidth>(loja.impressora_largura || '80mm');
  const [fonte, setFonte] = useState<PrinterFontSize>(loja.impressora_fonte || 'normal');
  const [vias, setVias] = useState<number>(loja.impressora_vias || 1);
  const [autoImprimir, setAutoImprimir] = useState<boolean>(
    Boolean(loja.impressora_auto_imprimir)
  );
  const [salvo, setSalvo] = useState(false);

  useEffect(() => {
    setLargura(loja.impressora_largura || '80mm');
    setFonte(loja.impressora_fonte || 'normal');
    setVias(loja.impressora_vias || 1);
    setAutoImprimir(Boolean(loja.impressora_auto_imprimir));
  }, [loja]);

  async function handleSalvar(e: React.FormEvent) {
    e.preventDefault();
    const config = {
      largura,
      fonte,
      vias,
      autoImprimir,
    };
    AppStorage.updateLojaPrinterConfig(loja.id, config);
    await DataService.updateLojaPrinterConfig(loja.id, config);
    setSalvo(true);
    if (onUpdate) onUpdate();
    setTimeout(() => setSalvo(false), 3000);
  }

  const [printMsg, setPrintMsg] = useState<string | null>(null);

  function handleTestarImpressao() {
    try {
      window.print();
    } catch {
      setPrintMsg('Seu navegador bloqueou a janela de impressão direta.');
      setTimeout(() => setPrintMsg(null), 4000);
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-2xl shadow-xs">
        <div className="flex items-center gap-2 mb-2">
          <Printer className="w-5 h-5 text-red-600" />
          <h2 className="text-lg font-black text-slate-900 dark:text-white">
            Configurações da Impressora Térmica
          </h2>
        </div>
        <p className="text-xs text-slate-500">
          Defina o padrão de impressão para bobinas térmicas de comanda, vias e disparo automático.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <form
          onSubmit={handleSalvar}
          className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-2xl shadow-xs space-y-5"
        >
          {salvo && (
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 rounded-xl text-xs font-bold flex items-center gap-2">
              <Check className="w-4 h-4" />
              Configurações salvas com sucesso!
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-2">
              1. Largura da Bobina / Papel Térmico
            </label>
            <div className="grid grid-cols-2 gap-3">
              {[
                { id: '80mm', title: 'Bobina Padrão 80mm', desc: 'Impressoras Epson, Bematech, Elgin' },
                { id: '58mm', title: 'Bobina Compacta 58mm', desc: 'Mini impressoras Bluetooth, POS e maquininhas' },
              ].map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setLargura(item.id as PrinterWidth)}
                  className={`p-3.5 rounded-xl border text-left transition cursor-pointer ${
                    largura === item.id
                      ? 'border-red-600 bg-red-50/60 dark:bg-red-950/20 text-red-950 dark:text-red-200 font-bold'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <span className="text-xs font-black block">{item.title}</span>
                  <p className="text-[10px] text-slate-500 mt-1 leading-snug">{item.desc}</p>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-2">
              2. Tamanho da Fonte da Comanda
            </label>
            <div className="grid grid-cols-3 gap-3">
              {[
                { id: 'pequena', title: 'Pequena (10px)', desc: 'Mais itens por linha' },
                { id: 'normal', title: 'Normal (12px)', desc: 'Padrão legível' },
                { id: 'grande', title: 'Grande (14px)', desc: 'Alta visibilidade' },
              ].map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setFonte(f.id as PrinterFontSize)}
                  className={`p-3 rounded-xl border text-center transition cursor-pointer ${
                    fonte === f.id
                      ? 'border-red-600 bg-red-50/60 dark:bg-red-950/20 text-red-900 dark:text-red-200 font-bold'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <span className="text-xs font-black block">{f.title}</span>
                  <span className="text-[10px] text-slate-500">{f.desc}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-2">
              3. Quantidade de Vias
            </label>
            <div className="grid grid-cols-3 gap-3">
              {[
                { qtd: 1, label: '1 Via', desc: '1x Cozinha' },
                { qtd: 2, label: '2 Vias', desc: '1x Cozinha + 1x Entrega' },
                { qtd: 3, label: '3 Vias', desc: '1x Cozinha + 1x Entrega + 1x Caixa' },
              ].map((v) => (
                <button
                  key={v.qtd}
                  type="button"
                  onClick={() => setVias(v.qtd)}
                  className={`p-3 rounded-xl border text-center transition cursor-pointer ${
                    vias === v.qtd
                      ? 'border-red-600 bg-red-50/60 dark:bg-red-950/20 text-red-900 dark:text-red-200 font-bold'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <span className="text-xs font-black block">{v.label}</span>
                  <span className="text-[10px] text-slate-500">{v.desc}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-start gap-3">
            <input
              type="checkbox"
              id="autoPrint"
              checked={autoImprimir}
              onChange={(e) => setAutoImprimir(e.target.checked)}
              className="mt-1 w-4 h-4 text-red-600 rounded focus:ring-0 cursor-pointer"
            />
            <label htmlFor="autoPrint" className="cursor-pointer space-y-0.5">
              <span className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-500" />
                Impressão Automática ao Aceitar Pedido
              </span>
              <p className="text-[11px] text-slate-500">
                Abre o diálogo de impressão instantaneamente ao clicar em &quot;Aceitar Pedido&quot;.
              </p>
            </label>
          </div>

          {printMsg && (
            <div className="p-3 bg-amber-500/10 border border-amber-500/30 text-amber-600 rounded-xl text-xs font-semibold">
              {printMsg}
            </div>
          )}

          <div className="flex justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={handleTestarImpressao}
              className="px-4 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold hover:bg-slate-200 cursor-pointer"
            >
              Testar Impressão Agora
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold shadow-xs transition cursor-pointer"
            >
              Salvar Configurações
            </button>
          </div>
        </form>

        <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex flex-col items-center">
          <span className="text-xs font-bold text-slate-400 mb-3 flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-red-500" />
            Visualização da Bobina ({largura})
          </span>
          <div
            className={`bg-white text-black p-3 font-mono shadow-2xl rounded-sm transition-all border border-gray-300 ${
              largura === '58mm' ? 'w-[210px]' : 'w-[280px]'
            } ${
              fonte === 'pequena'
                ? 'text-[10px] leading-tight'
                : fonte === 'grande'
                ? 'text-[13px] leading-normal'
                : 'text-[11px] leading-snug'
            }`}
          >
            <div className="text-center border-b border-dashed border-gray-400 pb-2 mb-2">
              <p className="font-black uppercase text-xs">{loja.nome_loja}</p>
              <p className="text-[9px]">TEL: {loja.telefone_whatsapp}</p>
              <div className="mt-1 bg-black text-white font-bold py-0.5 text-[10px]">
                1ª VIA - COZINHA ({vias} {vias > 1 ? 'VIAS' : 'VIA'})
              </div>
            </div>
            <div className="border-b border-dashed border-gray-400 pb-2 mb-2">
              <p className="font-black">PEDIDO: #4821</p>
              <p className="font-bold">CLIENTE: Exemplo de Cliente</p>
            </div>
            <div className="text-center text-[9px] text-gray-500 pt-1">
              {autoImprimir ? '⚡ Impressão Automática Ativa' : 'Disparo Manual'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

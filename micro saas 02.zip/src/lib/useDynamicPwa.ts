import { useEffect } from 'react';
import { Loja } from '../types';

export function useDynamicPwa(loja: Loja | null) {
  useEffect(() => {
    // 1. Registra o Service Worker caso suportado
    if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
      navigator.serviceWorker
        .register('/sw.js')
        .then(() => {
          // Service worker registrado
        })
        .catch((err) => {
          console.debug('[PWA] Service Worker registration skipped or failed:', err);
        });
    }

    if (!loja) return;

    // 2. Atualiza a tag <title> do documento com o nome do estabelecimento
    const originalTitle = document.title;
    document.title = `${loja.nome_loja} | Cardápio Digital & Delivery`;

    // 3. Atualiza meta theme-color
    let themeMeta = document.querySelector('meta[name="theme-color"]');
    if (!themeMeta) {
      themeMeta = document.createElement('meta');
      themeMeta.setAttribute('name', 'theme-color');
      document.head.appendChild(themeMeta);
    }
    const storeThemeColor = loja.cor_primaria || '#DC2626';
    themeMeta.setAttribute('content', storeThemeColor);

    // 4. Cria manifesto dinâmico com Nome da Loja, Nome Curto e Logotipo do Lojista
    const storeIcon =
      loja.logo_url ||
      '/armonix-logo.png';

    const dynamicManifest = {
      name: loja.nome_loja,
      short_name: loja.nome_loja.length > 12 ? loja.nome_loja.slice(0, 12) : loja.nome_loja,
      description: `Peça online no cardápio de ${loja.nome_loja} com entrega rápida e pagamento fácil via PIX.`,
      start_url: `/loja/${loja.slug}`,
      scope: `/loja/${loja.slug}`,
      display: 'standalone',
      orientation: 'portrait',
      background_color: '#ffffff',
      theme_color: storeThemeColor,
      icons: [
        {
          src: storeIcon,
          sizes: '192x192',
          type: 'image/png',
          purpose: 'any maskable',
        },
        {
          src: storeIcon,
          sizes: '512x512',
          type: 'image/png',
          purpose: 'any maskable',
        },
      ],
    };

    const manifestBlob = new Blob([JSON.stringify(dynamicManifest, null, 2)], {
      type: 'application/json',
    });
    const manifestBlobUrl = URL.createObjectURL(manifestBlob);

    let manifestLink = document.querySelector<HTMLLinkElement>('link#app-manifest');
    if (!manifestLink) {
      manifestLink = document.querySelector<HTMLLinkElement>('link[rel="manifest"]');
    }
    if (!manifestLink) {
      manifestLink = document.createElement('link');
      manifestLink.id = 'app-manifest';
      manifestLink.rel = 'manifest';
      document.head.appendChild(manifestLink);
    }
    manifestLink.href = manifestBlobUrl;

    // 5. Atualiza apple-touch-icon
    let appleIcon = document.querySelector<HTMLLinkElement>('link[rel="apple-touch-icon"]');
    if (!appleIcon) {
      appleIcon = document.createElement('link');
      appleIcon.rel = 'apple-touch-icon';
      document.head.appendChild(appleIcon);
    }
    appleIcon.href = storeIcon;

    return () => {
      URL.revokeObjectURL(manifestBlobUrl);
      document.title = originalTitle;
    };
  }, [loja?.id, loja?.nome_loja, loja?.slug, loja?.logo_url, loja?.cor_primaria]);
}

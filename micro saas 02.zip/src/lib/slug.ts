/**
 * Utilitário central de geração e sanitização de slugs multi-tenant
 * Garante compatibilidade estrita com URLs e consultas Supabase
 */
export function sanitizeSlug(input: string): string {
  if (!input) return '';
  return input
    .toString()
    .toLowerCase()
    .trim()
    .normalize('NFD') // Decompõe caracteres acentuados
    .replace(/[\u0300-\u036f]/g, '') // Remove diacríticos/acentos
    .replace(/[^a-z0-9\s-]/g, '') // Remove caracteres especiais
    .replace(/[\s_]+/g, '-') // Converte espaços e underscores para hífens
    .replace(/-+/g, '-') // Remove hífens duplicados
    .replace(/^-+|-+$/g, ''); // Remove hífens no início e fim
}

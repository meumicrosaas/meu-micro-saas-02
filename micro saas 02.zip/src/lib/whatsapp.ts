import { Pedido, Loja } from '../types';

export function gerarMensagemWhatsAppPedido(pedido: Pedido, loja: Loja): string {
  const itensTexto = pedido.itens
    .map((item) => {
      let linha = `👉 ${item.quantidade}x *${item.produto_nome}* - R$ ${item.total_item.toFixed(2)}`;
      if (item.opcionais && item.opcionais.length > 0) {
        const ops = item.opcionais.map((o) => `+ ${o.nome_opcao}`).join(', ');
        linha += `\n   _Opcionais: ${ops}_`;
      }
      if (item.observacao) {
        linha += `\n   _Obs: ${item.observacao}_`;
      }
      return linha;
    })
    .join('\n');

  const metodoTextoMap: Record<string, string> = {
    pix_online: 'PIX Online (Confirmado)',
    cartao_online: 'Cartão de Crédito Online',
    dinheiro: `Dinheiro na Entrega ${
      pedido.troco_para ? `(Troco p/ R$ ${pedido.troco_para.toFixed(2)})` : ''
    }`,
    maquininha: 'Cartão (Levar maquininha na entrega)',
  };

  const tipoEntregaTexto =
    pedido.tipo_entrega === 'delivery'
      ? `🛵 *DELIVERY*\n📍 Endereço: ${pedido.endereco_destino || pedido.endereco_completo}\n📏 Distância: ${
          pedido.distancia_km || 0
        } km`
      : `🛍️ *RETIRADA NO BALCÃO*`;

  const mensagem = `🍔 *NOVO PEDIDO ${pedido.codigo_pedido || '#' + pedido.id}*
🏪 *Loja:* ${loja.nome_loja}
------------------------------
👤 *Cliente:* ${pedido.cliente_nome}
📱 *WhatsApp:* ${pedido.cliente_telefone}
${tipoEntregaTexto}

📋 *ITENS:*
${itensTexto}

------------------------------
Subtotal: R$ ${pedido.subtotal.toFixed(2)}
Taxa de Entrega: R$ ${pedido.taxa_entrega.toFixed(2)}
*TOTAL: R$ ${pedido.total.toFixed(2)}*

💳 *Pagamento:* ${metodoTextoMap[pedido.metodo_pagamento] || pedido.metodo_pagamento}
⚡ *Status Pagamento:* ${(pedido.status_pagamento || 'pendente').toUpperCase()}
------------------------------
Pedido realizado via Cardápio Digital!`;

  return encodeURIComponent(mensagem);
}

export function abrirWhatsAppLoja(
  pedidoOuTel: Pedido | string,
  lojaOuTexto?: Loja | string
) {
  if (typeof pedidoOuTel === 'string') {
    const telefoneLimpo = pedidoOuTel.replace(/\D/g, '');
    const texto = typeof lojaOuTexto === 'string' ? encodeURIComponent(lojaOuTexto) : '';
    const ddi = telefoneLimpo.startsWith('55') ? '' : '55';
    const url = `https://wa.me/${ddi}${telefoneLimpo}?text=${texto}`;
    try {
      window.open(url, '_blank');
    } catch {}
  } else if (lojaOuTexto && typeof lojaOuTexto !== 'string') {
    const texto = gerarMensagemWhatsAppPedido(pedidoOuTel, lojaOuTexto);
    const telefoneLimpo = lojaOuTexto.telefone_whatsapp.replace(/\D/g, '');
    const ddi = telefoneLimpo.startsWith('55') ? '' : '55';
    const url = `https://wa.me/${ddi}${telefoneLimpo}?text=${texto}`;
    try {
      window.open(url, '_blank');
    } catch {}
  }
}

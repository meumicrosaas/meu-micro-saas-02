import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  Loja,
  Categoria,
  Produto,
  Cliente,
  Pedido,
  OrderStatus,
  PrinterConfig,
  BannerOfertaConfig,
  SaasPlanSettings,
  SaasAssinatura,
  SaasBranding,
} from '../types';
import { AppStorage } from './storage';
import { sanitizeSlug } from './slug';

// Detecção segura de variáveis de ambiente no Vite e SSR/Node
function getEnvVar(key: string): string {
  try {
    if (typeof import.meta !== 'undefined' && (import.meta as any).env) {
      if ((import.meta as any).env[key]) return String((import.meta as any).env[key]);
    }
  } catch {}
  try {
    if (typeof process !== 'undefined' && process.env) {
      if (process.env[key]) return String(process.env[key]);
    }
  } catch {}
  return '';
}

// Determina credenciais ativas: primeiro de AppStorage (configuradas no Super Admin), depois .env
export function getActiveSupabaseCredentials(): { url: string; anonKey: string; serviceRoleKey?: string; isCustom: boolean } {
  const saved = AppStorage.getSupabaseConfig();
  if (saved.url && saved.anonKey && saved.url.startsWith('http')) {
    return {
      url: saved.url.trim(),
      anonKey: saved.anonKey.trim(),
      serviceRoleKey: saved.serviceRoleKey?.trim(),
      isCustom: true,
    };
  }

  const envUrl =
    getEnvVar('NEXT_PUBLIC_SUPABASE_URL') ||
    getEnvVar('VITE_SUPABASE_URL') ||
    'https://eyaufwzdrjtfzcvtuxyw.supabase.co';
  const envKey =
    getEnvVar('NEXT_PUBLIC_SUPABASE_ANON_KEY') ||
    getEnvVar('VITE_SUPABASE_ANON_KEY') ||
    'sb_publishable_safdydwDCc5Z6KZrXxRUGQ_ui9kB0Vl';
  const envServiceKey =
    getEnvVar('SUPABASE_SERVICE_ROLE_KEY') ||
    getEnvVar('VITE_SUPABASE_SERVICE_ROLE_KEY') ||
    '';

  return {
    url: envUrl.trim(),
    anonKey: envKey.trim(),
    serviceRoleKey: envServiceKey.trim(),
    isCustom: true,
  };
}

let cachedClient: SupabaseClient | null = null;
let currentClientKey = '';

export function getSupabaseClient(): SupabaseClient | null {
  const creds = getActiveSupabaseCredentials();
  const isConfigured = Boolean(
    creds.url &&
    creds.anonKey &&
    creds.url.startsWith('http') &&
    !creds.url.includes('seu-projeto')
  );

  if (!isConfigured) {
    cachedClient = null;
    currentClientKey = '';
    return null;
  }

  const key = `${creds.url}|${creds.anonKey}`;
  if (cachedClient && currentClientKey === key) {
    return cachedClient;
  }

  try {
    cachedClient = createClient(creds.url, creds.anonKey, {
      auth: { persistSession: true, autoRefreshToken: true },
    });
    currentClientKey = key;
    return cachedClient;
  } catch (e) {
    console.warn('Erro ao inicializar cliente Supabase:', e);
    cachedClient = null;
    return null;
  }
}

export const isSupabaseConfigured = Boolean(
  getActiveSupabaseCredentials().url &&
  getActiveSupabaseCredentials().anonKey &&
  getActiveSupabaseCredentials().url.startsWith('http') &&
  !getActiveSupabaseCredentials().url.includes('seu-projeto')
);

export const supabase = getSupabaseClient();

/**
 * Validação e Teste em Tempo Real de Credenciais do Supabase
 */
export async function testSupabaseCredentials(
  urlInput?: string,
  anonKeyInput?: string
): Promise<{
  ok: boolean;
  message: string;
  latencyMs?: number;
  mode: 'supabase' | 'local';
}> {
  const creds = getActiveSupabaseCredentials();
  const url = (urlInput || creds.url || '').trim();
  const anonKey = (anonKeyInput || creds.anonKey || '').trim();

  if (!url || !anonKey || !url.startsWith('http')) {
    return {
      ok: false,
      message: 'URL e Anon Key são obrigatórias para conectar ao Supabase.',
      mode: 'local',
    };
  }

  const startTime = Date.now();
  try {
    const testClient = createClient(url, anonKey);
    const { error } = await testClient.from('lojas').select('id').limit(1);
    const latency = Date.now() - startTime;

    if (error) {
      return {
        ok: false,
        message: `Erro retornado pelo Supabase (${latency}ms): ${error.message}. Execute o script SQL schema.sql caso a tabela 'lojas' ainda não tenha sido criada.`,
        latencyMs: latency,
        mode: 'local',
      };
    }

    return {
      ok: true,
      message: `Conexão bem-sucedida! Supabase respondeu em ${latency}ms com a tabela 'lojas' operacional.`,
      latencyMs: latency,
      mode: 'supabase',
    };
  } catch (err: any) {
    const latency = Date.now() - startTime;
    return {
      ok: false,
      message: `Falha de rede ao conectar com ${url}: ${err?.message || err}`,
      latencyMs: latency,
      mode: 'local',
    };
  }
}

export const DataService = {
  isConfigured(): boolean {
    const client = getSupabaseClient();
    return Boolean(client);
  },

  async testConnection(): Promise<{ ok: boolean; message: string; mode: 'supabase' | 'local'; latencyMs?: number }> {
    const client = getSupabaseClient();
    if (!client) {
      return {
        ok: true,
        message: 'Modo Local Ativo: Usando banco de dados multi-tenant offline seguro.',
        mode: 'local',
      };
    }
    const creds = getActiveSupabaseCredentials();
    return testSupabaseCredentials(creds.url, creds.anonKey);
  },

  async saveConfig(config: {
    url: string;
    anonKey: string;
    serviceRoleKey?: string;
  }): Promise<{
    ok: boolean;
    message: string;
    latencyMs?: number;
    mode: 'supabase' | 'local';
  }> {
    const res = await testSupabaseCredentials(config.url, config.anonKey);
    AppStorage.saveSupabaseConfig({
      url: config.url.trim(),
      anonKey: config.anonKey.trim(),
      serviceRoleKey: config.serviceRoleKey?.trim(),
      lastTested: new Date().toISOString(),
      status: res.ok ? 'connected' : 'error',
    });
    cachedClient = null;
    currentClientKey = '';
    return res;
  },

  async getLojaBySlug(slug: string): Promise<Loja | null> {
    const raw = decodeURIComponent(slug || '').toLowerCase().trim();
    const cleanSlug = raw.replace(/^\/loja\//, '').replace(/^loja\//, '').replace(/\/$/, '');
    if (!cleanSlug) return null;
    const sanitizedSlug = sanitizeSlug(cleanSlug);
    const espacado = cleanSlug.replace(/-/g, ' ');

    const client = getSupabaseClient();
    if (client) {
      try {
        let storeRecord: any = null;
        try {
          const { data, error } = await client
            .from('lojas')
            .select('*')
            .ilike('slug', cleanSlug)
            .maybeSingle();
          if (!error && data) {
            storeRecord = data;
          }
        } catch {}

        if (!storeRecord && sanitizedSlug !== cleanSlug) {
          try {
            const { data, error } = await client
              .from('lojas')
              .select('*')
              .ilike('slug', sanitizedSlug)
              .maybeSingle();
            if (!error && data) {
              storeRecord = data;
            }
          } catch {}
        }

        if (!storeRecord) {
          try {
            const { data: todasLojas, error } = await client.from('lojas').select('*');
            if (!error && todasLojas) {
              storeRecord = todasLojas.find((l: any) => {
                const nome = (l.nome || l.nome_loja || '').trim();
                const nomeLower = nome.toLowerCase();
                const s = (l.slug || '').trim().toLowerCase();
                if (s && (s === cleanSlug || sanitizeSlug(s) === sanitizedSlug)) return true;
                if (nome && sanitizeSlug(nome) === sanitizedSlug) return true;
                if (nome && nomeLower.replace(/[\s_-]+/g, '-') === sanitizedSlug) return true;
                if (nome && nomeLower === espacado) return true;
                return false;
              });
            }
          } catch {}
        }

        if (storeRecord) {
          const data = storeRecord;
          const loja: Loja = {
            id: data.id,
            user_id: data.owner_id || data.user_id,
            nome_loja: data.nome || data.nome_loja || data.name || '',
            nome: data.nome || data.nome_loja || data.name || '',
            slug: data.slug,
            telefone_whatsapp: data.whatsapp || data.telefone_whatsapp || data.phone || '',
            whatsapp: data.whatsapp || data.telefone_whatsapp || data.phone || '',
            email: data.email,
            endereco_origem: {
              lat: data.origem_lat || -20.4697,
              lng: data.origem_lng || -54.6201,
              endereco_texto: data.origem_endereco_texto || 'Av. Afonso Pena, 1500 - Centro',
            },
            chave_pix: data.chave_pix,
            mercadopago_access_token: data.mercadopago_access_token,
            abacatepay_api_key: data.abacatepay_api_key,
            taxa_base_entrega: Number(data.taxa_base_entrega || 5.0),
            valor_por_km: Number(data.valor_por_km || 1.5),
            taxas_bairros: data.taxas_bairros || [],
            modelo_calculo_entrega: data.modelo_calculo_entrega || 'raio_km',
            raios_entrega: data.raios_entrega,
            raio_maximo_km: Number(data.raio_maximo_km || 15),
            valor_km_excedente: Number(data.valor_km_excedente || 2),
            valor_pedido_frete_gratis: data.valor_pedido_frete_gratis ? Number(data.valor_pedido_frete_gratis) : undefined,
            status_conta: data.status_conta || 'ativa',
            logo_url: data.logo_url,
            cor_primaria: data.cor_tema || data.cor_primaria || '#dc2626',
            aberto: data.aberto !== undefined ? data.aberto : true,
            impressora_largura: data.impressora_largura || '80mm',
            impressora_fonte: data.impressora_fonte || 'normal',
            impressora_vias: data.impressora_vias || 1,
            impressora_auto_imprimir: Boolean(data.impressora_auto_imprimir),
            impressora_espaco_corte: Number(data.impressora_espaco_corte || 4),
            impressora_rodape_texto: data.impressora_rodape_texto || 'Agradecemos a preferência! Volte sempre.',
            banner_oferta: data.banner_oferta,
            created_at: data.created_at || new Date().toISOString(),
          };
          AppStorage.saveOrUpdateLojaCache(loja);
          return loja;
        }
      } catch (e) {
        console.warn('Erro ao buscar loja por slug no Supabase:', e);
      }
    }

    const localLoja = AppStorage.getLojaBySlug(cleanSlug);
    if (localLoja) {
      return localLoja;
    }
    return null;
  },

  async corrigirSlugsDeTodasAsLojas(): Promise<{ corrigidas: number; total: number }> {
    let corrigidas = 0;
    let total = 0;
    const client = getSupabaseClient();
    if (client) {
      try {
        const { data: lojas, error } = await client.from('lojas').select('*');
        if (!error && lojas) {
          total += lojas.length;
          for (const l of lojas) {
            const nome = l.nome || l.nome_loja || '';
            if (!l.slug || l.slug.trim() === '') {
              const novoSlug = sanitizeSlug(nome) || `loja-${l.id.slice(0, 8)}`;
              const { error: updErr } = await client.from('lojas').update({ slug: novoSlug }).eq('id', l.id);
              if (!updErr) corrigidas++;
            }
          }
        }
      } catch (e) {
        console.warn('Erro ao verificar slugs em lojas:', e);
      }
    }

    const localLojas = AppStorage.getLojas();
    for (const l of localLojas) {
      if (!l.slug || l.slug.trim() === '') {
        const novoSlug = sanitizeSlug(l.nome_loja || l.nome || 'loja');
        AppStorage.updateLoja(l.id, { slug: novoSlug });
        corrigidas++;
      }
    }
    return { corrigidas, total };
  },

  async cadastrarNovaLoja(dados: {
    nomeLoja: string;
    slug: string;
    whatsapp: string;
    email: string;
    senha?: string;
    logo_url?: string;
    segmento?: string;
  }): Promise<{ loja: Loja; assinatura: SaasAssinatura }> {
    const slugSemEspacos = sanitizeSlug(dados.slug || dados.nomeLoja);
    const res = AppStorage.cadastrarNovaLoja({
      ...dados,
      slug: slugSemEspacos,
    });

    const client = getSupabaseClient();
    if (client) {
      try {
        const nova = res.loja;
        const ass = res.assinatura;

        // 1. Inserir Loja no Supabase
        const lojaPayload = {
          id: nova.id,
          nome: nova.nome_loja,
          nome_loja: nova.nome_loja,
          slug: nova.slug,
          whatsapp: nova.telefone_whatsapp,
          telefone_whatsapp: nova.telefone_whatsapp,
          email: nova.email,
          senha: nova.senha,
          cidade: nova.cidade || 'Campo Grande, MS',
          status_conta: 'ativa',
          taxa_base_entrega: nova.taxa_base_entrega,
          valor_por_km: nova.valor_por_km,
          logo_url: nova.logo_url,
          cor_tema: nova.cor_primaria,
          cor_primaria: nova.cor_primaria,
          aberto: true,
          impressora_largura: '80mm',
          impressora_fonte: 'normal',
          impressora_vias: 1,
          impressora_auto_imprimir: true,
          created_at: nova.created_at,
          updated_at: new Date().toISOString(),
        };
        await client.from('lojas').upsert(lojaPayload);

        // 2. Inserir Conta do Lojista na tabela saas_contas para sincronização multi-dispositivo
        try {
          await client.from('saas_contas').upsert({
            loja_id: nova.id,
            nome_responsavel: nova.nome_loja,
            nome_loja: nova.nome_loja,
            slug: nova.slug,
            email: nova.email,
            whatsapp: nova.telefone_whatsapp,
            senha: nova.senha,
            status: 'ativa',
            plano: 'mensal',
            dispositivos_conectados: 1,
            ultimo_acesso: new Date().toISOString(),
            created_at: nova.created_at,
            updated_at: new Date().toISOString(),
          });
        } catch (e) {
          console.warn('Aviso ao sincronizar conta em saas_contas no Supabase:', e);
        }

        // 3. Inserir Assinatura no Supabase
        try {
          await client.from('saas_assinaturas').upsert({
            id: ass.id,
            loja_id: nova.id,
            status: 'ativa',
            plano: 'mensal',
            valor: ass.valor,
            data_vencimento: ass.data_vencimento,
            dias_teste: ass.dias_teste || 7,
            created_at: ass.created_at,
          });
        } catch (e) {
          console.warn('Erro ao inserir assinatura inicial no Supabase:', e);
        }

        // 3. Inserir Categorias no Supabase
        const cats = AppStorage.getCategorias(nova.id);
        for (const c of cats) {
          try {
            await client.from('categorias').upsert({
              id: c.id,
              loja_id: nova.id,
              nome: c.nome,
              ordem: c.ordem,
              ativa: true,
              created_at: c.created_at,
            });
          } catch {}
        }

        // 4. Inserir Produtos no Supabase
        const prods = AppStorage.getProdutos(nova.id);
        for (const p of prods) {
          try {
            await client.from('produtos').upsert({
              id: p.id,
              loja_id: nova.id,
              categoria_id: p.categoria_id,
              nome: p.nome,
              descricao: p.descricao,
              preco: p.preco,
              preco_promocional: p.preco_promocional || null,
              imagem: p.imagem_url || p.imagem,
              imagem_url: p.imagem_url || p.imagem,
              destaque_oferta: true,
              destaque_mais_pedido: true,
              ativo: true,
              disponivel: true,
              created_at: p.created_at,
              updated_at: new Date().toISOString(),
            });
          } catch {}
        }
      } catch (err) {
        console.warn('Aviso ao sincronizar nova loja no Supabase:', err);
      }
    }
    return res;
  },

  async updateLoja(lojaId: string, updates: Partial<Loja>): Promise<void> {
    AppStorage.updateLoja(lojaId, updates);
    const client = getSupabaseClient();
    if (client) {
      try {
        const payload: Record<string, any> = {
          updated_at: new Date().toISOString(),
        };
        if (updates.nome_loja !== undefined) payload.nome_loja = updates.nome_loja;
        if (updates.nome !== undefined) payload.nome = updates.nome;
        if (updates.slug !== undefined) payload.slug = updates.slug;
        if (updates.telefone_whatsapp !== undefined) {
          payload.telefone_whatsapp = updates.telefone_whatsapp;
          payload.whatsapp = updates.telefone_whatsapp;
        }
        if (updates.chave_pix !== undefined) payload.chave_pix = updates.chave_pix;
        if (updates.mercadopago_access_token !== undefined) payload.mercadopago_access_token = updates.mercadopago_access_token;
        if (updates.abacatepay_api_key !== undefined) payload.abacatepay_api_key = updates.abacatepay_api_key;
        if (updates.taxa_base_entrega !== undefined) payload.taxa_base_entrega = updates.taxa_base_entrega;
        if (updates.valor_por_km !== undefined) payload.valor_por_km = updates.valor_por_km;
        if (updates.taxas_bairros !== undefined) payload.taxas_bairros = updates.taxas_bairros;
        if (updates.modelo_calculo_entrega !== undefined) payload.modelo_calculo_entrega = updates.modelo_calculo_entrega;
        if (updates.raios_entrega !== undefined) payload.raios_entrega = updates.raios_entrega;
        if (updates.raio_maximo_km !== undefined) payload.raio_maximo_km = updates.raio_maximo_km;
        if (updates.valor_km_excedente !== undefined) payload.valor_km_excedente = updates.valor_km_excedente;
        if (updates.valor_pedido_frete_gratis !== undefined) payload.valor_pedido_frete_gratis = updates.valor_pedido_frete_gratis;
        if (updates.impressora_largura !== undefined) payload.impressora_largura = updates.impressora_largura;
        if (updates.impressora_fonte !== undefined) payload.impressora_fonte = updates.impressora_fonte;
        if (updates.impressora_vias !== undefined) payload.impressora_vias = updates.impressora_vias;
        if (updates.impressora_auto_imprimir !== undefined) payload.impressora_auto_imprimir = updates.impressora_auto_imprimir;
        if (updates.impressora_espaco_corte !== undefined) payload.impressora_espaco_corte = updates.impressora_espaco_corte;
        if (updates.impressora_rodape_texto !== undefined) payload.impressora_rodape_texto = updates.impressora_rodape_texto;
        if (updates.status_conta !== undefined) payload.status_conta = updates.status_conta;
        if (updates.aberto !== undefined) payload.aberto = updates.aberto;
        if (updates.logo_url !== undefined) payload.logo_url = updates.logo_url;
        if (updates.cor_primaria !== undefined) payload.cor_primaria = updates.cor_primaria;
        if (updates.cidade !== undefined) payload.cidade = updates.cidade;

        await client.from('lojas').update(payload).eq('id', lojaId);
      } catch (e) {
        console.warn('Erro ao atualizar loja no Supabase:', e);
      }
    }
  },

  async editarLojaCompleta(
    lojaId: string,
    dados: Partial<Loja> & { diasTeste?: number; valorMensal?: number }
  ): Promise<Loja | null> {
    const atualizada = AppStorage.editarLojaCompleta(lojaId, dados);
    const client = getSupabaseClient();
    if (client && atualizada) {
      try {
        await client
          .from('lojas')
          .update({
            nome: atualizada.nome_loja,
            nome_loja: atualizada.nome_loja,
            slug: atualizada.slug,
            telefone_whatsapp: atualizada.telefone_whatsapp,
            whatsapp: atualizada.telefone_whatsapp,
            email: atualizada.email,
            senha: atualizada.senha,
            segmento: atualizada.segmento,
            status_conta: atualizada.status_conta,
            chave_pix: atualizada.chave_pix,
            taxa_base_entrega: atualizada.taxa_base_entrega,
            valor_por_km: atualizada.valor_por_km,
            updated_at: new Date().toISOString(),
          })
          .eq('id', lojaId);

        if (dados.diasTeste !== undefined || dados.valorMensal !== undefined) {
          const ass = AppStorage.getAssinaturaByLoja(lojaId);
          if (ass) {
            await client
              .from('saas_assinaturas')
              .update({
                valor: ass.valor,
                dias_teste: ass.dias_teste,
                data_vencimento: ass.data_vencimento,
                status: ass.status,
              })
              .eq('loja_id', lojaId);
          }
        }
      } catch (e) {
        console.warn('Erro ao atualizar dados completos da loja no Supabase:', e);
      }
    }
    return atualizada;
  },

  async renovarAssinaturaLoja(
    lojaId: string,
    gateway: 'mercadopago' | 'abacatepay' | 'pix',
    comprovanteId: string,
    valor: number = 169.99
  ): Promise<{ sucesso: boolean; mensagem: string }> {
    // 1. Atualizar localmente
    const res = AppStorage.processarWebhookPagamentoSaas(
      lojaId,
      gateway === 'pix' ? 'mercadopago' : gateway,
      comprovanteId
    );

    // 2. Atualizar no Supabase
    const client = getSupabaseClient();
    if (client) {
      try {
        const novaDataVencimento = new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString();
        // Atualiza a assinatura
        await client
          .from('saas_assinaturas')
          .update({
            status: 'ativa',
            data_vencimento: novaDataVencimento,
            ultimo_pagamento: new Date().toISOString(),
            dias_teste: 0,
          })
          .eq('loja_id', lojaId);

        // Atualiza a loja para ativa
        await client
          .from('lojas')
          .update({
            status_conta: 'ativa',
            updated_at: new Date().toISOString(),
          })
          .eq('id', lojaId);

        // Registra log do pagamento
        const loja = AppStorage.getLojaById(lojaId);
        await client.from('saas_pagamentos_logs').insert({
          loja_id: lojaId,
          loja_nome: loja?.nome_loja || 'Loja',
          valor,
          metodo: 'pix',
          gateway: gateway === 'pix' ? 'mercadopago' : gateway,
          status: 'confirmado',
          data_pagamento: new Date().toISOString(),
          comprovante_id: comprovanteId,
        });
      } catch (err) {
        console.warn('Erro ao sincronizar renovação no Supabase:', err);
      }
    }

    return res;
  },

  async getLojas(): Promise<Loja[]> {
    const client = getSupabaseClient();
    if (client) {
      try {
        const { data, error } = await client.from('lojas').select('*');
        if (!error && data && data.length > 0) {
          const mapped: Loja[] = data.map((l: any) => ({
            id: l.id,
            user_id: l.owner_id || l.user_id,
            nome_loja: l.nome || l.nome_loja,
            nome: l.nome || l.nome_loja,
            slug: l.slug,
            email: l.email || '',
            senha: l.senha || '123456',
            cidade: l.cidade || 'Campo Grande, MS',
            telefone_whatsapp: l.whatsapp || l.telefone_whatsapp,
            whatsapp: l.whatsapp || l.telefone_whatsapp,
            endereco_origem: {
              lat: l.origem_lat || -20.4697,
              lng: l.origem_lng || -54.6201,
              endereco_texto: l.origem_endereco_texto || 'Av. Afonso Pena, 1500 - Centro',
            },
            chave_pix: l.chave_pix,
            mercadopago_access_token: l.mercadopago_access_token,
            abacatepay_api_key: l.abacatepay_api_key,
            taxa_base_entrega: Number(l.taxa_base_entrega || 5.0),
            valor_por_km: Number(l.valor_por_km || 1.5),
            taxas_bairros: l.taxas_bairros || [],
            modelo_calculo_entrega: l.modelo_calculo_entrega || 'raio_km',
            raios_entrega: l.raios_entrega,
            raio_maximo_km: Number(l.raio_maximo_km || 15),
            valor_km_excedente: Number(l.valor_km_excedente || 2),
            valor_pedido_frete_gratis: l.valor_pedido_frete_gratis ? Number(l.valor_pedido_frete_gratis) : undefined,
            status_conta: l.status_conta || 'ativa',
            logo_url: l.logo_url,
            cor_primaria: l.cor_tema || l.cor_primaria || '#dc2626',
            aberto: l.aberto !== undefined ? l.aberto : true,
            impressora_largura: l.impressora_largura || '80mm',
            impressora_fonte: l.impressora_fonte || 'normal',
            impressora_vias: l.impressora_vias || 1,
            impressora_auto_imprimir: Boolean(l.impressora_auto_imprimir),
            impressora_espaco_corte: Number(l.impressora_espaco_corte || 4),
            impressora_rodape_texto: l.impressora_rodape_texto || 'Agradecemos a preferência! Volte sempre.',
            banner_oferta: l.banner_oferta,
            created_at: l.created_at || new Date().toISOString(),
          }));

          // Sincronizar automaticamente no cache local para navegação offline rápida
          mapped.forEach((item) => AppStorage.saveOrUpdateLojaCache(item));
          return mapped;
        }
      } catch (e) {
        console.warn('Fallback para AppStorage getLojas:', e);
      }
    }
    return AppStorage.getLojas();
  },

  async authenticateMerchant(
    identificador: string,
    senhaDigitada: string,
    lojaIdAlvo?: string
  ): Promise<{ success: boolean; loja?: Loja; erro?: string }> {
    const cleanInput = (identificador || '').trim().toLowerCase();
    const cleanTel = cleanInput.replace(/\D/g, '');
    const cleanPass = (senhaDigitada || '').trim();

    if (cleanInput === 'adileradm') {
      return { success: false, erro: 'Credencial de Super Admin. Use o painel Super Admin.' };
    }
    if (!cleanInput || !cleanPass) {
      return { success: false, erro: 'Informe seu e-mail ou WhatsApp e senha de acesso.' };
    }

    // 1. Tentar primeiro no cache local
    const localRes = AppStorage.authenticateMerchant(lojaIdAlvo || '', cleanInput, cleanPass);
    if (localRes.success && localRes.lojaId) {
      const lojaLocal = AppStorage.getLojaById(localRes.lojaId);
      if (lojaLocal) {
        return { success: true, loja: lojaLocal };
      }
    }

    // 2. Se não encontrou ou falhou localmente, consultar diretamente o Supabase (para acessar em outros dispositivos)
    const client = getSupabaseClient();
    if (client) {
      try {
        let storeRecord: any = null;
        let contaRecord: any = null;

        // A. Consultar primeiro a tabela oficial saas_contas
        try {
          let queryContas = client.from('saas_contas').select('*');
          if (cleanInput.includes('@')) {
            queryContas = queryContas.ilike('email', cleanInput);
          } else if (cleanTel.length >= 8) {
            queryContas = queryContas.or(`whatsapp.ilike.%${cleanTel}%,slug.ilike.%${cleanInput}%`);
          } else {
            queryContas = queryContas.ilike('slug', cleanInput);
          }
          const { data: cData } = await queryContas.limit(1);
          if (cData && cData.length > 0) {
            contaRecord = cData[0];
          }
        } catch (e) {
          console.warn('Consulta em saas_contas:', e);
        }

        // B. Se achou conta em saas_contas, validar senha
        if (contaRecord) {
          const passCadastrada = (contaRecord.senha || '123456').trim();
          if (cleanPass !== passCadastrada) {
            return { success: false, erro: 'Senha incorreta para esta conta.' };
          }
          // Localizar loja associada
          const targetLojaId = contaRecord.loja_id || contaRecord.id;
          const { data: sData } = await client.from('lojas').select('*').eq('id', targetLojaId).maybeSingle();
          if (sData) {
            storeRecord = sData;
          } else {
            storeRecord = {
              id: targetLojaId,
              nome_loja: contaRecord.nome_loja,
              nome: contaRecord.nome_loja,
              slug: contaRecord.slug,
              email: contaRecord.email,
              whatsapp: contaRecord.whatsapp,
              telefone_whatsapp: contaRecord.whatsapp,
              senha: contaRecord.senha,
              status_conta: contaRecord.status || 'ativa',
              created_at: contaRecord.created_at,
            };
          }
        }

        // C. Se não achou em saas_contas, consultar diretamente a tabela lojas
        if (!storeRecord) {
          // Busca por e-mail exato
          if (cleanInput.includes('@')) {
            const { data, error } = await client
              .from('lojas')
              .select('*')
              .ilike('email', cleanInput)
              .limit(1);
            if (!error && data && data.length > 0) {
              storeRecord = data[0];
            }
          }

          // Busca por slug
          if (!storeRecord) {
            const { data, error } = await client
              .from('lojas')
              .select('*')
              .ilike('slug', cleanInput)
              .limit(1);
            if (!error && data && data.length > 0) {
              storeRecord = data[0];
            }
          }

          // Busca por telefone / WhatsApp
          if (!storeRecord && cleanTel.length >= 8) {
            const { data, error } = await client
              .from('lojas')
              .select('*')
              .or(`whatsapp.ilike.%${cleanTel}%,telefone_whatsapp.ilike.%${cleanTel}%`)
              .limit(1);
            if (!error && data && data.length > 0) {
              storeRecord = data[0];
            }
          }

          // Busca completa em lojas se não achou pelos filtros rápidos
          if (!storeRecord) {
            const { data, error } = await client.from('lojas').select('*');
            if (!error && data) {
              storeRecord = data.find((l: any) => {
                const lEmail = (l.email || '').trim().toLowerCase();
                const lTel = (l.whatsapp || l.telefone_whatsapp || '').replace(/\D/g, '');
                const lSlug = (l.slug || '').trim().toLowerCase();
                const emailMatch = lEmail.length > 0 && cleanInput === lEmail;
                const slugMatch = lSlug.length > 0 && cleanInput === lSlug;
                const telMatch =
                  cleanTel.length >= 8 &&
                  lTel.length >= 8 &&
                  (lTel === cleanTel || lTel.endsWith(cleanTel) || cleanTel.endsWith(lTel));
                return emailMatch || slugMatch || telMatch;
              });
            }
          }
        }

        if (storeRecord) {
          const passCadastrada = (storeRecord.senha || '123456').trim();
          if (cleanPass !== passCadastrada) {
            return { success: false, erro: 'Senha incorreta para esta conta.' };
          }

          const lojaSupa: Loja = {
            id: storeRecord.id,
            user_id: storeRecord.owner_id || storeRecord.user_id,
            nome_loja: storeRecord.nome || storeRecord.nome_loja,
            nome: storeRecord.nome || storeRecord.nome_loja,
            slug: storeRecord.slug,
            email: storeRecord.email || '',
            senha: storeRecord.senha || '123456',
            cidade: storeRecord.cidade || 'Campo Grande, MS',
            telefone_whatsapp: storeRecord.whatsapp || storeRecord.telefone_whatsapp,
            whatsapp: storeRecord.whatsapp || storeRecord.telefone_whatsapp,
            endereco_origem: {
              lat: storeRecord.origem_lat || -20.4697,
              lng: storeRecord.origem_lng || -54.6201,
              endereco_texto: storeRecord.origem_endereco_texto || 'Av. Afonso Pena, 1500 - Centro',
            },
            chave_pix: storeRecord.chave_pix,
            mercadopago_access_token: storeRecord.mercadopago_access_token,
            abacatepay_api_key: storeRecord.abacatepay_api_key,
            taxa_base_entrega: Number(storeRecord.taxa_base_entrega || 5.0),
            valor_por_km: Number(storeRecord.valor_por_km || 1.5),
            taxas_bairros: storeRecord.taxas_bairros || [],
            modelo_calculo_entrega: storeRecord.modelo_calculo_entrega || 'raio_km',
            raios_entrega: storeRecord.raios_entrega,
            raio_maximo_km: Number(storeRecord.raio_maximo_km || 15),
            valor_km_excedente: Number(storeRecord.valor_km_excedente || 2),
            valor_pedido_frete_gratis: storeRecord.valor_pedido_frete_gratis ? Number(storeRecord.valor_pedido_frete_gratis) : undefined,
            status_conta: storeRecord.status_conta || 'ativa',
            logo_url: storeRecord.logo_url,
            cor_primaria: storeRecord.cor_tema || storeRecord.cor_primaria || '#dc2626',
            aberto: storeRecord.aberto !== undefined ? storeRecord.aberto : true,
            impressora_largura: storeRecord.impressora_largura || '80mm',
            impressora_fonte: storeRecord.impressora_fonte || 'normal',
            impressora_vias: storeRecord.impressora_vias || 1,
            impressora_auto_imprimir: Boolean(storeRecord.impressora_auto_imprimir),
            impressora_espaco_corte: Number(storeRecord.impressora_espaco_corte || 4),
            impressora_rodape_texto: storeRecord.impressora_rodape_texto || 'Agradecemos a preferência! Volte sempre.',
            banner_oferta: storeRecord.banner_oferta,
            created_at: storeRecord.created_at || new Date().toISOString(),
          };

          AppStorage.saveOrUpdateLojaCache(lojaSupa);

          // Sincronizar assinatura do Supabase se existir
          try {
            const { data: assData } = await client
              .from('saas_assinaturas')
              .select('*')
              .eq('loja_id', lojaSupa.id)
              .maybeSingle();
            if (assData) {
              AppStorage.saveOrUpdateAssinaturaCache({
                id: assData.id,
                loja_id: assData.loja_id,
                status: assData.status || 'ativa',
                plano: assData.plano || 'mensal',
                valor: Number(assData.valor || 169.99),
                data_vencimento: assData.data_vencimento,
                ultimo_pagamento: assData.ultimo_pagamento,
                dias_teste: assData.dias_teste,
                created_at: assData.created_at,
              });
            }
          } catch {}

          // Sincronizar categorias e produtos deste lojista do Supabase para este novo dispositivo
          try {
            const [supaCats, supaProds] = await Promise.all([
              client.from('categorias').select('*').eq('loja_id', lojaSupa.id),
              client.from('produtos').select('*').eq('loja_id', lojaSupa.id),
            ]);
            if (supaCats.data) {
              AppStorage.saveCategoriasCache(lojaSupa.id, supaCats.data);
            }
            if (supaProds.data) {
              AppStorage.saveProdutosCache(lojaSupa.id, supaProds.data);
            }
          } catch {}

          // Atualizar último acesso e registrar em saas_contas
          try {
            await client.from('saas_contas').upsert({
              loja_id: lojaSupa.id,
              nome_responsavel: lojaSupa.nome_loja,
              nome_loja: lojaSupa.nome_loja,
              slug: lojaSupa.slug,
              email: lojaSupa.email,
              whatsapp: lojaSupa.telefone_whatsapp,
              senha: lojaSupa.senha,
              status: 'ativa',
              ultimo_acesso: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            });
          } catch {}

          // Autenticar este dispositivo
          AppStorage.setActiveLojaId(lojaSupa.id);
          AppStorage.setAuthenticatedMerchantLojaId(lojaSupa.id);

          return { success: true, loja: lojaSupa };
        }
      } catch (err: any) {
        console.warn('Erro ao autenticar no Supabase:', err);
      }
    }

    return {
      success: false,
      erro: 'Nenhuma conta encontrada com este e-mail ou WhatsApp. Verifique seus dados ou crie sua conta.',
    };
  },

  async limparCardapioLoja(lojaId: string): Promise<void> {
    AppStorage.limparCardapioLoja(lojaId);
    const client = getSupabaseClient();
    if (client) {
      try {
        await client.from('produtos').delete().eq('loja_id', lojaId);
        await client.from('categorias').delete().eq('loja_id', lojaId);
      } catch (e) {
        console.warn('Erro ao limpar cardápio no Supabase:', e);
      }
    }
  },

  async updateLojaPrinterConfig(lojaId: string, config: PrinterConfig): Promise<void> {
    AppStorage.updateLojaPrinterConfig(lojaId, config);
    const client = getSupabaseClient();
    if (client) {
      try {
        await client
          .from('lojas')
          .update({
            impressora_largura: config.largura,
            impressora_fonte: config.fonte,
            impressora_vias: config.vias,
            impressora_auto_imprimir: config.autoImprimir,
            updated_at: new Date().toISOString(),
          })
          .eq('id', lojaId);
      } catch (e) {
        console.warn('Erro ao sincronizar impressora com Supabase:', e);
      }
    }
  },

  async updateLojaBanner(lojaId: string, banner: BannerOfertaConfig): Promise<void> {
    AppStorage.updateLojaBanner(lojaId, banner);
    const client = getSupabaseClient();
    if (client) {
      try {
        await client
          .from('lojas')
          .update({
            banner_oferta: banner,
            updated_at: new Date().toISOString(),
          })
          .eq('id', lojaId);
      } catch (e) {
        console.warn('Erro ao sincronizar banner com Supabase:', e);
      }
    }
  },

  async deleteLoja(lojaId: string): Promise<boolean> {
    const ok = AppStorage.deleteLoja(lojaId);
    const client = getSupabaseClient();
    if (client) {
      try {
        await client.from('pedidos').delete().or(`loja_id.eq.${lojaId},store_id.eq.${lojaId}`);
        await client.from('produtos').delete().or(`loja_id.eq.${lojaId},store_id.eq.${lojaId}`);
        await client.from('categorias').delete().or(`loja_id.eq.${lojaId},store_id.eq.${lojaId}`);
        await client.from('lojas').delete().eq('id', lojaId);
      } catch (e) {
        console.warn('Erro ao deletar loja no Supabase:', e);
      }
    }
    return ok;
  },

  async getCategorias(lojaId: string): Promise<Categoria[]> {
    if (!lojaId) return [];
    const client = getSupabaseClient();
    if (client) {
      try {
        const res = await client
          .from('categorias')
          .select('*')
          .eq('loja_id', lojaId)
          .order('ordem', { ascending: true });
        if (!res.error && res.data && res.data.length > 0) {
          const mapped = res.data.map((c: any) => ({
            id: c.id,
            loja_id: c.loja_id || lojaId,
            nome: c.nome,
            ordem: c.ordem ?? 1,
            ativa: c.ativa ?? true,
            created_at: c.created_at,
          }));
          AppStorage.saveCategoriasCache(lojaId, mapped);
          return mapped;
        }
      } catch (e) {
        console.warn('Fallback para AppStorage getCategorias:', e);
      }
    }
    return AppStorage.getCategorias(lojaId);
  },

  async addCategoria(lojaId: string, nome: string): Promise<Categoria> {
    const localCat = AppStorage.addCategoria(lojaId, nome);
    const client = getSupabaseClient();
    if (client) {
      try {
        await client.from('categorias').insert({
          id: localCat.id,
          loja_id: lojaId,
          nome,
          ordem: localCat.ordem,
          ativa: true,
        });
      } catch (e) {
        console.warn('Erro ao inserir categoria no Supabase:', e);
      }
    }
    return localCat;
  },

  async getProdutos(lojaId: string): Promise<Produto[]> {
    if (!lojaId) return [];
    const client = getSupabaseClient();
    if (client) {
      try {
        const res = await client
          .from('produtos')
          .select('*')
          .eq('loja_id', lojaId);
        if (!res.error && res.data && res.data.length > 0) {
          const mapped = res.data.map((p: any) => ({
            id: p.id,
            loja_id: p.loja_id || lojaId,
            categoria_id: p.categoria_id,
            nome: p.nome,
            descricao: p.descricao || '',
            preco: Number(p.preco),
            preco_promocional: p.preco_promocional ? Number(p.preco_promocional) : undefined,
            preco_original: p.preco_promocional ? `R$ ${Number(p.preco).toFixed(2).replace('.', ',')}` : undefined,
            imagem: p.imagem || p.imagem_url,
            imagem_url: p.imagem_url || p.imagem,
            destaque_oferta: Boolean(p.destaque_oferta),
            destaque_mais_pedido: Boolean(p.destaque_mais_pedido),
            ativo: p.ativo ?? p.disponivel ?? true,
            disponivel: p.disponivel ?? p.ativo ?? true,
            created_at: p.created_at,
          }));
          AppStorage.saveProdutosCache(lojaId, mapped);
          return mapped;
        }
      } catch (e) {
        console.warn('Fallback para AppStorage getProdutos:', e);
      }
    }
    return AppStorage.getProdutos(lojaId);
  },

  async saveProduto(produto: Omit<Produto, 'id' | 'created_at'> & { id?: string }): Promise<Produto> {
    let saved: Produto;
    if (produto.id) {
      AppStorage.updateProduto(produto.id, produto);
      saved = AppStorage.getProdutos(produto.loja_id).find((p) => p.id === produto.id)!;
    } else {
      saved = AppStorage.addProduto(produto);
    }
    const client = getSupabaseClient();
    if (client) {
      try {
        const payload = {
          id: saved.id,
          loja_id: saved.loja_id,
          categoria_id: saved.categoria_id,
          nome: saved.nome,
          descricao: saved.descricao,
          preco: saved.preco,
          preco_promocional: saved.preco_promocional || null,
          imagem: saved.imagem_url || saved.imagem,
          destaque_oferta: saved.destaque_oferta,
          destaque_mais_pedido: saved.destaque_mais_pedido,
          ativo: saved.disponivel,
          updated_at: new Date().toISOString(),
        };
        await client.from('produtos').upsert(payload);
      } catch (e) {
        console.warn('Erro ao persistir produto no Supabase:', e);
      }
    }
    return saved;
  },

  async deleteProduto(lojaId: string, produtoId: string): Promise<void> {
    AppStorage.deleteProduto(produtoId);
    const client = getSupabaseClient();
    if (client) {
      try {
        await client.from('produtos').delete().eq('id', produtoId);
      } catch (e) {
        console.warn('Erro ao deletar produto no Supabase:', e);
      }
    }
  },

  async findClienteByTelefone(lojaId: string, telefone: string): Promise<Cliente | null> {
    const cleanTel = telefone.replace(/\D/g, '');
    if (!cleanTel || cleanTel.length < 8) return null;
    const client = getSupabaseClient();
    if (client) {
      try {
        const { data } = await client
          .from('clientes')
          .select('*')
          .eq('loja_id', lojaId)
          .ilike('telefone', `%${cleanTel.slice(-8)}%`)
          .limit(1);
        if (data && data.length > 0) {
          const c = data[0];
          return {
            id: c.id,
            loja_id: c.loja_id,
            nome: c.nome,
            telefone: c.telefone,
            endereco: c.endereco,
            numero: c.numero,
            complemento: c.complemento,
            bairro: c.bairro,
            created_at: c.created_at,
          };
        }
      } catch (e) {
        console.warn('Fallback para AppStorage busca de cliente:', e);
      }
    }
    return AppStorage.findClienteByTelefone(lojaId, cleanTel);
  },

  async saveCliente(cliente: Omit<Cliente, 'id' | 'created_at'>): Promise<Cliente> {
    const saved = AppStorage.saveCliente(cliente);
    const client = getSupabaseClient();
    if (client) {
      try {
        await client.from('clientes').upsert({
          id: saved.id,
          loja_id: saved.loja_id,
          nome: saved.nome,
          telefone: saved.telefone,
          endereco: saved.endereco,
          numero: saved.numero,
          complemento: saved.complemento,
          bairro: saved.bairro,
          created_at: saved.created_at,
        });
      } catch (e) {
        console.warn('Erro ao salvar cliente no Supabase:', e);
      }
    }
    return saved;
  },

  async getPedidos(lojaId: string): Promise<Pedido[]> {
    const client = getSupabaseClient();
    if (client) {
      try {
        const { data, error } = await client
          .from('pedidos')
          .select('*, itens:itens_pedido(*)')
          .eq('loja_id', lojaId)
          .order('created_at', { ascending: false });
        if (!error && data && data.length > 0) {
          return data.map((p: any) => ({
            id: p.id,
            loja_id: p.loja_id,
            codigo_pedido: p.codigo_pedido || `#${p.id.slice(-4)}`,
            cliente_nome: p.cliente_nome,
            cliente_telefone: p.cliente_telefone,
            tipo_entrega: p.tipo_entrega || 'delivery',
            endereco_destino: p.endereco_completo || p.endereco_destino,
            endereco_completo: p.endereco_completo || p.endereco_destino,
            taxa_entrega: Number(p.taxa_entrega || 0),
            subtotal: Number(p.subtotal || p.total),
            total: Number(p.total),
            status: p.status,
            status_pagamento: p.status_pagamento || 'pendente',
            metodo_pagamento: p.metodo_pagamento || p.forma_pagamento || 'pix_online',
            forma_pagamento: p.forma_pagamento || p.metodo_pagamento || 'pix_online',
            troco_para: p.troco_para ? Number(p.troco_para) : undefined,
            impresso: Boolean(p.impresso),
            created_at: p.created_at,
            itens: (p.itens || []).map((i: any) => ({
              id: i.id,
              pedido_id: p.id,
              produto_id: i.produto_id,
              produto_nome: i.produto_nome || 'Produto',
              quantidade: i.quantidade,
              preco_unitario: Number(i.preco_unitario),
              observacao: i.observacao,
              opcionais: [],
              total_item: Number(i.preco_unitario) * Number(i.quantidade),
            })),
          }));
        }
      } catch (e) {
        console.warn('Fallback para AppStorage getPedidos:', e);
      }
    }
    return AppStorage.getPedidos(lojaId);
  },

  async createPedido(pedido: Pedido): Promise<Pedido> {
    const saved = AppStorage.addPedido(pedido);
    const client = getSupabaseClient();
    if (client) {
      try {
        const { error: pedErr } = await client.from('pedidos').insert({
          id: saved.id,
          loja_id: saved.loja_id,
          cliente_nome: saved.cliente_nome,
          cliente_telefone: saved.cliente_telefone,
          endereco_completo: saved.endereco_destino || saved.endereco_completo || 'Retirada no Balcão',
          taxa_entrega: saved.taxa_entrega,
          total: saved.total,
          forma_pagamento: saved.metodo_pagamento || saved.forma_pagamento,
          status: saved.status,
          created_at: saved.created_at,
        });
        if (!pedErr && saved.itens && saved.itens.length > 0) {
          const itensPayload = saved.itens.map((i) => ({
            id: i.id,
            pedido_id: saved.id,
            produto_id: i.produto_id,
            quantidade: i.quantidade,
            preco_unitario: i.preco_unitario,
            observacao: i.observacao || null,
          }));
          await client.from('itens_pedido').insert(itensPayload);
        }
      } catch (e) {
        console.warn('Erro ao inserir pedido no Supabase:', e);
      }
    }
    return saved;
  },

  async updatePedidoStatus(pedidoId: string, status: OrderStatus): Promise<void> {
    AppStorage.updatePedidoStatus(pedidoId, status);
    const client = getSupabaseClient();
    if (client) {
      try {
        await client
          .from('pedidos')
          .update({ status, updated_at: new Date().toISOString() })
          .eq('id', pedidoId);
      } catch (e) {
        console.warn('Erro ao atualizar status do pedido no Supabase:', e);
      }
    }
  },

  async getSaasPlanSettings(): Promise<SaasPlanSettings> {
    const local = AppStorage.getSaasPlanSettings();
    const client = getSupabaseClient();
    if (client) {
      try {
        const { data, error } = await client
          .from('configuracoes_saas')
          .select('valor')
          .eq('chave', 'plan_settings')
          .single();
        if (!error && data?.valor) {
          const merged = { ...local, ...data.valor };
          AppStorage.saveSaasPlanSettings(merged);
          return merged;
        }
      } catch {}
    }
    return local;
  },

  async saveSaasPlanSettings(settings: Partial<SaasPlanSettings>): Promise<SaasPlanSettings> {
    AppStorage.saveSaasPlanSettings(settings);
    const updated = AppStorage.getSaasPlanSettings();
    const client = getSupabaseClient();
    if (client) {
      try {
        await client.from('configuracoes_saas').upsert({
          chave: 'plan_settings',
          valor: updated,
          updated_at: new Date().toISOString(),
        });
      } catch (e) {
        console.warn('Fallback: configuracoes_saas salvo no storage local (Supabase:', e, ')');
      }
    }
    return updated;
  },

  async atualizarValorMensalidade(lojaId: string, valor: number): Promise<void> {
    AppStorage.atualizarValorMensalidade(lojaId, valor);
    const client = getSupabaseClient();
    if (client) {
      try {
        await client.from('saas_assinaturas').update({ valor }).eq('loja_id', lojaId);
      } catch (e) {
        console.warn('Erro ao atualizar mensalidade no Supabase:', e);
      }
    }
  },

  async getSaasBranding(): Promise<SaasBranding> {
    const local = AppStorage.getSaasBranding();
    const client = getSupabaseClient();
    if (client) {
      try {
        const { data, error } = await client
          .from('configuracoes_saas')
          .select('valor')
          .eq('chave', 'armonix_store_branding')
          .single();
        if (!error && data?.valor) {
          const merged = { ...local, ...data.valor };
          AppStorage.saveSaasBranding(merged);
          return merged;
        }
      } catch {}
    }
    return local;
  },

  async saveSaasBranding(branding: Partial<SaasBranding>): Promise<SaasBranding> {
    AppStorage.saveSaasBranding(branding);
    const updated = AppStorage.getSaasBranding();
    const client = getSupabaseClient();
    if (client) {
      try {
        await client.from('configuracoes_saas').upsert({
          chave: 'armonix_store_branding',
          valor: updated,
          updated_at: new Date().toISOString(),
        });
      } catch (e) {
        console.warn('Fallback: branding salvo no storage local (Supabase:', e, ')');
      }
    }
    return updated;
  },

  async atualizarTempoTesteLoja(lojaId: string, diasTeste: number): Promise<boolean> {
    AppStorage.atualizarTempoTesteLoja(lojaId, diasTeste);
    const client = getSupabaseClient();
    if (client) {
      try {
        const dias = Math.max(0, Math.floor(diasTeste));
        const novaDataVencimento = new Date(Date.now() + dias * 24 * 3600 * 1000).toISOString();
        await client
          .from('saas_assinaturas')
          .update({
            dias_teste: dias,
            data_vencimento: novaDataVencimento,
            status: 'ativa',
          })
          .eq('loja_id', lojaId);

        await client
          .from('lojas')
          .update({
            status_conta: 'ativa',
            updated_at: new Date().toISOString(),
          })
          .eq('id', lojaId);
      } catch (e) {
        console.warn('Erro ao sincronizar dias de teste com Supabase:', e);
      }
    }
    return true;
  },
};

export default DataService;

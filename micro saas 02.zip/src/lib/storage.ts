import {
  Loja,
  SaasAssinatura,
  Categoria,
  Produto,
  Pedido,
  Cliente,
  SaasPaymentLog,
  StorageMetrics,
  OrderStatus,
  PrinterConfig,
  BannerOfertaConfig,
  SupabaseConfig,
  AvisoGlobal,
  SaasPlanSettings,
  SaasBranding,
} from '../types';
import { sanitizeSlug } from './slug';

const STORAGE_KEY = 'delivery_saas_multi_tenant_db_v2';
const ACTIVE_STORE_KEY = 'delivery_saas_loja_ativa_id';
const SUPABASE_CONFIG_KEY = 'delivery_saas_supabase_config';
const AVISOS_GLOBAIS_KEY = 'delivery_saas_avisos_globais_v1';
const SAAS_PLAN_SETTINGS_KEY = 'delivery_saas_plan_settings_v1';
const SAAS_BRANDING_KEY = 'delivery_saas_armonix_branding_v1';

export function generateUUID(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    try {
      return crypto.randomUUID();
    } catch {}
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

const DEFAULT_PLAN_SETTINGS: SaasPlanSettings = {
  dias_teste_padrao: 7,
  renovacao_antecipada_dias: 7,
  renovacao_antecipada_desconto_percentual: 15,
  valor_mensal_padrao: 169.99,
  pix_tipo_chave: 'cnpj',
  pix_chave: '45.123.456/0001-89',
  pix_titular: 'Delivery SaaS Tecnologia & Pagamentos Ltda',
  pix_banco: 'Banco Inter S.A. (077)',
  mercadopago_access_token: '',
  abacatepay_api_key: '',
};

const DEFAULT_BRANDING: SaasBranding = {
  logo_url: '',
  banner_url: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1200&auto=format&fit=crop&q=80',
  nome_marca: 'ARMONIX STORE',
  subtitulo: 'Plataforma de Delivery & Catálogo Digital',
  titulo_principal: 'Veja como sua loja pode ficar na internet',
  badge_destaque: 'Modelos Prontos • Simulação Completa em Tela Cheia',
  cor_primaria: '#dc2626',
  imagem_hero: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1200&auto=format&fit=crop&q=80',
  texto_chamada: 'Você pode ter uma página exclusiva e personalizada para sua empresa, com seus próprios produtos, fotos de alta qualidade, preços, cores, horários e link direto para o seu WhatsApp e painel de pedidos.',
  texto_botao: 'Criar Meu Painel Agora',
  imagens_vitrine: {},
};

const DEFAULT_AVISOS: AvisoGlobal[] = [
  {
    id: 'aviso-1',
    titulo: 'Novidade: Impressão Térmica Automática e Banner de Ofertas',
    mensagem:
      'Agora você pode configurar a auto-impressão de pedidos em 80mm e 58mm diretamente na sua impressora térmica, e personalizar o Banner de Ofertas do Dia no seu cardápio!',
    tipo: 'informativo',
    ativo: true,
    data_criacao: new Date().toISOString(),
  },
];

interface AppDatabase {
  lojas: Loja[];
  assinaturas: SaasAssinatura[];
  categorias: Categoria[];
  produtos: Produto[];
  pedidos: Pedido[];
  clientes: Cliente[];
  pagamentosSaas: SaasPaymentLog[];
  metrics: StorageMetrics;
}

export const DEMO_STORE: Loja = {
  id: 'loja-demo',
  user_id: 'user-demo',
  nome_loja: 'Burger & Grill Prime (Demonstração)',
  nome: 'Burger & Grill Prime (Demonstração)',
  slug: 'demo',
  telefone_whatsapp: '11999998888',
  whatsapp: '11999998888',
  endereco_origem: {
    lat: -23.561684,
    lng: -46.655981,
    endereco_texto: 'Av. Paulista, 1578 - Bela Vista, São Paulo - SP',
  },
  chave_pix: 'pix@cardapiodemo.com.br',
  taxa_base_entrega: 4.9,
  valor_por_km: 1.5,
  status_conta: 'ativa',
  email: 'demo@cardapiodelivery.com',
  senha: 'demo',
  logo_url: 'https://images.unsplash.com/photo-1550547660-d9450f859349?w=150&auto=format&fit=crop&q=80',
  cor_primaria: '#ea580c',
  aberto: true,
  impressora_largura: '80mm',
  impressora_fonte: 'normal',
  impressora_vias: 1,
  impressora_auto_imprimir: false,
  banner_oferta: {
    ativo: true,
    produto_id: 'prod-demo-combo-1',
    titulo: 'Festival Smash Burger Prime • 20% OFF',
    descricao: 'Carne 100% Angus ultra prensada com crostinha crocante na chapa, queijo cheddar inglês cremoso derretido, tiras de bacon artesanal e pão brioche dourado na manteiga.',
    badge_texto: '🔥 OFERTA DO DIA',
    imagem_url: 'https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?w=600&auto=format&fit=crop&q=80',
  },
  created_at: new Date().toISOString(),
};

export const DEMO_ASSINATURA: SaasAssinatura = {
  id: 'ass-demo',
  loja_id: 'loja-demo',
  status: 'ativa',
  plano: 'mensal',
  valor: 169.99,
  data_vencimento: new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString(),
  dias_teste: 7,
  created_at: new Date().toISOString(),
};

export const DEMO_CATEGORIAS: Categoria[] = [
  { id: 'cat-demo-combos', loja_id: 'loja-demo', nome: 'Combos & Ofertas', ordem: 1, ativa: true, icone: 'Flame', created_at: new Date().toISOString() },
  { id: 'cat-demo-burgers', loja_id: 'loja-demo', nome: 'Smash Burgers Artesanais', ordem: 2, ativa: true, icone: 'Utensils', created_at: new Date().toISOString() },
  { id: 'cat-demo-porcoes', loja_id: 'loja-demo', nome: 'Batatas & Acompanhamentos', ordem: 3, ativa: true, icone: 'UtensilsCrossed', created_at: new Date().toISOString() },
  { id: 'cat-demo-sobremesas', loja_id: 'loja-demo', nome: 'Sobremesas & Shakes', ordem: 4, ativa: true, icone: 'Sparkles', created_at: new Date().toISOString() },
  { id: 'cat-demo-bebidas', loja_id: 'loja-demo', nome: 'Bebidas Geladas & Sucos', ordem: 5, ativa: true, icone: 'Beer', created_at: new Date().toISOString() },
];

export const DEMO_PRODUTOS: Produto[] = [
  {
    id: 'prod-demo-combo-1',
    loja_id: 'loja-demo',
    categoria_id: 'cat-demo-combos',
    nome: 'Combo Smash Prime + Fritas + Bebida',
    descricao: '1 Smash Burger Angus 160g com queijo cheddar cremoso e bacon crocante no pão brioche + 1 Porção Individual de Batata Frita Crocante + 1 Refrigerante Lata 350ml geladinho.',
    preco: 44.9,
    preco_promocional: 36.9,
    preco_original: 'R$ 44,90',
    imagem_url: 'https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?w=600&auto=format&fit=crop&q=80',
    destaque_oferta: true,
    destaque_mais_pedido: true,
    disponivel: true,
    ativo: true,
    created_at: new Date().toISOString(),
    opcionais: [
      { id: 'op-demo-1', nome_opcao: 'Adicionar Bacon Extra (+30g)', preco_adicional: 5.0, obrigatorio: false },
      { id: 'op-demo-2', nome_opcao: 'Turbinar Batata com Cheddar & Bacon', preco_adicional: 6.5, obrigatorio: false },
      { id: 'op-demo-3', nome_opcao: 'Refrigerante Coca-Cola Normal', preco_adicional: 0.0, obrigatorio: false },
      { id: 'op-demo-4', nome_opcao: 'Refrigerante Guaraná Antarctica', preco_adicional: 0.0, obrigatorio: false },
    ],
  },
  {
    id: 'prod-demo-combo-2',
    loja_id: 'loja-demo',
    categoria_id: 'cat-demo-combos',
    nome: 'Combo Casal Smash 2 Burgers + Batata Grande',
    descricao: '2 Deliciosos Smash Burgers Angus com cheddar e cebola caramelizada + 1 Porção Média de Batata Rústica para compartilhar + 2 Latas de Bebidas.',
    preco: 82.9,
    preco_promocional: 69.9,
    preco_original: 'R$ 82,90',
    imagem_url: 'https://images.unsplash.com/photo-1561758033-d89a9ad46330?w=600&auto=format&fit=crop&q=80',
    destaque_oferta: true,
    destaque_mais_pedido: true,
    disponivel: true,
    ativo: true,
    created_at: new Date().toISOString(),
    opcionais: [],
  },
  {
    id: 'prod-demo-burger-1',
    loja_id: 'loja-demo',
    categoria_id: 'cat-demo-burgers',
    nome: 'Gran Picanha Artesanal 180g',
    descricao: 'Pão brioche selado na manteiga de garrafa, blend de picanha 180g grelhado na brasa, queijo provolone derretido, chimichurri argentino fresco e maionese defumada.',
    preco: 38.9,
    preco_promocional: 34.9,
    preco_original: 'R$ 38,90',
    imagem_url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80',
    destaque_oferta: true,
    destaque_mais_pedido: true,
    disponivel: true,
    ativo: true,
    created_at: new Date().toISOString(),
    opcionais: [
      { id: 'op-demo-5', nome_opcao: 'Ponto da Carne: Ao Ponto Suculento', preco_adicional: 0.0, obrigatorio: false },
      { id: 'op-demo-6', nome_opcao: 'Molho Chimichurri em Pote Extra', preco_adicional: 3.5, obrigatorio: false },
    ],
  },
  {
    id: 'prod-demo-burger-2',
    loja_id: 'loja-demo',
    categoria_id: 'cat-demo-burgers',
    nome: 'Smash Bacon Melt Supremo',
    descricao: 'Dois smash burgers prensados com crosta caramelizada, dobro de queijo cheddar inglês derretido, tiras crocantes de bacon artesanal e maionese da casa.',
    preco: 36.9,
    imagem_url: 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=600&auto=format&fit=crop&q=80',
    destaque_oferta: false,
    destaque_mais_pedido: true,
    disponivel: true,
    ativo: true,
    created_at: new Date().toISOString(),
    opcionais: [],
  },
  {
    id: 'prod-demo-burger-3',
    loja_id: 'loja-demo',
    categoria_id: 'cat-demo-burgers',
    nome: 'Royal Trufado com Queijo Brie',
    descricao: 'Blend Angus 160g, queijo brie maçaricado, cogumelos shimeji salteados na manteiga trufada e maionese especial no pão australiano.',
    preco: 42.9,
    imagem_url: 'https://images.unsplash.com/photo-1550547660-d9450f859349?w=600&auto=format&fit=crop&q=80',
    destaque_oferta: false,
    destaque_mais_pedido: false,
    disponivel: true,
    ativo: true,
    created_at: new Date().toISOString(),
    opcionais: [],
  },
  {
    id: 'prod-demo-porcao-1',
    loja_id: 'loja-demo',
    categoria_id: 'cat-demo-porcoes',
    nome: 'Batata Rústica com Alecrim & Parmesão',
    descricao: 'Batatas selecionadas com casca cortadas em gomos rústicos, temperadas com sal marinho, alecrim fresco da horta e lascas de queijo parmesão maturado.',
    preco: 24.9,
    imagem_url: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=600&auto=format&fit=crop&q=80',
    destaque_oferta: false,
    destaque_mais_pedido: true,
    disponivel: true,
    ativo: true,
    created_at: new Date().toISOString(),
    opcionais: [],
  },
  {
    id: 'prod-demo-porcao-2',
    loja_id: 'loja-demo',
    categoria_id: 'cat-demo-porcoes',
    nome: 'Chicken Crispy Goujons (8 un)',
    descricao: 'Tiras suculentas de peito de frango marinadas com especiarias e empanadas em farinha panko ultra crocante. Acompanha molho barbecue artesanal.',
    preco: 28.9,
    imagem_url: 'https://images.unsplash.com/photo-1562967914-608f82629710?w=600&auto=format&fit=crop&q=80',
    destaque_oferta: false,
    destaque_mais_pedido: false,
    disponivel: true,
    ativo: true,
    created_at: new Date().toISOString(),
    opcionais: [],
  },
  {
    id: 'prod-demo-sobremesa-1',
    loja_id: 'loja-demo',
    categoria_id: 'cat-demo-sobremesas',
    nome: 'Milkshake Especial Nutella & Ninho 500ml',
    descricao: 'Sorvete artesanal batido com leite Ninho em pó e generosa cascata de Nutella pura na borda do copo. Finalizado com chantilly aerado.',
    preco: 22.9,
    imagem_url: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=600&auto=format&fit=crop&q=80',
    destaque_oferta: false,
    destaque_mais_pedido: true,
    disponivel: true,
    ativo: true,
    created_at: new Date().toISOString(),
    opcionais: [],
  },
  {
    id: 'prod-demo-sobremesa-2',
    loja_id: 'loja-demo',
    categoria_id: 'cat-demo-sobremesas',
    nome: 'Petit Gâteau com Sorvete de Baunilha',
    descricao: 'Bolo quente de chocolate meio amargo com recheio cremoso e fluído. Acompanha bola generosa de sorvete de baunilha Bourbon e calda quente.',
    preco: 25.9,
    imagem_url: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=600&auto=format&fit=crop&q=80',
    destaque_oferta: false,
    destaque_mais_pedido: false,
    disponivel: true,
    ativo: true,
    created_at: new Date().toISOString(),
    opcionais: [],
  },
  {
    id: 'prod-demo-bebida-1',
    loja_id: 'loja-demo',
    categoria_id: 'cat-demo-bebidas',
    nome: 'Coca-Cola Original 350ml Lata Gelada',
    descricao: 'Lata 350ml servida trincando de gelada.',
    preco: 6.9,
    imagem_url: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=600&auto=format&fit=crop&q=80',
    destaque_oferta: false,
    destaque_mais_pedido: false,
    disponivel: true,
    ativo: true,
    created_at: new Date().toISOString(),
    opcionais: [],
  },
  {
    id: 'prod-demo-bebida-2',
    loja_id: 'loja-demo',
    categoria_id: 'cat-demo-bebidas',
    nome: 'Suco Natural de Laranja Integral 500ml',
    descricao: '100% natural, espremido na hora, sem adição de água ou conservantes.',
    preco: 9.9,
    imagem_url: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?w=600&auto=format&fit=crop&q=80',
    destaque_oferta: false,
    destaque_mais_pedido: false,
    disponivel: true,
    ativo: true,
    created_at: new Date().toISOString(),
    opcionais: [],
  },
  {
    id: 'prod-demo-bebida-3',
    loja_id: 'loja-demo',
    categoria_id: 'cat-demo-bebidas',
    nome: 'Chopp Artesanal IPA 500ml Copo Térmico',
    descricao: 'Chopp artesanal estilo American IPA com amargor cítrico marcante e aroma floral intenso. Servido em copo térmico.',
    preco: 16.9,
    imagem_url: 'https://images.unsplash.com/photo-1535958636474-b021ee887b13?w=600&auto=format&fit=crop&q=80',
    destaque_oferta: false,
    destaque_mais_pedido: false,
    disponivel: true,
    ativo: true,
    created_at: new Date().toISOString(),
    opcionais: [],
  },
];

export function gerarItensPadraoPorSegmento(
  lojaId: string,
  segmentoRaw?: string
): { categorias: Categoria[]; produtos: Produto[] } {
  const seg = (segmentoRaw || 'hamburgueria').toLowerCase().trim();
  const agora = new Date().toISOString();

  if (seg.includes('pizza')) {
    const catPizzas: Categoria = {
      id: `cat-${lojaId}-pizzas`,
      loja_id: lojaId,
      nome: 'Pizzas Tradicionais & Especiais',
      ordem: 1,
      ativa: true,
      created_at: agora,
    };
    const catDoces: Categoria = {
      id: `cat-${lojaId}-doces`,
      loja_id: lojaId,
      nome: 'Pizzas Doces',
      ordem: 2,
      ativa: true,
      created_at: agora,
    };
    const catBebidas: Categoria = {
      id: `cat-${lojaId}-bebidas`,
      loja_id: lojaId,
      nome: 'Bebidas Geladas',
      ordem: 3,
      ativa: true,
      created_at: agora,
    };

    const produtos: Produto[] = [
      {
        id: `prod-${lojaId}-p1`,
        loja_id: lojaId,
        categoria_id: catPizzas.id,
        nome: 'Pizza Calabresa Especial com Cebola Roxa',
        descricao: 'Molho pelati artesanal, muçarela derretida, calabresa defumada fatiada fininha, cebola roxa e orégano fresco.',
        preco: 58.9,
        preco_promocional: 49.9,
        imagem_url: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600&auto=format&fit=crop&q=80',
        destaque_oferta: true,
        destaque_mais_pedido: true,
        disponivel: true,
        ativo: true,
        created_at: agora,
      },
      {
        id: `prod-${lojaId}-p2`,
        loja_id: lojaId,
        categoria_id: catPizzas.id,
        nome: 'Pizza Quatro Queijos Nobres',
        descricao: 'Muçarela, catupiry original, provolone defumado e parmesão curado crocante.',
        preco: 64.9,
        imagem_url: 'https://images.unsplash.com/photo-1573821663912-569905455b1c?w=600&auto=format&fit=crop&q=80',
        destaque_oferta: false,
        destaque_mais_pedido: true,
        disponivel: true,
        ativo: true,
        created_at: agora,
      },
      {
        id: `prod-${lojaId}-p3`,
        loja_id: lojaId,
        categoria_id: catDoces.id,
        nome: 'Pizza Doce Morango com Chocolate Meio Amargo',
        descricao: 'Base crocante com camada generosa de ganache de chocolate e morangos frescos fatiados.',
        preco: 42.0,
        imagem_url: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=600&auto=format&fit=crop&q=80',
        destaque_oferta: false,
        destaque_mais_pedido: false,
        disponivel: true,
        ativo: true,
        created_at: agora,
      },
      {
        id: `prod-${lojaId}-p4`,
        loja_id: lojaId,
        categoria_id: catBebidas.id,
        nome: 'Refrigerante 2 Litros Bem Gelado',
        descricao: 'Garrafa pet 2L clássica servida trincando de gelada.',
        preco: 14.0,
        imagem_url: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=600&auto=format&fit=crop&q=80',
        destaque_oferta: false,
        destaque_mais_pedido: false,
        disponivel: true,
        ativo: true,
        created_at: agora,
      },
    ];

    return { categorias: [catPizzas, catDoces, catBebidas], produtos };
  }

  if (seg.includes('sushi') || seg.includes('japones')) {
    const catCombos: Categoria = {
      id: `cat-${lojaId}-combos`,
      loja_id: lojaId,
      nome: 'Combos & Barcas',
      ordem: 1,
      ativa: true,
      created_at: agora,
    };
    const catTemakis: Categoria = {
      id: `cat-${lojaId}-temakis`,
      loja_id: lojaId,
      nome: 'Temakis Especiais',
      ordem: 2,
      ativa: true,
      created_at: agora,
    };
    const catHot: Categoria = {
      id: `cat-${lojaId}-hot`,
      loja_id: lojaId,
      nome: 'Hot Rolls & Entradas',
      ordem: 3,
      ativa: true,
      created_at: agora,
    };

    const produtos: Produto[] = [
      {
        id: `prod-${lojaId}-s1`,
        loja_id: lojaId,
        categoria_id: catCombos.id,
        nome: 'Combo Salmão Supremo 30 Peças',
        descricao: '10 sashimis de salmão fresco, 8 uramakis, 6 niguiris e 6 hots crocantes com tarê e gergelim tostado.',
        preco: 89.9,
        preco_promocional: 79.9,
        imagem_url: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=600&auto=format&fit=crop&q=80',
        destaque_oferta: true,
        destaque_mais_pedido: true,
        disponivel: true,
        ativo: true,
        created_at: agora,
      },
      {
        id: `prod-${lojaId}-s2`,
        loja_id: lojaId,
        categoria_id: catTemakis.id,
        nome: 'Temaki Salmão em Cubos com Cream Cheese',
        descricao: 'Alga crocante, arroz temperado suave, salmão fresco em cubos e cebolinha verde.',
        preco: 31.9,
        imagem_url: 'https://images.unsplash.com/photo-1617196034796-73dfa7b1fd56?w=600&auto=format&fit=crop&q=80',
        destaque_oferta: false,
        destaque_mais_pedido: true,
        disponivel: true,
        ativo: true,
        created_at: agora,
      },
      {
        id: `prod-${lojaId}-s3`,
        loja_id: lojaId,
        categoria_id: catHot.id,
        nome: 'Hot Roll Especial Crocante 10 Peças',
        descricao: 'Enrolado frito com salmão e cream cheese, empanado na farinha panko, finalizado com molho tarê.',
        preco: 26.0,
        imagem_url: 'https://images.unsplash.com/photo-1611143669185-af224c5e3252?w=600&auto=format&fit=crop&q=80',
        destaque_oferta: false,
        destaque_mais_pedido: false,
        disponivel: true,
        ativo: true,
        created_at: agora,
      },
    ];

    return { categorias: [catCombos, catTemakis, catHot], produtos };
  }

  if (seg.includes('acai') || seg.includes('açaí') || seg.includes('sorvet')) {
    const catCopos: Categoria = {
      id: `cat-${lojaId}-copos`,
      loja_id: lojaId,
      nome: 'Copos de Açaí Cremoso',
      ordem: 1,
      ativa: true,
      created_at: agora,
    };
    const catBarcas: Categoria = {
      id: `cat-${lojaId}-barcas`,
      loja_id: lojaId,
      nome: 'Barcas & Taças Especiais',
      ordem: 2,
      ativa: true,
      created_at: agora,
    };
    const catBebidas: Categoria = {
      id: `cat-${lojaId}-bebidas-acai`,
      loja_id: lojaId,
      nome: 'Picolés & Bebidas',
      ordem: 3,
      ativa: true,
      created_at: agora,
    };

    const produtos: Produto[] = [
      {
        id: `prod-${lojaId}-a1`,
        loja_id: lojaId,
        categoria_id: catCopos.id,
        nome: 'Copo Açaí Tradicional 500ml Turbinado',
        descricao: 'Açaí puro batido com xarope de guaraná, leite condensado, leite Ninho, banana e morango fatiado.',
        preco: 23.9,
        preco_promocional: 19.9,
        imagem_url: 'https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?w=600&auto=format&fit=crop&q=80',
        destaque_oferta: true,
        destaque_mais_pedido: true,
        disponivel: true,
        ativo: true,
        created_at: agora,
      },
      {
        id: `prod-${lojaId}-a2`,
        loja_id: lojaId,
        categoria_id: catBarcas.id,
        nome: 'Barca Suprema de Açaí Especial (1 Litro)',
        descricao: 'Serve até 3 pessoas. Açaí batido na hora com morango, kiwi, granola artesanal, Nutella e leite Ninho.',
        preco: 49.9,
        imagem_url: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=600&auto=format&fit=crop&q=80',
        destaque_oferta: false,
        destaque_mais_pedido: true,
        disponivel: true,
        ativo: true,
        created_at: agora,
      },
      {
        id: `prod-${lojaId}-a3`,
        loja_id: lojaId,
        categoria_id: catBebidas.id,
        nome: 'Suco Natural de Laranja 500ml',
        descricao: 'Feito na hora com laranjas frescas selecionadas.',
        preco: 8.5,
        imagem_url: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?w=600&auto=format&fit=crop&q=80',
        destaque_oferta: false,
        destaque_mais_pedido: false,
        disponivel: true,
        ativo: true,
        created_at: agora,
      },
    ];

    return { categorias: [catCopos, catBarcas, catBebidas], produtos };
  }

  if (seg.includes('restaurante') || seg.includes('marmit')) {
    const catMarmitex: Categoria = {
      id: `cat-${lojaId}-marmitex`,
      loja_id: lojaId,
      nome: 'Marmitex do Dia',
      ordem: 1,
      ativa: true,
      created_at: agora,
    };
    const catExecutivos: Categoria = {
      id: `cat-${lojaId}-executivos`,
      loja_id: lojaId,
      nome: 'Pratos Executivos & Carnes',
      ordem: 2,
      ativa: true,
      created_at: agora,
    };
    const catBebidas: Categoria = {
      id: `cat-${lojaId}-bebidas-almoco`,
      loja_id: lojaId,
      nome: 'Bebidas & Sobremesas',
      ordem: 3,
      ativa: true,
      created_at: agora,
    };

    const produtos: Produto[] = [
      {
        id: `prod-${lojaId}-r1`,
        loja_id: lojaId,
        categoria_id: catMarmitex.id,
        nome: 'Marmitex Executivo Bife Acebolado com Fritas',
        descricao: 'Arroz soltinho, feijão caseiro, bife bovino acebolado grelhado, batata frita e farofa crocante.',
        preco: 26.9,
        preco_promocional: 22.9,
        imagem_url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=80',
        destaque_oferta: true,
        destaque_mais_pedido: true,
        disponivel: true,
        ativo: true,
        created_at: agora,
      },
      {
        id: `prod-${lojaId}-r2`,
        loja_id: lojaId,
        categoria_id: catExecutivos.id,
        nome: 'Filé de Frango Grelhado com Salada Caesar',
        descricao: 'Peito de frango marinado em ervas finas, mix de folhas verdes, tomates cereja e molho caesar.',
        preco: 28.5,
        imagem_url: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=600&auto=format&fit=crop&q=80',
        destaque_oferta: false,
        destaque_mais_pedido: true,
        disponivel: true,
        ativo: true,
        created_at: agora,
      },
    ];

    return { categorias: [catMarmitex, catExecutivos, catBebidas], produtos };
  }

  if (seg.includes('bebida') || seg.includes('distribuidora')) {
    const catCervejas: Categoria = {
      id: `cat-${lojaId}-cervejas`,
      loja_id: lojaId,
      nome: 'Cervejas Trincando de Geladas',
      ordem: 1,
      ativa: true,
      created_at: agora,
    };
    const catDestilados: Categoria = {
      id: `cat-${lojaId}-destilados`,
      loja_id: lojaId,
      nome: 'Destilados & Combos',
      ordem: 2,
      ativa: true,
      created_at: agora,
    };
    const catGelo: Categoria = {
      id: `cat-${lojaId}-gelo`,
      loja_id: lojaId,
      nome: 'Gelo, Carvão & Conveniência',
      ordem: 3,
      ativa: true,
      created_at: agora,
    };

    const produtos: Produto[] = [
      {
        id: `prod-${lojaId}-b1`,
        loja_id: lojaId,
        categoria_id: catCervejas.id,
        nome: 'Pack Cerveja Heineken 6 Long Necks 330ml',
        descricao: 'Cerveja puro malte gelada no ponto certo para consumo imediato.',
        preco: 44.9,
        preco_promocional: 39.9,
        imagem_url: 'https://images.unsplash.com/photo-1608270546124-7eb3e6ef6d7f?w=600&auto=format&fit=crop&q=80',
        destaque_oferta: true,
        destaque_mais_pedido: true,
        disponivel: true,
        ativo: true,
        created_at: agora,
      },
      {
        id: `prod-${lojaId}-b2`,
        loja_id: lojaId,
        categoria_id: catDestilados.id,
        nome: 'Combo Gin Tanqueray 750ml + 4 Tônicas',
        descricao: 'Garrafa original selada com 4 latas de água tônica e fatias de especiarias.',
        preco: 129.0,
        imagem_url: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?w=600&auto=format&fit=crop&q=80',
        destaque_oferta: false,
        destaque_mais_pedido: true,
        disponivel: true,
        ativo: true,
        created_at: agora,
      },
      {
        id: `prod-${lojaId}-b3`,
        loja_id: lojaId,
        categoria_id: catGelo.id,
        nome: 'Saco de Gelo Filtrado em Cubos 5kg',
        descricao: 'Gelo potável com selo de qualidade para drinks e churrasco.',
        preco: 12.0,
        imagem_url: 'https://images.unsplash.com/photo-1549488344-1f9b8d2bd1f3?w=600&auto=format&fit=crop&q=80',
        destaque_oferta: false,
        destaque_mais_pedido: false,
        disponivel: true,
        ativo: true,
        created_at: agora,
      },
    ];

    return { categorias: [catCervejas, catDestilados, catGelo], produtos };
  }

  // Padrão: Hamburgueria & Lanches
  const catBurgers: Categoria = {
    id: `cat-${lojaId}-burgers`,
    loja_id: lojaId,
    nome: 'Burgers Artesanais',
    ordem: 1,
    ativa: true,
    created_at: agora,
  };
  const catCombos: Categoria = {
    id: `cat-${lojaId}-combos-lanche`,
    loja_id: lojaId,
    nome: 'Combos & Ofertas',
    ordem: 2,
    ativa: true,
    created_at: agora,
  };
  const catPorcoes: Categoria = {
    id: `cat-${lojaId}-porcoes`,
    loja_id: lojaId,
    nome: 'Porções & Bebidas',
    ordem: 3,
    ativa: true,
    created_at: agora,
  };

  const produtos: Produto[] = [
    {
      id: `prod-${lojaId}-h1`,
      loja_id: lojaId,
      categoria_id: catBurgers.id,
      nome: 'Smash Cheddar Duplo Bacon',
      descricao: 'Dois discos de 100g de carne Angus ultra selados na chapa com crostinha crocante, queijo cheddar cremoso e fatias crocantes de bacon.',
      preco: 36.9,
      preco_promocional: 29.9,
      imagem_url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80',
      destaque_oferta: true,
      destaque_mais_pedido: true,
      disponivel: true,
      ativo: true,
      created_at: agora,
    },
    {
      id: `prod-${lojaId}-h2`,
      loja_id: lojaId,
      categoria_id: catCombos.id,
      nome: 'Combo Smash Especial + Batata Frita + Refrigerante',
      descricao: 'Burger artesanal completo acompanhado de porção individual de batata frita dourada e lata de refrigerante 350ml.',
      preco: 46.9,
      preco_promocional: 39.9,
      imagem_url: 'https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?w=600&auto=format&fit=crop&q=80',
      destaque_oferta: true,
      destaque_mais_pedido: true,
      disponivel: true,
      ativo: true,
      created_at: agora,
    },
    {
      id: `prod-${lojaId}-h3`,
      loja_id: lojaId,
      categoria_id: catPorcoes.id,
      nome: 'Batata Rústica com Alecrim e Páprica',
      descricao: 'Batatas com corte especial rústico temperadas com flor de sal e páprica defumada.',
      preco: 18.0,
      imagem_url: 'https://images.unsplash.com/photo-1576107232684-1279f3908594?w=600&auto=format&fit=crop&q=80',
      destaque_oferta: false,
      destaque_mais_pedido: false,
      disponivel: true,
      ativo: true,
      created_at: agora,
    },
  ];

  return { categorias: [catBurgers, catCombos, catPorcoes], produtos };
}

const DEFAULT_DB: AppDatabase = {
  lojas: [
    DEMO_STORE,
    {
      id: 'loja-brasa',
      user_id: 'user-brasa',
      nome_loja: 'Brasa & Sabor Delivery',
      nome: 'Brasa & Sabor Delivery',
      slug: 'brasa-sabor',
      telefone_whatsapp: '67981163697',
      whatsapp: '67981163697',
      endereco_origem: {
        lat: -20.4697,
        lng: -54.6201,
        endereco_texto: 'Rua do Carimbo, 488 - Campo Grande, MS',
      },
      chave_pix: '67981163697',
      mercadopago_access_token: 'TEST-9921829103-mp',
      abacatepay_api_key: 'aba_prod_9918231',
      taxa_base_entrega: 5.9,
      valor_por_km: 1.8,
      status_conta: 'ativa',
      email: 'contato@brasaesabor.com.br',
      senha: '123456',
      logo_url: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=150&auto=format&fit=crop&q=80',
      cor_primaria: '#dc2626',
      aberto: true,
      impressora_largura: '80mm',
      impressora_fonte: 'normal',
      impressora_vias: 1,
      impressora_auto_imprimir: false,
      banner_oferta: {
        ativo: true,
        produto_id: 'prod-brasa-1',
        titulo: 'Festival do Smash Burger',
        descricao: 'Carne 100% Angus com crostinha crocante ultra selada na chapa, queijo cheddar inglês derretido e pão brioche amanteigado. Aproveite 15% OFF nesta semana!',
        badge_texto: '# Oferta do Dia',
        imagem_url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80',
      },
      created_at: new Date(Date.now() - 60 * 24 * 3600 * 1000).toISOString(),
    },
  ],
  assinaturas: [
    DEMO_ASSINATURA,
    {
      id: 'ass-brasa',
      loja_id: 'loja-brasa',
      status: 'ativa',
      plano: 'mensal',
      valor: 169.99,
      data_vencimento: new Date(Date.now() + 25 * 24 * 3600 * 1000).toISOString(),
      ultimo_pagamento: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString(),
      created_at: new Date(Date.now() - 60 * 24 * 3600 * 1000).toISOString(),
    },
  ],
  // Cardápio limpo: categorias e produtos vazios por padrão para o lojista criar seus próprios itens
  categorias: [],
  produtos: [],
  clientes: [
    {
      id: 'cli-1',
      loja_id: 'loja-brasa',
      nome: 'Carlos Eduardo Silva',
      telefone: '67981163697',
      endereco: 'Rua das Palmeiras',
      numero: '340',
      complemento: 'Apto 12B',
      bairro: 'Bela Vista / Paulista',
      created_at: new Date().toISOString(),
    },
  ],
  pedidos: [],
  pagamentosSaas: [],
  metrics: {
    db_size_bytes: 48000,
    db_size_mb: 0.05,
    db_limit_mb: 500,
    photos_size_mb: 1.2,
    photos_limit_mb: 1000,
    total_pedidos: 1,
    pedidos_antigos_elegiveis: 0,
  },
};

function notifyEvent(action: string, detail?: any) {
  if (typeof window !== 'undefined') {
    try {
      window.dispatchEvent(new CustomEvent('app_storage_change', { detail: { action, ...detail } }));
    } catch {}
  }
}

export const DEFAULT_CLEAN_TENANT: Loja = {
  id: 'loja-aroma-sabor',
  user_id: 'user-aroma-sabor',
  nome_loja: 'Aroma & Sabor Hamburgueria',
  nome: 'Aroma & Sabor Hamburgueria',
  slug: 'aroma-e-sabor',
  telefone_whatsapp: '11999998888',
  whatsapp: '11999998888',
  created_at: new Date().toISOString(),
  endereco_origem: {
    lat: -20.4697,
    lng: -54.6201,
    endereco_texto: 'Av. Afonso Pena, 1500 - Centro, Campo Grande - MS',
  },
  chave_pix: 'pix@aromaesabor.com.br',
  taxa_base_entrega: 5.0,
  valor_por_km: 1.5,
  status_conta: 'ativa',
  email: 'contato@aromaesabor.com.br',
  senha: '123',
  logo_url: 'https://images.unsplash.com/photo-1550547660-d9450f859349?w=150&auto=format&fit=crop&q=80',
  cor_primaria: '#ea580c',
  aberto: true,
  impressora_largura: '80mm',
  impressora_fonte: 'normal',
  impressora_vias: 1,
  impressora_auto_imprimir: false,
  banner_oferta: {
    ativo: true,
    produto_id: 'prod-padrao-1',
    titulo: 'Smash Burger Artesanal • Oferta da Semana',
    descricao: 'Carne 100% Angus prensada na chapa com crostinha crocante, queijo cheddar inglês derretido, bacon e pão brioche.',
    badge_texto: '# Oferta do Dia',
    imagem_url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80',
  },
};

export const AppStorage = {
  getDB(): AppDatabase {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      let parsed: AppDatabase;
      if (!data) {
        parsed = JSON.parse(JSON.stringify(DEFAULT_DB));
      } else {
        parsed = JSON.parse(data);
      }
      let mudou = false;

      const tenantsRaw = localStorage.getItem('delivery_saas_tenants');
      if (tenantsRaw) {
        try {
          const directTenants = JSON.parse(tenantsRaw);
          if (Array.isArray(directTenants) && directTenants.length > 0) {
            parsed.lojas = directTenants;
          }
        } catch {}
      }

      if (!parsed.lojas || !Array.isArray(parsed.lojas) || parsed.lojas.length === 0) {
        parsed.lojas = [DEFAULT_CLEAN_TENANT];
        mudou = true;
      }
      if (!parsed.clientes) {
        parsed.clientes = DEFAULT_DB.clientes;
        mudou = true;
      }
      if (Array.isArray(parsed.assinaturas)) {
        parsed.assinaturas.forEach((a: SaasAssinatura) => {
          if (!a.valor || a.valor === 97 || a.valor < 169.99) {
            a.valor = 169.99;
            mudou = true;
          }
        });
      }

      // Garante que lojas ativas possuam categorias e produtos mínimos funcionais
      if (Array.isArray(parsed.lojas) && parsed.lojas.length > 0) {
        parsed.lojas.forEach((l: Loja) => {
          const catsLoja = (parsed.categorias || []).filter(
            (c: Categoria) => c.loja_id === l.id || (c as any).store_id === l.id
          );
          if (catsLoja.length === 0) {
            // Inicialização sob demanda
            const geradas = gerarItensPadraoPorSegmento(l.id, l.segmento || 'hamburgueria');
            if (!parsed.categorias) parsed.categorias = [];
            if (!parsed.produtos) parsed.produtos = [];
            parsed.categorias.push(...geradas.categorias);
            parsed.produtos.push(...geradas.produtos);
            mudou = true;
          }
        });
      }

      if (mudou || !data) {
        this.saveDB(parsed);
      }
      return parsed;
    } catch {
      return DEFAULT_DB;
    }
  },

  saveDB(db: AppDatabase): void {
    try {
      if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
        if (Array.isArray(db.lojas)) {
          localStorage.setItem('delivery_saas_tenants', JSON.stringify(db.lojas));
        }
      }
    } catch (e) {
      console.warn('Erro ao salvar no localStorage:', e);
    }
  },

  getActiveLojaId(): string | null {
    try {
      const stored =
        localStorage.getItem('activeTenantId') || localStorage.getItem(ACTIVE_STORE_KEY);
      if (stored) {
        const existe = this.getLojas().some((l) => l.id === stored);
        if (existe) return stored;
      }
      const lojas = this.getLojas();
      if (lojas.length > 0) {
        return lojas[0].id;
      }
      return null;
    } catch {
      return null;
    }
  },

  setActiveLojaId(lojaId: string): void {
    try {
      localStorage.setItem('activeTenantId', lojaId);
      localStorage.setItem(ACTIVE_STORE_KEY, lojaId);
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('loja_ativa_alterada', { detail: { lojaId } }));
        window.dispatchEvent(new CustomEvent('app_storage_change', { detail: { action: 'active_tenant_changed', lojaId } }));
      }
    } catch (e) {
      console.warn('Erro ao salvar loja ativa:', e);
    }
  },

  getActiveLoja(): Loja | undefined {
    const activeId = this.getActiveLojaId();
    if (activeId) {
      const loja = this.getLojaById(activeId);
      if (loja) return loja;
    }
    const todas = this.getLojas();
    return todas[0];
  },

  deleteLoja(lojaIdOuSlug: string): boolean {
    const db = this.getDB();
    const cleanParam = (lojaIdOuSlug || '').toLowerCase().trim();
    if (!cleanParam) return false;

    let lojaIndex = db.lojas.findIndex((l) => l.id === lojaIdOuSlug);
    if (lojaIndex === -1) {
      lojaIndex = db.lojas.findIndex((l) => (l.slug || '').toLowerCase().trim() === cleanParam);
    }
    if (lojaIndex === -1) return false;

    const lojaParaExcluir = db.lojas[lojaIndex];
    const realLojaId = lojaParaExcluir.id;
    const slugLoja = (lojaParaExcluir.slug || '').toLowerCase().trim();

    db.lojas.splice(lojaIndex, 1);
    db.lojas = db.lojas.filter(
      (l) => l.id !== realLojaId && (l.slug || '').toLowerCase().trim() !== slugLoja
    );

    db.assinaturas = db.assinaturas.filter(
      (a) => a.loja_id !== realLojaId && a.loja_id !== slugLoja
    );
    db.produtos = db.produtos.filter(
      (p) =>
        p.loja_id !== realLojaId &&
        (p as any).store_id !== realLojaId &&
        (p as any).tenantId !== realLojaId &&
        p.loja_id !== slugLoja
    );
    db.categorias = db.categorias.filter(
      (c) =>
        c.loja_id !== realLojaId &&
        (c as any).store_id !== realLojaId &&
        (c as any).tenantId !== realLojaId &&
        c.loja_id !== slugLoja
    );
    db.pedidos = db.pedidos.filter(
      (p) =>
        p.loja_id !== realLojaId &&
        (p as any).store_id !== realLojaId &&
        (p as any).tenantId !== realLojaId &&
        p.loja_id !== slugLoja
    );
    db.pagamentosSaas = db.pagamentosSaas.filter(
      (p) => p.loja_id !== realLojaId && p.loja_id !== slugLoja
    );
    if (db.clientes) {
      db.clientes = db.clientes.filter(
        (c) => (c as any).loja_id !== realLojaId && (c as any).loja_id !== slugLoja
      );
    }

    this.saveDB(db);

    if (this.getActiveLojaId() === realLojaId || this.getActiveLojaId() === slugLoja) {
      const proxima = db.lojas[0];
      if (proxima) {
        this.setActiveLojaId(proxima.id);
      } else {
        localStorage.removeItem(ACTIVE_STORE_KEY);
        localStorage.removeItem('activeTenantId');
      }
    }

    notifyEvent('loja_excluida', { lojaId: realLojaId, slug: slugLoja });
    notifyEvent('app_storage_change', { action: 'loja_excluida', lojaId: realLojaId, slug: slugLoja });
    return true;
  },

  getLojas(): Loja[] {
    return this.getDB().lojas;
  },

  getLojaById(id: string): Loja | undefined {
    return this.getLojas().find((l) => l.id === id);
  },

  getLojaBySlug(slug: string): Loja | undefined {
    const raw = decodeURIComponent(slug || '').toLowerCase().trim();
    const limpo = raw.replace(/^\/loja\//, '').replace(/^loja\//, '').replace(/\/$/, '');
    if (limpo === 'demo') {
      const demo = this.getLojas().find((l) => (l.slug || '').toLowerCase().trim() === 'demo');
      return demo || DEMO_STORE;
    }

    const sanitized = sanitizeSlug(limpo);
    const espacado = limpo.replace(/[-_]+/g, ' ').trim();
    const lojas = this.getLojas();

    let loja = lojas.find((l) => {
      const s = (l.slug || '').toLowerCase().trim();
      return s === limpo || s === sanitized || sanitizeSlug(s) === sanitized;
    });

    if (!loja) {
      loja = lojas.find((l) => {
        const nome = (l.nome_loja || l.nome || '').trim();
        const nomeLower = nome.toLowerCase();
        if (sanitizeSlug(nome) === sanitized) return true;
        if (nomeLower.replace(/[\s_-]+/g, '-') === sanitized) return true;
        if (nomeLower === espacado) return true;
        return false;
      });
    }

    if (loja && (!loja.slug || loja.slug.trim() === '')) {
      const novoSlug = sanitized || sanitizeSlug(loja.nome_loja || loja.nome || 'loja');
      this.updateLoja(loja.id, { slug: novoSlug });
      loja.slug = novoSlug;
    }
    return loja;
  },

  saveOrUpdateLojaCache(loja: Loja): void {
    const db = this.getDB();
    const idx = db.lojas.findIndex((l) => l.id === loja.id || l.slug?.toLowerCase().trim() === loja.slug?.toLowerCase().trim());
    if (idx !== -1) {
      db.lojas[idx] = { ...db.lojas[idx], ...loja };
    } else {
      db.lojas.push(loja);
    }
    this.saveDB(db);
  },

  saveCategoriasCache(lojaId: string, categorias: Categoria[]): void {
    const db = this.getDB();
    db.categorias = db.categorias.filter((c) => c.loja_id !== lojaId && (c as any).store_id !== lojaId);
    db.categorias.push(...categorias);
    this.saveDB(db);
    notifyEvent('app_storage_change', { lojaId });
  },

  saveProdutosCache(lojaId: string, produtos: Produto[]): void {
    const db = this.getDB();
    db.produtos = db.produtos.filter((p) => p.loja_id !== lojaId && (p as any).store_id !== lojaId);
    db.produtos.push(...produtos);
    this.saveDB(db);
    notifyEvent('app_storage_change', { lojaId });
  },

  saveOrUpdateAssinaturaCache(ass: SaasAssinatura): void {
    const db = this.getDB();
    const idx = db.assinaturas.findIndex((a) => a.loja_id === ass.loja_id || a.id === ass.id);
    if (idx !== -1) {
      db.assinaturas[idx] = { ...db.assinaturas[idx], ...ass };
    } else {
      db.assinaturas.push(ass);
    }
    this.saveDB(db);
  },

  limparCardapioLoja(lojaId: string): void {
    const db = this.getDB();
    db.produtos = db.produtos.filter((p) => p.loja_id !== lojaId && (p as any).store_id !== lojaId);
    db.categorias = db.categorias.filter((c) => c.loja_id !== lojaId && (c as any).store_id !== lojaId);
    this.saveDB(db);
    notifyEvent('app_storage_change', { lojaId });
  },

  createLoja(dados: Partial<Loja>): Loja {
    const db = this.getDB();
    const id = dados.id || generateUUID();
    const slug = (dados.slug || sanitizeSlug(dados.nome_loja || dados.nome || 'loja')).toLowerCase().trim();
    const nova: Loja = {
      id,
      nome_loja: dados.nome_loja || dados.nome || 'Nova Loja',
      nome: dados.nome || dados.nome_loja || 'Nova Loja',
      slug,
      telefone_whatsapp: dados.telefone_whatsapp || dados.whatsapp || '',
      whatsapp: dados.whatsapp || dados.telefone_whatsapp || '',
      created_at: dados.created_at || new Date().toISOString(),
      endereco_origem: dados.endereco_origem || { lat: -20.4697, lng: -54.6201, endereco_texto: '' },
      chave_pix: dados.chave_pix || '',
      taxa_base_entrega: dados.taxa_base_entrega ?? 5,
      valor_por_km: dados.valor_por_km ?? 1.5,
      status_conta: dados.status_conta || 'ativa',
      email: dados.email || '',
      senha: dados.senha || '',
      logo_url: dados.logo_url || '',
      cor_primaria: dados.cor_primaria || '#dc2626',
      aberto: dados.aberto ?? true,
      ...dados,
    };
    db.lojas.unshift(nova);
    this.saveDB(db);
    notifyEvent('loja_cadastrada', { loja: nova });
    return nova;
  },

  addLoja(dados: Partial<Loja>): Loja {
    return this.createLoja(dados);
  },

  updateLoja(id: string, updates: Partial<Loja>): void {
    const db = this.getDB();
    const idx = db.lojas.findIndex((l) => l.id === id);
    if (idx !== -1) {
      db.lojas[idx] = { ...db.lojas[idx], ...updates };
      const updatedLoja = db.lojas[idx];
      this.saveDB(db);
      notifyEvent('loja_atualizada', { lojaId: id, loja: updatedLoja });
    }
  },

  updateLojaPrinterConfig(lojaId: string, config: PrinterConfig): void {
    this.updateLoja(lojaId, {
      impressora_largura: config.largura,
      impressora_fonte: config.fonte,
      impressora_vias: config.vias,
      impressora_auto_imprimir: config.autoImprimir,
    });
  },

  updateLojaBanner(lojaId: string, banner: BannerOfertaConfig): void {
    this.updateLoja(lojaId, { banner_oferta: banner });
  },

  getSupabaseConfig(): SupabaseConfig {
    try {
      const data = localStorage.getItem(SUPABASE_CONFIG_KEY);
      if (data) {
        const parsed = JSON.parse(data);
        if (parsed.url && parsed.anonKey) return parsed;
      }
    } catch {}
    return {
      url: 'https://eyaufwzdrjtfzcvtuxyw.supabase.co',
      anonKey: 'sb_publishable_safdydwDCc5Z6KZrXxRUGQ_ui9kB0Vl',
      serviceRoleKey: '',
      status: 'connected',
    };
  },

  saveSupabaseConfig(config: SupabaseConfig): void {
    try {
      localStorage.setItem(SUPABASE_CONFIG_KEY, JSON.stringify(config));
      notifyEvent('supabase_config_atualizada', config);
    } catch (e) {
      console.warn('Erro ao salvar configuração Supabase:', e);
    }
  },

  clearSupabaseConfig(): void {
    try {
      localStorage.removeItem(SUPABASE_CONFIG_KEY);
      notifyEvent('supabase_config_atualizada', { status: 'unconfigured' });
    } catch {}
  },

  inicializarCategoriasPadrao(lojaId: string, segmento?: string): Categoria[] {
    const db = this.getDB();
    const geradas = gerarItensPadraoPorSegmento(lojaId, segmento);

    // Remove antigas para inicializar limpo com o segmento selecionado
    db.categorias = db.categorias.filter((c) => c.loja_id !== lojaId && (c as any).store_id !== lojaId);
    db.produtos = db.produtos.filter((p) => p.loja_id !== lojaId && (p as any).store_id !== lojaId);

    db.categorias.push(...geradas.categorias);
    db.produtos.push(...geradas.produtos);
    this.saveDB(db);

    notifyEvent('cardapio_inicializado', { lojaId, categorias: geradas.categorias });
    notifyEvent('app_storage_change', { action: 'cardapio_inicializado', lojaId });
    return geradas.categorias;
  },

  editarLojaCompleta(
    lojaId: string,
    dados: Partial<Loja> & { diasTeste?: number; valorMensal?: number }
  ): Loja | null {
    const db = this.getDB();
    const idx = db.lojas.findIndex((l) => l.id === lojaId);
    if (idx === -1) return null;

    db.lojas[idx] = {
      ...db.lojas[idx],
      ...dados,
      id: lojaId,
    };
    const lojaAtualizada = db.lojas[idx];

    const ass = db.assinaturas.find((a) => a.loja_id === lojaId);
    if (ass) {
      if (dados.valorMensal !== undefined && !isNaN(dados.valorMensal)) {
        ass.valor = dados.valorMensal;
      }
      if (dados.diasTeste !== undefined && !isNaN(dados.diasTeste)) {
        ass.dias_teste = Math.max(0, Math.floor(dados.diasTeste));
        ass.data_vencimento = new Date(Date.now() + ass.dias_teste * 24 * 3600 * 1000).toISOString();
        if (ass.dias_teste > 0 && lojaAtualizada.status_conta !== 'bloqueada') {
          ass.status = 'ativa';
        }
      }
      if (dados.status_conta) {
        ass.status = dados.status_conta === 'bloqueada' ? 'bloqueada' : 'ativa';
      }
    }

    this.saveDB(db);
    notifyEvent('loja_atualizada', { lojaId, loja: lojaAtualizada });
    notifyEvent('app_storage_change', { action: 'loja_editada', lojaId, loja: lojaAtualizada });
    return lojaAtualizada;
  },

  getCategorias(lojaId: string): Categoria[] {
    if (!lojaId) return [];
    const db = this.getDB();
    return db.categorias
      .filter((c) => c.loja_id === lojaId || (c as any).store_id === lojaId)
      .sort((a, b) => a.ordem - b.ordem);
  },

  addCategoria(lojaId: string, nome: string): Categoria {
    const db = this.getDB();
    const nova: Categoria = {
      id: generateUUID(),
      loja_id: lojaId,
      nome,
      ordem: db.categorias.filter((c) => c.loja_id === lojaId || (c as any).store_id === lojaId).length + 1,
      ativa: true,
      created_at: new Date().toISOString(),
    };
    db.categorias.push(nova);
    this.saveDB(db);
    notifyEvent('categoria_adicionada', { categoria: nova });
    return nova;
  },

  getProdutos(lojaId: string): Produto[] {
    if (!lojaId) return [];
    return this.getDB().produtos.filter((p) => p.loja_id === lojaId || (p as any).store_id === lojaId);
  },

  addProduto(produto: Omit<Produto, 'id' | 'created_at'> & { id?: string }): Produto {
    const db = this.getDB();
    const novo: Produto = {
      ...produto,
      id: produto.id || generateUUID(),
      created_at: new Date().toISOString(),
      disponivel: produto.disponivel ?? true,
      ativo: produto.ativo ?? true,
    };
    db.produtos.unshift(novo);
    this.saveDB(db);
    notifyEvent('produto_salvo', { produto: novo });
    return novo;
  },

  updateProduto(id: string, updates: Partial<Produto>): void {
    const db = this.getDB();
    const idx = db.produtos.findIndex((p) => p.id === id);
    if (idx !== -1) {
      db.produtos[idx] = { ...db.produtos[idx], ...updates };
      const prod = db.produtos[idx];
      this.saveDB(db);
      notifyEvent('produto_salvo', { produtoId: id, produto: prod });
    }
  },

  deleteProduto(id: string): void {
    const db = this.getDB();
    db.produtos = db.produtos.filter((p) => p.id !== id);
    this.saveDB(db);
    notifyEvent('produto_removido', { produtoId: id });
  },

  getClientes(lojaId: string): Cliente[] {
    return (this.getDB().clientes || []).filter((c) => c.loja_id === lojaId);
  },

  findClienteByTelefone(lojaId: string, telefone: string): Cliente | null {
    const limpo = telefone.replace(/\D/g, '');
    if (!limpo || limpo.length < 8) return null;
    const db = this.getDB();
    const found = (db.clientes || []).find(
      (c) => c.loja_id === lojaId && c.telefone.replace(/\D/g, '').includes(limpo.slice(-8))
    );
    return found || null;
  },

  saveCliente(cliente: Omit<Cliente, 'id' | 'created_at'>): Cliente {
    const db = this.getDB();
    if (!db.clientes) db.clientes = [];
    const cleanTel = cliente.telefone.replace(/\D/g, '');
    const existingIndex = db.clientes.findIndex(
      (c) => c.loja_id === cliente.loja_id && c.telefone.replace(/\D/g, '') === cleanTel
    );
    if (existingIndex !== -1) {
      db.clientes[existingIndex] = {
        ...db.clientes[existingIndex],
        ...cliente,
      };
      this.saveDB(db);
      return db.clientes[existingIndex];
    }
    const novo: Cliente = {
      ...cliente,
      id: `cli-${Date.now()}`,
      created_at: new Date().toISOString(),
    };
    db.clientes.push(novo);
    this.saveDB(db);
    return novo;
  },

  getPedidos(lojaId: string): Pedido[] {
    return this.getDB()
      .pedidos.filter((p) => p.loja_id === lojaId)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  },

  addPedido(pedidoData: any): Pedido {
    const db = this.getDB();
    const novo: Pedido = {
      ...pedidoData,
      id: pedidoData.id || generateUUID(),
      codigo_pedido: pedidoData.codigo_pedido || `#${Math.floor(1000 + Math.random() * 9000)}`,
      created_at: pedidoData.created_at || new Date().toISOString(),
      status: pedidoData.status || 'pendente',
      impresso: pedidoData.impresso || false,
    };
    db.pedidos.unshift(novo);
    this.saveDB(db);
    if (novo.cliente_telefone && novo.cliente_nome) {
      this.saveCliente({
        loja_id: novo.loja_id,
        nome: novo.cliente_nome,
        telefone: novo.cliente_telefone,
        endereco: novo.endereco_destino || novo.endereco_completo || 'Retirada',
      });
    }
    notifyEvent('pedido_criado', { pedido: novo });
    return novo;
  },

  updatePedidoStatus(id: string, status: OrderStatus): void {
    const db = this.getDB();
    const idx = db.pedidos.findIndex((p) => p.id === id);
    if (idx !== -1) {
      db.pedidos[idx].status = status;
      this.saveDB(db);
      notifyEvent('pedido_status_alterado', { pedidoId: id, status });
    }
  },

  updatePedidoImpresso(id: string, impresso: boolean): void {
    const db = this.getDB();
    const idx = db.pedidos.findIndex((p) => p.id === id);
    if (idx !== -1) {
      db.pedidos[idx].impresso = impresso;
      this.saveDB(db);
      notifyEvent('pedido_impresso', { pedidoId: id });
    }
  },

  getAssinaturas(): SaasAssinatura[] {
    return this.getDB().assinaturas || [];
  },

  getPagamentosSaas(): SaasPaymentLog[] {
    return this.getDB().pagamentosSaas || [];
  },

  getAssinaturaByLoja(lojaId: string): SaasAssinatura | undefined {
    return this.getDB().assinaturas.find((a) => a.loja_id === lojaId);
  },

  cadastrarNovaLoja(dados: {
    nomeLoja: string;
    slug: string;
    whatsapp: string;
    email: string;
    senha?: string;
    logo_url?: string;
    segmento?: string;
  }): { loja: Loja; assinatura: SaasAssinatura } {
    const db = this.getDB();
    const cleanEmail = dados.email.trim().toLowerCase();
    const cleanWhatsapp = dados.whatsapp.trim().replace(/\D/g, '');
    const cleanSenha = (dados.senha || '').trim();
    const cleanNome = dados.nomeLoja.trim();
    const rawSlug = (dados.slug || cleanNome || '')
      .toString()
      .toLowerCase()
      .trim()
      .replace(/\s+/g, '-')
      .replace(/[^a-z0-9-]/g, '')
      .replace(/-+/g, '-')
      .replace(/^-+|-+$/g, '');
    const cleanSlug = rawSlug || `loja-${Date.now()}`;

    const finalSlug = cleanSlug;
    const lojaId = generateUUID();
    const novaLoja: Loja = {
      id: lojaId,
      user_id: generateUUID(),
      nome_loja: cleanNome,
      nome: cleanNome,
      slug: finalSlug,
      telefone_whatsapp: cleanWhatsapp,
      whatsapp: cleanWhatsapp,
      email: cleanEmail,
      senha: cleanSenha || '123456',
      logo_url: dados.logo_url?.trim() || '',
      segmento: dados.segmento || 'outro',
      cidade: 'Campo Grande, MS',
      endereco_origem: {
        lat: -20.4697,
        lng: -54.6201,
        endereco_texto: 'Av. Afonso Pena, 1500 - Centro',
      },
      taxa_base_entrega: 5.0,
      valor_por_km: 1.5,
      taxas_bairros: [
        { id: `tb-1-${lojaId}`, bairro: 'Centro', taxa: 5.0 },
        { id: `tb-2-${lojaId}`, bairro: 'Jardim dos Estados', taxa: 7.0 },
      ],
      aberto: true,
      status_conta: 'ativa',
      impressora_largura: '80mm',
      impressora_fonte: 'normal',
      impressora_vias: 1,
      impressora_auto_imprimir: true,
      created_at: new Date().toISOString(),
    };

    const saasSettings = this.getSaasPlanSettings();
    const diasTeste = Math.max(1, saasSettings.dias_teste_padrao || 7);
    const novaAssinatura: SaasAssinatura = {
      id: generateUUID(),
      loja_id: lojaId,
      status: 'ativa',
      plano: 'mensal',
      valor: saasSettings.valor_mensal_padrao || 169.99,
      data_vencimento: new Date(Date.now() + diasTeste * 24 * 3600 * 1000).toISOString(),
      dias_teste: diasTeste,
      created_at: new Date().toISOString(),
    };

    db.lojas.push(novaLoja);
    db.assinaturas.push(novaAssinatura);
    this.saveDB(db);

    // Inicializa categorias e produtos demonstrativos do segmento escolhido
    this.inicializarCategoriasPadrao(lojaId, dados.segmento || 'outro');

    this.setActiveLojaId(lojaId);
    this.setAuthenticatedMerchantLojaId(lojaId);
    notifyEvent('loja_cadastrada', { loja: novaLoja, assinatura: novaAssinatura });
    return { loja: novaLoja, assinatura: novaAssinatura };
  },

  getAuthenticatedMerchantLojaId(): string | null {
    try {
      return sessionStorage.getItem('delivery_saas_merchant_auth_loja_id');
    } catch {
      return null;
    }
  },

  setAuthenticatedMerchantLojaId(lojaId: string | null): void {
    try {
      if (lojaId) {
        sessionStorage.setItem('delivery_saas_merchant_auth_loja_id', lojaId);
      } else {
        sessionStorage.removeItem('delivery_saas_merchant_auth_loja_id');
      }
      notifyEvent('merchant_auth_change', { lojaId });
    } catch {}
  },

  logoutMerchant(): void {
    this.setAuthenticatedMerchantLojaId(null);
  },

  authenticateMerchant(
    lojaId: string,
    emailOuTel: string,
    senhaDigitada: string
  ): { success: boolean; lojaId?: string; erro?: string } {
    const cleanInput = (emailOuTel || '').trim().toLowerCase();
    const cleanTel = cleanInput.replace(/\D/g, '');
    const cleanSenha = (senhaDigitada || '').trim();

    if (cleanInput === 'adileradm') {
      return { success: false, erro: 'Credencial de Super Admin. Use o login de Super Admin.' };
    }
    if (!cleanInput || !cleanSenha) {
      return { success: false, erro: 'Preencha todos os campos para autenticar.' };
    }

    const lojas = this.getLojas();
    const matchesLoja = (l: Loja): boolean => {
      const lEmail = (l.email || '').trim().toLowerCase();
      const lTel = (l.telefone_whatsapp || l.whatsapp || '').replace(/\D/g, '');
      const lSlug = (l.slug || '').trim().toLowerCase();
      const emailMatch = lEmail.length > 0 && cleanInput === lEmail;
      const slugMatch = lSlug.length > 0 && cleanInput === lSlug;
      const telMatch = cleanTel.length >= 8 && lTel.length >= 8 && (lTel === cleanTel || lTel.endsWith(cleanTel) || cleanTel.endsWith(lTel));
      return emailMatch || slugMatch || telMatch;
    };

    const lojaSelecionada = this.getLojaById(lojaId);
    if (lojaSelecionada && matchesLoja(lojaSelecionada)) {
      if (cleanSenha === (lojaSelecionada.senha || '123456')) {
        this.setAuthenticatedMerchantLojaId(lojaSelecionada.id);
        this.setActiveLojaId(lojaSelecionada.id);
        return { success: true, lojaId: lojaSelecionada.id };
      }
    }

    const lojaEncontrada = lojas.find((l) => matchesLoja(l));
    if (lojaEncontrada) {
      if (cleanSenha === (lojaEncontrada.senha || '123456')) {
        this.setAuthenticatedMerchantLojaId(lojaEncontrada.id);
        this.setActiveLojaId(lojaEncontrada.id);
        return { success: true, lojaId: lojaEncontrada.id };
      }
    }

    return { success: false, erro: 'E-mail, telefone ou senha incorretos.' };
  },

  adicionarDiasAssinatura(lojaId: string, dias: number): void {
    const db = this.getDB();
    const ass = db.assinaturas.find((a) => a.loja_id === lojaId);
    if (ass) {
      const atual = new Date(ass.data_vencimento).getTime();
      const base = atual > Date.now() ? atual : Date.now();
      ass.data_vencimento = new Date(base + dias * 24 * 3600 * 1000).toISOString();
      ass.status = 'ativa';
      if (ass.dias_teste && ass.dias_teste > 0) {
        ass.dias_teste = Math.max(1, ass.dias_teste + dias);
      }
    }
    const loja = db.lojas.find((l) => l.id === lojaId);
    if (loja) {
      loja.status_conta = 'ativa';
    }
    this.saveDB(db);
    notifyEvent('assinatura_atualizada', { lojaId });
  },

  atualizarTempoTesteLoja(lojaId: string, diasTeste: number, status: 'ativa' | 'bloqueada' = 'ativa'): void {
    const db = this.getDB();
    const dias = Math.max(0, Math.floor(diasTeste));
    const ass = db.assinaturas.find((a) => a.loja_id === lojaId);
    const dataVencimento = new Date(Date.now() + dias * 24 * 3600 * 1000).toISOString();

    if (ass) {
      ass.dias_teste = dias;
      ass.data_vencimento = dataVencimento;
      ass.status = status;
    } else {
      const novaAss: SaasAssinatura = {
        id: `ass-${lojaId}`,
        loja_id: lojaId,
        status,
        plano: 'mensal',
        valor: 169.99,
        data_vencimento: dataVencimento,
        dias_teste: dias,
        created_at: new Date().toISOString(),
      };
      db.assinaturas.push(novaAss);
    }

    const loja = db.lojas.find((l) => l.id === lojaId);
    if (loja) {
      loja.status_conta = status;
    }

    this.saveDB(db);
    notifyEvent('assinatura_atualizada', { lojaId, diasTeste: dias });
    notifyEvent('app_storage_change', { action: 'tempo_teste_atualizado', lojaId, diasTeste: dias });
  },

  toggleBloqueioLoja(lojaId: string): boolean {
    const db = this.getDB();
    const loja = db.lojas.find((l) => l.id === lojaId);
    if (!loja) return false;
    const novoStatus = loja.status_conta === 'ativa' ? 'bloqueada' : 'ativa';
    loja.status_conta = novoStatus;
    const ass = db.assinaturas.find((a) => a.loja_id === lojaId);
    if (ass) {
      ass.status = novoStatus === 'ativa' ? 'ativa' : 'bloqueada';
    }
    this.saveDB(db);
    notifyEvent('loja_bloqueio_alterado', { lojaId, status: novoStatus });
    return novoStatus === 'ativa';
  },

  atualizarValorMensalidade(lojaId: string, valor: number): void {
    const db = this.getDB();
    const ass = db.assinaturas.find((a) => a.loja_id === lojaId);
    if (ass) {
      ass.valor = valor;
      this.saveDB(db);
      notifyEvent('assinatura_atualizada', { lojaId });
    }
  },

  processarWebhookPagamentoSaas(
    lojaId: string,
    gateway: 'mercadopago' | 'abacatepay',
    transacaoId: string
  ): { sucesso: boolean; mensagem: string } {
    const db = this.getDB();
    const ass = db.assinaturas.find((a) => a.loja_id === lojaId);
    const loja = db.lojas.find((l) => l.id === lojaId);
    if (ass) {
      ass.status = 'ativa';
      ass.data_vencimento = new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString();
      ass.ultimo_pagamento = new Date().toISOString();
      ass.dias_teste = 0;
    }
    if (loja) {
      loja.status_conta = 'ativa';
    }
    if (!db.pagamentosSaas) db.pagamentosSaas = [];
    db.pagamentosSaas.unshift({
      id: `pay-${Date.now()}`,
      loja_id: lojaId,
      loja_nome: loja?.nome_loja || 'Loja Parceira',
      valor: ass?.valor || 169.99,
      metodo: 'pix',
      gateway,
      status: 'confirmado',
      data_pagamento: new Date().toISOString(),
      comprovante_id: transacaoId,
    });
    this.saveDB(db);
    notifyEvent('assinatura_paga', { lojaId });
    return {
      sucesso: true,
      mensagem: `Pagamento PIX confirmado via ${gateway}! Assinatura renovada por +30 dias.`,
    };
  },

  arquivarPedidosAntigos(): { deletados: number; espacoLiberadoMb: number } {
    const db = this.getDB();
    const umAnoAtras = Date.now() - 365 * 24 * 3600 * 1000;
    const pedidosAtuais = db.pedidos.filter(
      (p) => new Date(p.created_at).getTime() >= umAnoAtras
    );
    const deletados = db.pedidos.length - pedidosAtuais.length;
    db.pedidos = pedidosAtuais;
    this.saveDB(db);
    const liberado = Number(((deletados * 2.5) / 1024).toFixed(2));
    return { deletados, espacoLiberadoMb: liberado };
  },

  getMetrics(): StorageMetrics {
    const db = this.getDB();
    const str = JSON.stringify(db);
    const sizeBytes = new Blob([str]).size;
    return {
      db_size_bytes: sizeBytes,
      db_size_mb: Number((sizeBytes / (1024 * 1024)).toFixed(3)),
      db_limit_mb: 500,
      photos_size_mb: Number(((db.produtos.length * 90) / 1024).toFixed(2)),
      photos_limit_mb: 1000,
      total_pedidos: db.pedidos.length,
      pedidos_antigos_elegiveis: 0,
    };
  },

  getAvisosGlobais(): AvisoGlobal[] {
    try {
      const data = localStorage.getItem(AVISOS_GLOBAIS_KEY);
      if (data) return JSON.parse(data);
    } catch {}
    return DEFAULT_AVISOS;
  },

  saveAvisoGlobal(aviso: AvisoGlobal): void {
    const list = this.getAvisosGlobais();
    const idx = list.findIndex((a) => a.id === aviso.id);
    if (idx !== -1) {
      list[idx] = aviso;
    } else {
      list.unshift(aviso);
    }
    localStorage.setItem(AVISOS_GLOBAIS_KEY, JSON.stringify(list));
    notifyEvent('avisos_atualizados', {});
  },

  deleteAvisoGlobal(id: string): void {
    const list = this.getAvisosGlobais().filter((a) => a.id !== id);
    localStorage.setItem(AVISOS_GLOBAIS_KEY, JSON.stringify(list));
    notifyEvent('avisos_atualizados', {});
  },

  toggleAvisoGlobal(id: string): void {
    const list = this.getAvisosGlobais();
    const item = list.find((a) => a.id === id);
    if (item) {
      item.ativo = !item.ativo;
      localStorage.setItem(AVISOS_GLOBAIS_KEY, JSON.stringify(list));
      notifyEvent('avisos_atualizados', {});
    }
  },

  getSaasPlanSettings(): SaasPlanSettings {
    try {
      const data = localStorage.getItem(SAAS_PLAN_SETTINGS_KEY);
      if (data) return { ...DEFAULT_PLAN_SETTINGS, ...JSON.parse(data) };
    } catch {}
    return DEFAULT_PLAN_SETTINGS;
  },

  saveSaasPlanSettings(settings: Partial<SaasPlanSettings>): void {
    const current = this.getSaasPlanSettings();
    const updated = { ...current, ...settings };
    localStorage.setItem(SAAS_PLAN_SETTINGS_KEY, JSON.stringify(updated));
    notifyEvent('saas_plan_settings_atualizado', updated);
  },

  getSaasBranding(): SaasBranding {
    try {
      const data = localStorage.getItem(SAAS_BRANDING_KEY);
      if (data) return { ...DEFAULT_BRANDING, ...JSON.parse(data) };
    } catch {}
    return DEFAULT_BRANDING;
  },

  saveSaasBranding(branding: Partial<SaasBranding>): void {
    const current = this.getSaasBranding();
    const updated = { ...current, ...branding };
    localStorage.setItem(SAAS_BRANDING_KEY, JSON.stringify(updated));
    notifyEvent('saas_branding_atualizado', updated);
  },
};

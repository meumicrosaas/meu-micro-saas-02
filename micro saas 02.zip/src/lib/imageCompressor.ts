/**
 * Client-Side Image Compressor & WebP Converter
 * Converte e compacta fotos de produtos diretamente no navegador antes do upload para o Supabase Storage,
 * economizando cota do plano gratuito (1GB limit).
 */

export interface CompressionResult {
  blob: Blob;
  dataUrl: string;
  originalSizeKb: number;
  compressedSizeKb: number;
  reductionPercentage: number;
}

export async function compressAndConvertToWebP(
  file: File,
  maxWidth: number = 800,
  quality: number = 0.8
): Promise<CompressionResult> {
  return new Promise((resolve, reject) => {
    const originalSizeKb = Math.round(file.size / 1024);
    const reader = new FileReader();

    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Falha ao obter contexto do canvas'));
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);

        canvas.toBlob(
          (blob) => {
            if (!blob) {
              reject(new Error('Falha ao converter para WebP'));
              return;
            }

            const compressedSizeKb = Math.round(blob.size / 1024);
            const reductionPercentage =
              originalSizeKb > 0
                ? Math.max(0, Math.round(((originalSizeKb - compressedSizeKb) / originalSizeKb) * 100))
                : 0;

            const dataUrl = canvas.toDataURL('image/webp', quality);

            resolve({
              blob,
              dataUrl,
              originalSizeKb,
              compressedSizeKb,
              reductionPercentage,
            });
          },
          'image/webp',
          quality
        );
      };

      img.onerror = () => reject(new Error('Falha ao carregar imagem'));
      img.src = event.target?.result as string;
    };

    reader.onerror = () => reject(new Error('Falha ao ler arquivo'));
    reader.readAsDataURL(file);
  });
}

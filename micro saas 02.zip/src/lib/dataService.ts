import { Loja, Produto, Categoria, Pedido, OrderStatus, TaxaBairro } from '../types';
import { AppStorage } from './storage';
import { DataService as SupabaseDataService } from './supabase';
import { calcularDistanciaHaversine, calcularTaxaEntrega, Coordinates } from './haversine';

export const dataService = {
  // ===== TENANTS / LOJAS =====
  async getTenants(): Promise<Loja[]> {
    try {
      const supa = await SupabaseDataService.getLojas();
      if (supa && supa.length > 0) return supa;
    } catch {}
    return AppStorage.getLojas();
  },

  getTenantsSync(): Loja[] {
    return AppStorage.getLojas();
  },

  async getTenantById(id: string): Promise<Loja | null> {
    const local = AppStorage.getLojaById(id);
    if (local) return local;
    try {
      const remote = await SupabaseDataService.getLojas();
      const found = remote.find((l) => l.id === id);
      if (found) return found;
    } catch {}
    return null;
  },

  async getTenantBySlug(slug: string): Promise<Loja | null> {
    const local = AppStorage.getLojaBySlug(slug);
    if (local) return local;
    try {
      const supa = await SupabaseDataService.getLojaBySlug(slug);
      if (supa) return supa;
    } catch {}
    return null;
  },

  async createTenant(tenantData: Partial<Loja>): Promise<Loja> {
    const novaLoja = AppStorage.createLoja(tenantData);
    try {
      if (tenantData.nome_loja && tenantData.slug && tenantData.telefone_whatsapp && tenantData.email && tenantData.senha) {
        await SupabaseDataService.cadastrarNovaLoja({
          nomeLoja: tenantData.nome_loja,
          slug: tenantData.slug,
          whatsapp: tenantData.telefone_whatsapp,
          email: tenantData.email,
          senha: tenantData.senha,
          logo_url: tenantData.logo_url,
        });
      }
    } catch (err) {
      console.warn('Erro ao sincronizar nova loja no Supabase (mantida localmente):', err);
    }
    return novaLoja;
  },

  async updateTenant(id: string, updates: Partial<Loja>): Promise<Loja | null> {
    AppStorage.updateLoja(id, updates);
    const atualizada = AppStorage.getLojaById(id);
    return atualizada || null;
  },

  async deleteTenant(idOrSlug: string): Promise<boolean> {
    const localOk = AppStorage.deleteLoja(idOrSlug);
    try {
      await SupabaseDataService.deleteLoja(idOrSlug);
    } catch (err) {
      console.warn('Erro ao sincronizar exclusão da loja no Supabase:', err);
    }
    return localOk;
  },

  // ===== PRODUTOS =====
  async getProducts(tenantId: string): Promise<Produto[]> {
    try {
      const supa = await SupabaseDataService.getProdutos(tenantId);
      if (supa && supa.length > 0) return supa;
    } catch {}
    return AppStorage.getProdutos(tenantId);
  },

  async createProduct(productData: Omit<Produto, 'id' | 'created_at'>): Promise<Produto> {
    const local = AppStorage.addProduto(productData);
    try {
      await SupabaseDataService.saveProduto(local);
    } catch (err) {
      console.warn('Erro ao salvar produto no Supabase:', err);
    }
    return local;
  },

  async updateProduct(id: string, updates: Partial<Produto>): Promise<Produto | null> {
    AppStorage.updateProduto(id, updates);
    const db = AppStorage.getDB();
    const prod = db.produtos.find((p) => p.id === id);
    if (prod) {
      try {
        await SupabaseDataService.saveProduto(prod);
      } catch (err) {
        console.warn('Erro ao atualizar produto no Supabase:', err);
      }
      return prod;
    }
    return null;
  },

  async deleteProduct(tenantId: string, productId: string): Promise<boolean> {
    AppStorage.deleteProduto(productId);
    try {
      await SupabaseDataService.deleteProduto(tenantId, productId);
    } catch (err) {
      console.warn('Erro ao deletar produto no Supabase:', err);
    }
    return true;
  },

  // ===== CATEGORIAS =====
  async getCategories(tenantId: string): Promise<Categoria[]> {
    try {
      const supa = await SupabaseDataService.getCategorias(tenantId);
      if (supa && supa.length > 0) return supa;
    } catch {}
    return AppStorage.getCategorias(tenantId);
  },

  async createCategory(tenantId: string, nome: string): Promise<Categoria> {
    const cat = AppStorage.addCategoria(tenantId, nome);
    try {
      await SupabaseDataService.addCategoria(tenantId, nome);
    } catch (err) {
      console.warn('Erro ao salvar categoria no Supabase:', err);
    }
    return cat;
  },

  // ===== PEDIDOS =====
  async getOrders(tenantId: string): Promise<Pedido[]> {
    try {
      const supa = await SupabaseDataService.getPedidos(tenantId);
      if (supa && supa.length > 0) return supa;
    } catch {}
    return AppStorage.getPedidos(tenantId);
  },

  async createOrder(orderData: Omit<Pedido, 'id' | 'created_at'>): Promise<Pedido> {
    const order = AppStorage.addPedido(orderData);
    try {
      await SupabaseDataService.createPedido(order);
    } catch (err) {
      console.warn('Erro ao enviar pedido para Supabase:', err);
    }
    return order;
  },

  async updateOrderStatus(orderId: string, status: OrderStatus): Promise<boolean> {
    AppStorage.updatePedidoStatus(orderId, status);
    try {
      await SupabaseDataService.updatePedidoStatus(orderId, status);
    } catch (err) {
      console.warn('Erro ao atualizar status do pedido no Supabase:', err);
    }
    return true;
  },

  // ===== FRETE & CÁLCULO GEOGRÁFICO =====
  calculateFreight(
    origin: Coordinates,
    destination: Coordinates,
    baseRate: number,
    kmRate: number,
    neighborhood?: TaxaBairro
  ): { distanceKm: number; fee: number; method: 'km' | 'bairro' } {
    if (neighborhood && neighborhood.taxa > 0) {
      const distance = calcularDistanciaHaversine(origin, destination);
      return {
        distanceKm: distance,
        fee: neighborhood.taxa,
        method: 'bairro',
      };
    }
    const distance = calcularDistanciaHaversine(origin, destination);
    const fee = calcularTaxaEntrega(distance, baseRate, kmRate);
    return {
      distanceKm: distance,
      fee,
      method: 'km',
    };
  },
};

export default dataService;

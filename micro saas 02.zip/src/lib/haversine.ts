/**
 * Algoritmo de Geolocalização por KM baseado na Fórmula de Haversine
 * Permite cálculo de frete sem custos de APIs pagas (OpenStreetMap / Coordenadas).
 */
export interface Coordinates {
  lat: number;
  lng: number;
}

/**
 * Coordenadas padrão de cidades brasileiras para fallback imediato e preciso
 */
export const COORDENADAS_CIDADES: Record<string, Coordinates> = {
  'campo grande': { lat: -20.4697, lng: -54.6201 },
  'campo grande ms': { lat: -20.4697, lng: -54.6201 },
  'sao paulo': { lat: -23.5505, lng: -46.6333 },
  'são paulo': { lat: -23.5505, lng: -46.6333 },
  'rio de janeiro': { lat: -22.9068, lng: -43.1729 },
  'curitiba': { lat: -25.4284, lng: -49.2733 },
  'belo horizonte': { lat: -19.9167, lng: -43.9345 },
  'brasilia': { lat: -15.7975, lng: -47.8919 },
  'brasília': { lat: -15.7975, lng: -47.8919 },
  'goiania': { lat: -16.6869, lng: -49.2648 },
  'goiânia': { lat: -16.6869, lng: -49.2648 },
  'cuiaba': { lat: -15.6014, lng: -56.0979 },
  'cuiabá': { lat: -15.6014, lng: -56.0979 },
  'porto alegre': { lat: -30.0346, lng: -51.2177 },
  'florianopolis': { lat: -27.5954, lng: -48.5480 },
  'florianópolis': { lat: -27.5954, lng: -48.5480 },
  'salvador': { lat: -12.9777, lng: -38.5016 },
  'recife': { lat: -8.0476, lng: -34.8770 },
  'fortaleza': { lat: -3.7319, lng: -38.5267 },
  'manaus': { lat: -3.1190, lng: -60.0217 },
  'belem': { lat: -1.4558, lng: -48.4902 },
  'belém': { lat: -1.4558, lng: -48.4902 },
};

/**
 * Busca coordenadas a partir de texto de endereço e cidade
 * Utiliza OpenStreetMap Nominatim com fallback inteligente para a base de cidades
 */
export async function buscarCoordenadasEndereco(
  endereco: string,
  cidade?: string
): Promise<Coordinates | null> {
  const queryCompleta = [endereco.trim(), cidade?.trim(), 'Brasil']
    .filter(Boolean)
    .join(', ');

  // 1. Tenta geocodificação gratuita via OpenStreetMap Nominatim
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2500);
    const res = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(queryCompleta)}&limit=1`,
      {
        headers: { 'Accept-Language': 'pt-BR,pt;q=0.9' },
        signal: controller.signal,
      }
    );
    clearTimeout(timeoutId);
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0 && data[0].lat && data[0].lon) {
        return {
          lat: parseFloat(data[0].lat),
          lng: parseFloat(data[0].lon),
        };
      }
    }
  } catch {}

  // 2. Fallback por detecção de cidade informada no campo ou no endereço
  const textoParaBuscar = `${cidade || ''} ${endereco || ''}`
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');

  for (const [nomeCidade, coords] of Object.entries(COORDENADAS_CIDADES)) {
    const limpo = nomeCidade
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '');
    if (textoParaBuscar.includes(limpo)) {
      return coords;
    }
  }

  // Fallback padrão: Campo Grande, MS
  return { lat: -20.4697, lng: -54.6201 };
}

/**
 * Calcula a distância em quilômetros entre dois pontos geográficos
 * usando a fórmula trigonométrica de Haversine.
 */
export function calcularDistanciaHaversine(
  origem: Coordinates,
  destino: Coordinates
): number {
  const R = 6371; // Raio médio da Terra em quilômetros
  const dLat = toRad(destino.lat - origem.lat);
  const dLon = toRad(destino.lng - origem.lng);
  const lat1 = toRad(origem.lat);
  const lat2 = toRad(destino.lat);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distancia = R * c;

  return Math.round(distancia * 10) / 10; // Arredonda com 1 casa decimal (ex: 3.4 km)
}

function toRad(graus: number): number {
  return (graus * Math.PI) / 180;
}

/**
 * Calcula o valor da taxa de entrega baseado na taxa base da loja e no valor por km
 */
export function calcularTaxaEntrega(
  distanciaKm: number,
  taxaBase: number,
  valorPorKm: number
): number {
  if (distanciaKm <= 0) return taxaBase;
  const taxaTotal = taxaBase + distanciaKm * valorPorKm;
  return Math.round(taxaTotal * 100) / 100;
}

export interface ResultadoCalculoEntrega {
  taxa: number;
  regra: string;
  distanciaKm: number;
  foraDoRaio: boolean;
  tempoEstimado?: string;
  freteGratis: boolean;
}

/**
 * Cálculo inteligente de entrega suportando faixas de raio, valor por km,
 * raio máximo e promoção de frete grátis
 */
export function calcularTaxaEntregaCompleta(params: {
  distanciaKm: number;
  subtotalPedido?: number;
  modeloPreferido?: 'raio_km' | 'distancia_km' | 'bairros';
  taxaBase?: number;
  valorPorKm?: number;
  raiosEntrega?: Array<{ id: string; de_km: number; ate_km: number; valor: number; tempo_estimado_min?: string }>;
  raioMaximoKm?: number;
  valorKmExcedente?: number;
  valorPedidoFreteGratis?: number;
}): ResultadoCalculoEntrega {
  const {
    distanciaKm,
    subtotalPedido = 0,
    modeloPreferido = 'raio_km',
    taxaBase = 5.0,
    valorPorKm = 1.5,
    raiosEntrega = [],
    raioMaximoKm = 15,
    valorKmExcedente = 2.0,
    valorPedidoFreteGratis,
  } = params;

  const dist = Math.max(0.1, Math.round(distanciaKm * 10) / 10);

  // 1. Regra de Frete Grátis por valor do pedido
  if (valorPedidoFreteGratis && valorPedidoFreteGratis > 0 && subtotalPedido >= valorPedidoFreteGratis) {
    return {
      taxa: 0,
      regra: `Frete Grátis (Pedido acima de R$ ${valorPedidoFreteGratis.toFixed(2)})`,
      distanciaKm: dist,
      foraDoRaio: false,
      freteGratis: true,
      tempoEstimado: '30-45 min',
    };
  }

  // 2. Verificação de Raio Máximo
  const foraDoRaio = Boolean(raioMaximoKm && dist > raioMaximoKm);

  // 3. Modelo: Faixas de Raio (se configuradas e habilitadas)
  if ((modeloPreferido === 'raio_km' || !modeloPreferido) && raiosEntrega && raiosEntrega.length > 0) {
    // Ordena as faixas por distância máxima
    const faixasOrdenadas = [...raiosEntrega].sort((a, b) => a.ate_km - b.ate_km);

    for (const faixa of faixasOrdenadas) {
      if (dist >= faixa.de_km && dist <= faixa.ate_km) {
        return {
          taxa: faixa.valor,
          regra: `Raio de ${faixa.de_km} a ${faixa.ate_km} km`,
          distanciaKm: dist,
          foraDoRaio: false,
          tempoEstimado: faixa.tempo_estimado_min || '30-45 min',
          freteGratis: faixa.valor === 0,
        };
      }
    }

    // Se passou da última faixa configurada
    const ultimaFaixa = faixasOrdenadas[faixasOrdenadas.length - 1];
    if (ultimaFaixa && dist > ultimaFaixa.ate_km) {
      const kmAdicionais = dist - ultimaFaixa.ate_km;
      const taxaAdicional = kmAdicionais * (valorKmExcedente || valorPorKm);
      const taxaFinal = Math.round((ultimaFaixa.valor + taxaAdicional) * 100) / 100;
      return {
        taxa: taxaFinal,
        regra: `Raio acima de ${ultimaFaixa.ate_km} km (+R$ ${(valorKmExcedente || valorPorKm).toFixed(2)}/km excedente)`,
        distanciaKm: dist,
        foraDoRaio,
        tempoEstimado: '45-60 min',
        freteGratis: false,
      };
    }
  }

  // 4. Modelo Contínuo: Taxa Base + Valor por KM
  const taxaCalculada = Math.round((taxaBase + dist * valorPorKm) * 100) / 100;
  return {
    taxa: taxaCalculada,
    regra: `Cálculo por KM: Base R$ ${taxaBase.toFixed(2)} + ${dist} km x R$ ${valorPorKm.toFixed(2)}/km`,
    distanciaKm: dist,
    foraDoRaio,
    tempoEstimado: dist > 8 ? '45-60 min' : '30-45 min',
    freteGratis: false,
  };
}

/**
 * Coordenadas simuladas para testes rápidos de endereços urbanos
 */
export const LOCAIS_TESTE: Record<string, { lat: number; lng: number; nome: string }> = {
  bairro_proximo: { lat: -20.4650, lng: -54.6150, nome: 'Centro (Bairro Próximo - 1.2 km)' },
  bairro_medio: { lat: -20.4850, lng: -54.6400, nome: 'Jardins / Vilas (Bairro Médio - 3.8 km)' },
  bairro_distante: { lat: -20.5200, lng: -54.6800, nome: 'Zona Sul / Tiradentes (Bairro Distante - 7.5 km)' },
  bairro_periferico: { lat: -20.5600, lng: -54.7100, nome: 'Aero Rancho / Extremo (Extremo - 12.0 km)' },
};
